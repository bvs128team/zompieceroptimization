using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.GUI;

namespace ZompiercerPerf
{
    static class GraphicsMenu
    {
        static GUIManager manager;
        static bool open;
        static bool russian = true;
        static bool languageKnown;
        static Vector2 scroll;
        static List<Choice> choices;
        static GUIStyle titleStyle;
        static GUIStyle rowStyle;
        static GUIStyle valueStyle;

        sealed class Choice
        {
            public bool Preset;
            public bool KeepPreset;
            public bool Mode;
            public string Title;
            public string[] Labels;
            public Func<int> Get;
            public Action<int> Set;
        }

        public static void Patch(Harmony harmony)
        {
            var hide = new HarmonyMethod(typeof(GraphicsMenu), "HideIfCovered");
            string[] names = {
                "VideoOptionButton", "AudioOptionButton", "ControlInOptionButton", "MouseOptionButton",
                "ControlInOptionGamepadButton", "DifficultyOptionButton", "BackToOptionsButton",
                "CancelOption", "ExitOptionInGameButton", "OptionInGameButton"
            };
            for (int i = 0; i < names.Length; i++)
            {
                var method = AccessTools.Method(typeof(GUIManager), names[i]);
                if (method != null)
                    harmony.Patch(method, null, hide);
            }
        }

        public static void HideIfCovered(GUIManager __instance)
        {
            manager = __instance;
            open = false;
        }

        [HarmonyPatch(typeof(GUIManager), "Start")]
        static class RememberManager
        {
            static void Postfix(GUIManager __instance)
            {
                manager = __instance;
            }
        }

        public static void Draw()
        {
            if (manager == null || manager.options == null || !manager.options.activeSelf)
            {
                open = false;
                return;
            }
            if (LeavesOptions()) { open = false; return; }
            DetectLanguage();
            EnsureStyles();
            int depth = GUI.depth;
            Color color = GUI.color;
            Color background = GUI.backgroundColor;
            GUI.depth = 100;
            try
            {
                if (!open)
                {
                    // Left edge: the game's own settings are centred and must stay uncovered.
                    if (GUI.Button(new Rect(Left(), 12f, 220f, 34f), russian ? "Графика" : "Graphics", buttonStyle))
                    {
                        open = true;
                        PerfPlugin.Tune.Pull();
                    }
                    return;
                }
                float width = 700f;
                float height = Mathf.Min(640f, Screen.height - 40f);
                var window = new Rect(Left(), 48f, width, height);
                GUI.Box(window, GUIContent.none, boxStyle);
                GUI.Label(new Rect(window.x + 16f, window.y + 8f, width - 32f, 26f), russian ? "Графика" : "Graphics", titleStyle);
                EnsureChoices();
                float viewY = window.y + 40f;
                float viewH = height - 88f;
                float contentH = choices.Count * 32f;
                float maxScroll = Mathf.Max(0f, contentH - viewH);
                if (Event.current.type == EventType.ScrollWheel && window.Contains(Event.current.mousePosition))
                {
                    scroll.y = Mathf.Clamp(scroll.y + Event.current.delta.y * 32f, 0f, maxScroll);
                    Event.current.Use();
                }
                if (scroll.y < 0f)
                    scroll.y = 0f;
                if (scroll.y > maxScroll)
                    scroll.y = maxScroll;
                var view = new Rect(window.x + 10f, viewY, width - 20f, viewH);
                GUI.BeginGroup(view);
                for (int i = 0; i < choices.Count; i++)
                    DrawChoice(choices[i], new Rect(0f, i * 32f - scroll.y, view.width - 4f, 30f));
                GUI.EndGroup();
                if (GUI.Button(new Rect(window.x + 16f, window.y + height - 40f, 70f, 28f), "<", buttonStyle))
                    scroll.y -= 96f;
                if (GUI.Button(new Rect(window.x + 94f, window.y + height - 40f, 70f, 28f), ">", buttonStyle))
                    scroll.y += 96f;
                if (GUI.Button(new Rect(window.x + width - 150f, window.y + height - 40f, 130f, 28f), russian ? "Назад" : "Back", buttonStyle))
                    open = false;
            }
            finally
            {
                GUI.depth = depth;
                GUI.color = color;
                GUI.backgroundColor = background;
            }
        }

        static float Left()
        {
            return Mathf.Max(16f, Screen.width * 0.02f);
        }

        static bool LeavesOptions()
        {
            return Shown(manager.videoOption) || Shown(manager.audioOption) || Shown(manager.keyboardMouseControl)
                || Shown(manager.controlGamepad) || Shown(manager.difficultyOption);
        }

        static bool Shown(GameObject go)
        {
            return go != null && go.activeSelf;
        }

        static void DetectLanguage()
        {
            if (languageKnown || manager.options == null)
                return;
            var texts = manager.options.GetComponentsInChildren<UnityEngine.UI.Text>(true);
            bool any = false;
            for (int i = 0; i < texts.Length; i++)
            {
                string value = texts[i].text;
                if (string.IsNullOrEmpty(value))
                    continue;
                any = true;
                for (int c = 0; c < value.Length; c++)
                {
                    if (value[c] >= '\u0400' && value[c] <= '\u04FF')
                    {
                        russian = true;
                        languageKnown = true;
                        return;
                    }
                }
            }
            if (any)
            {
                russian = false;
                languageKnown = true;
            }
        }

        static GUIStyle buttonStyle;
        static GUIStyle boxStyle;

        static GUIStyle Safe(GUIStyle source, int size, TextAnchor align)
        {
            var style = new GUIStyle(source);
            var state = new GUIStyleState();
            state.textColor = Color.white;
            state.background = source.normal.background;
            style.normal = state;
            style.fontSize = size;
            style.alignment = align;
            return style;
        }

        static void EnsureStyles()
        {
            if (titleStyle != null)
                return;
            titleStyle = Safe(GUI.skin.label, 20, TextAnchor.MiddleLeft);
            titleStyle.fontStyle = FontStyle.Bold;
            rowStyle = Safe(GUI.skin.label, 15, TextAnchor.MiddleLeft);
            valueStyle = Safe(GUI.skin.box, 15, TextAnchor.MiddleCenter);
            buttonStyle = Safe(GUI.skin.button, 15, TextAnchor.MiddleCenter);
            boxStyle = Safe(GUI.skin.box, 15, TextAnchor.MiddleCenter);
        }

        static void DrawChoice(Choice choice, Rect rect)
        {
            int index = choice.Get();
            if (index < 0)
                index = 0;
            if (index >= choice.Labels.Length)
                index = choice.Labels.Length - 1;
            GUI.Label(new Rect(rect.x, rect.y, 250f, 28f), choice.Title, rowStyle);
            if (GUI.Button(new Rect(rect.x + 254f, rect.y, 32f, 28f), "<", buttonStyle))
                Change(choice, index - 1);
            GUI.Label(new Rect(rect.x + 292f, rect.y, rect.width - 370f, 28f), choice.Labels[index], valueStyle);
            if (GUI.Button(new Rect(rect.x + rect.width - 40f, rect.y, 32f, 28f), ">", buttonStyle))
                Change(choice, index + 1);
        }

        static void Change(Choice choice, int index)
        {
            if (index < 0)
                index = choice.Labels.Length - 1;
            if (index >= choice.Labels.Length)
                index = 0;
            if (choice.Mode)
            {
                if (PerfPlugin.Instance != null)
                    PerfPlugin.Instance.SetOptimization(index != 0);
                return;
            }
            if (choice.KeepPreset)
            {
                choice.Set(index);
                return;
            }
            if (choice.Preset)
            {
                choice.Set(index);
                GraphicsApply.ApplyNow();
                return;
            }
            choice.Set(index);
            if (!choice.KeepPreset)
                PerfPlugin.Preset.Value = 4;
            PerfPlugin.Tune.Pull();
            GraphicsApply.ApplyNow();
        }

        static void EnsureChoices()
        {
            if (choices != null)
                return;
            choices = new List<Choice>();
            var mode = Make(false, "Режим", "Mode",
                new[] { "Как без мода", "С оптимизацией" },
                new[] { "Vanilla", "Optimized" },
                delegate { return PerfPlugin.Tune.Bypass ? 0 : 1; },
                delegate(int index) { PerfPlugin.Bypass.Value = index == 0; });
            mode.Mode = true;
            choices.Add(mode);
            choices.Add(Make(true, "Профиль", "Preset",
                new[] { "Максимум", "Лучший баланс", "Минимум", "Своё" },
                new[] { "Maximum", "Best balance", "Minimum", "Custom" },
                delegate { return Array.IndexOf(PresetOrder, PerfPlugin.Tune.Preset); },
                delegate(int index) { GraphicsPresets.Write(PresetOrder[index]); }));
            choices.Add(Make(false, "Текстуры", "Textures",
                new[] { "Высокие", "Средние", "Низкие", "Очень низкие" },
                new[] { "High", "Medium", "Low", "Very low" },
                delegate { return PerfPlugin.Tune.TextureLimit; },
                delegate(int index) { PerfPlugin.TextureLimit.Value = index; }));
            choices.Add(Make(false, "Дальность теней", "Shadow distance",
                new[] { "Как в игре", "25 м", "40 м", "70 м", "110 м", "180 м" },
                new[] { "Game", "25 m", "40 m", "70 m", "110 m", "180 m" },
                delegate { return PerfPlugin.Tune.ShadowMeters; },
                delegate(int index) { PerfPlugin.ShadowMeters.Value = index; }));
            choices.Add(Make(false, "Тени", "Shadows",
                new[] { "Выкл", "Жёсткие", "Все" },
                new[] { "Off", "Hard", "All" },
                delegate { return PerfPlugin.Tune.ShadowMode; },
                delegate(int index) { PerfPlugin.ShadowMode.Value = index; }));
            choices.Add(Make(false, "Разрешение теней", "Shadow resolution",
                new[] { "Низкое", "Среднее", "Высокое", "Очень высокое" },
                new[] { "Low", "Medium", "High", "Very high" },
                delegate { return PerfPlugin.Tune.ShadowRes; },
                delegate(int index) { PerfPlugin.ShadowRes.Value = index; }));
            choices.Add(Make(false, "Каскады теней", "Shadow cascades",
                new[] { "1", "2", "4" },
                new[] { "1", "2", "4" },
                delegate { return PerfPlugin.Tune.Cascades; },
                delegate(int index) { PerfPlugin.Cascades.Value = index; }));
            choices.Add(Make(false, "Дальность обзора", "View distance",
                new[] { "Как в игре", "500", "900", "1400", "2200" },
                new[] { "Game", "500", "900", "1400", "2200" },
                delegate { return PerfPlugin.Tune.FarClip; },
                delegate(int index) { PerfPlugin.FarClip.Value = index; }));
            choices.Add(Make(false, "LOD персонажей", "Character LOD",
                new[] { "Выкл", "Мягко", "Сильно" },
                new[] { "Off", "Gentle", "Strong" },
                delegate { return PerfPlugin.Tune.CharacterLod; },
                delegate(int index) { PerfPlugin.CharacterLod.Value = index; }));
            choices.Add(Make(false, "LOD мелочи", "Small object LOD",
                new[] { "Выкл", "Мягко", "Сильно" },
                new[] { "Off", "Gentle", "Strong" },
                delegate { return PerfPlugin.Tune.PropLod; },
                delegate(int index) { PerfPlugin.PropLod.Value = index; }));
            choices.Add(Make(false, "Детализация", "LOD",
                new[] { "Низкая", "Ниже", "Обычная", "Выше", "Высокая" },
                new[] { "Low", "Lower", "Normal", "Higher", "High" },
                delegate { return PerfPlugin.Tune.Lod; },
                delegate(int index) { PerfPlugin.Lod.Value = index; }));
            choices.Add(Make(false, "Источники света", "Pixel lights",
                new[] { "0", "1", "2", "4" },
                new[] { "0", "1", "2", "4" },
                delegate { return PerfPlugin.Tune.PixelLights; },
                delegate(int index) { PerfPlugin.PixelLights.Value = index; }));
            choices.Add(Make(false, "Анизотропия", "Anisotropic",
                new[] { "Выкл", "Вкл", "Принудительно" },
                new[] { "Off", "On", "Force" },
                delegate { return PerfPlugin.Tune.Aniso; },
                delegate(int index) { PerfPlugin.Aniso.Value = index; }));
            choices.Add(Bool("Мягкие частицы", "Soft particles", delegate { return PerfPlugin.Tune.SoftParticles; }, delegate(bool value) { PerfPlugin.SoftParticles.Value = value; }));
            choices.Add(Bool("Мягкая трава", "Soft vegetation", delegate { return PerfPlugin.Tune.SoftVegetation; }, delegate(bool value) { PerfPlugin.SoftVegetation.Value = value; }));
            choices.Add(Bool("Отражения", "Reflections", delegate { return PerfPlugin.Tune.RealtimeProbes; }, delegate(bool value) { PerfPlugin.RealtimeProbes.Value = value; }));
            choices.Add(Bool("Тяжёлые эффекты", "Heavy effects", delegate { return PerfPlugin.Tune.HeavyEffects; }, delegate(bool value) { PerfPlugin.HeavyEffects.Value = value; }));
            choices.Add(Bool("Свечение", "Bloom", delegate { return PerfPlugin.Tune.BloomOn; }, delegate(bool value) { PerfPlugin.BloomOn.Value = value; }));
            choices.Add(Bool("Тени только от солнца", "Sun shadows only", delegate { return PerfPlugin.Tune.SunOnlyShadows; }, delegate(bool value) { PerfPlugin.SunOnlyShadows.Value = value; }));
            choices.Add(Make(false, "Дальность травы", "Grass distance",
                new[] { "Как в игре", "80%", "65%", "50%", "35%" },
                new[] { "Game", "80%", "65%", "50%", "35%" },
                delegate { return PerfPlugin.Tune.GrassDistance; },
                delegate(int index) { PerfPlugin.GrassDistanceMode.Value = index; }));
            choices.Add(Make(false, "Плотность травы", "Grass density",
                new[] { "Как в игре", "80%", "60%", "40%" },
                new[] { "Game", "80%", "60%", "40%" },
                delegate { return PerfPlugin.Tune.GrassDensity; },
                delegate(int index) { PerfPlugin.GrassDensityMode.Value = index; }));
            choices.Add(Make(false, "Облака", "Clouds",
                new[] { "Как в игре", "Высокие", "Средние", "Низкие", "Плоские" },
                new[] { "Game", "High", "Medium", "Low", "Flat" },
                delegate { return PerfPlugin.Tune.Clouds; },
                delegate(int index) { PerfPlugin.CloudsMode.Value = index; }));
            choices.Add(Make(false, "Объёмный свет", "Volumetric light",
                new[] { "Как в игре", "Половина", "Четверть", "Выкл" },
                new[] { "Game", "Half", "Quarter", "Off" },
                delegate { return PerfPlugin.Tune.VolumeLight; },
                delegate(int index) { PerfPlugin.VolumeLightMode.Value = index; }));
            choices.Add(Make(false, "Тени мелочи", "Small object shadows",
                new[] { "Как в игре", "До 20 м", "До 35 м", "До 50 м" },
                new[] { "Game", "To 20 m", "To 35 m", "To 50 m" },
                delegate { return PerfPlugin.Tune.SmallShadows; },
                delegate(int index) { PerfPlugin.SmallShadowsMode.Value = index; }));
            choices.Add(Make(false, "Ландшафт", "Terrain",
                new[] { "Близко", "Средне", "Далеко", "Как в игре" },
                new[] { "Near", "Medium", "Far", "Game" },
                delegate { return PerfPlugin.Tune.TerrainDetail; },
                delegate(int index) { PerfPlugin.TerrainDetail.Value = index; }));
            choices.Add(Make(false, "Частицы вдали", "Distant particles",
                new[] { "Не трогать", "25 м", "45 м", "80 м" },
                new[] { "Leave", "25 m", "45 m", "80 m" },
                delegate { return PerfPlugin.Tune.ParticleCull; },
                delegate(int index) { PerfPlugin.ParticleCull.Value = index; }));
            choices.Add(Make(false, "Столкновения частиц", "Particle collisions",
                new[] { "4", "16", "64", "256" },
                new[] { "4", "16", "64", "256" },
                delegate { return PerfPlugin.Tune.ParticleBudget; },
                delegate(int index) { PerfPlugin.ParticleBudget.Value = index; }));
            choices.Add(Bool("Потоковые текстуры", "Texture streaming", delegate { return PerfPlugin.Tune.StreamingMips; }, delegate(bool value) { PerfPlugin.StreamingMips.Value = value; }));
            choices.Add(Make(false, "Отражения воды", "Water reflections",
                new[] { "Выкл", "Как в игре", "128", "256", "512" },
                new[] { "Off", "Game", "128", "256", "512" },
                WaterIndex,
                delegate(int index)
                {
                    int[] values = { -1, 0, 128, 256, 512 };
                    PerfPlugin.WaterReflectionSize.Value = values[index];
                }));
            var probes = Make(false, "Отражения окружения", "Environment reflections",
                new[] { "Как в игре", "Раз в 0,5 с", "Раз в 2 с" },
                new[] { "Game", "Every 0.5 s", "Every 2 s" },
                delegate { return PerfPlugin.Tune.ProbeUpdate; },
                delegate(int index) { PerfPlugin.ProbeUpdateMode.Value = index; });
            probes.KeepPreset = true;
            choices.Add(probes);
            choices.Add(Make(false, "Обновление отражений воды", "Water reflection updates",
                new[] { "Каждый кадр", "Через кадр", "Каждый 3-й кадр" },
                new[] { "Every frame", "Every 2nd frame", "Every 3rd frame" },
                delegate { return PerfPlugin.Tune.WaterUpdate; },
                delegate(int index) { PerfPlugin.WaterUpdateMode.Value = index; }));
            choices.Add(Make(false, "Карточки растений", "Plant cards",
                new[] { "Каждый кадр", "Когда камера движется", "Реже" },
                new[] { "Every frame", "While camera moves", "Less often" },
                delegate { return PerfPlugin.Tune.VegetationMode; },
                delegate(int index) { PerfPlugin.VegetationMode.Value = index; }));
            choices.Add(Bool("Визуальный LOD зомби", "Zombie visual LOD", delegate { return PerfPlugin.Tune.DistanceLod; }, delegate(bool value) { PerfPlugin.DistanceLod.Value = value; }));
            choices.Add(Make(false, "Тени зомби", "Zombie shadows",
                new[] { "Как в игре", "До 25 м", "До 45 м", "До 80 м" },
                new[] { "Game", "To 25 m", "To 45 m", "To 80 m" },
                delegate { return Mathf.Min(PerfPlugin.Tune.ZombieShadowMode, 3); },
                delegate(int index) { PerfPlugin.ZombieShadowMode.Value = index; }));
            choices.Add(Make(false, "Поворот голов", "Head tracking",
                new[] { "Как в игре", "До 12 м", "До 22 м", "До 40 м" },
                new[] { "Game", "To 12 m", "To 22 m", "To 40 m" },
                delegate { return PerfPlugin.Tune.HeadMode; },
                delegate(int index) { PerfPlugin.HeadMode.Value = index; }));
            choices.Add(Bool("Избегание зомби", "Zombie avoidance", delegate { return PerfPlugin.Tune.NavAvoidance; }, delegate(bool value) { PerfPlugin.NavAvoidance.Value = value; }));
            choices.Add(Bool("Анимация за кадром", "Offscreen animation", delegate { return PerfPlugin.Tune.AnimatorCulling; }, delegate(bool value) { PerfPlugin.AnimatorCulling.Value = value; }));
            var scale = Make(false, "Масштаб рендера", "Render scale",
                new[] { "100%", "90%", "85%", "77% (ультра-качество)", "67% (качество)", "59% (баланс)", "50% (производительность)", "Авто по FPS" },
                new[] { "100%", "90%", "85%", "77% (Ultra quality)", "67% (Quality)", "59% (Balanced)", "50% (Performance)", "Auto by FPS" },
                delegate { return Array.IndexOf(ScaleOrder, PerfPlugin.Tune.RenderScale); },
                delegate(int index) { PerfPlugin.RenderScaleIndex.Value = ScaleOrder[index]; });
            scale.KeepPreset = true;
            choices.Add(scale);
            var upscaler = Make(false, "Растяжка", "Upscaler",
                new[] { "FSR 1", "Простая" },
                new[] { "FSR 1", "Bilinear" },
                delegate { return PerfPlugin.Tune.Upscaler; },
                delegate(int index) { PerfPlugin.Upscaler.Value = index; });
            upscaler.KeepPreset = true;
            choices.Add(upscaler);
            var sharpness = Make(false, "Резкость FSR", "FSR sharpness",
                new[] { "Низкая", "Средняя", "Высокая" },
                new[] { "Low", "Medium", "High" },
                delegate { return PerfPlugin.Tune.Sharpness; },
                delegate(int index) { PerfPlugin.Sharpness.Value = index; });
            sharpness.KeepPreset = true;
            choices.Add(sharpness);
            var antialiasing = Make(false, "Сглаживание", "Anti-aliasing",
                new[] { "Как в игре", "Выкл", "FXAA", "SMAA", "TAA" },
                new[] { "Game", "Off", "FXAA", "SMAA", "TAA" },
                delegate { return PerfPlugin.Tune.AntiAliasing; },
                delegate(int index) { PerfPlugin.AntiAliasingMode.Value = index; });
            antialiasing.KeepPreset = true;
            choices.Add(antialiasing);
            var target = Make(false, "Цель авто-масштаба", "Auto scale target",
                new[] { "45 FPS", "60 FPS", "75 FPS", "90 FPS", "120 FPS", "144 FPS" },
                new[] { "45 FPS", "60 FPS", "75 FPS", "90 FPS", "120 FPS", "144 FPS" },
                delegate { return PerfPlugin.Tune.TargetFps; },
                delegate(int index) { PerfPlugin.TargetFps.Value = index; });
            target.KeepPreset = true;
            choices.Add(target);
            var sharpen = Bool("Резкость при 100%", "Sharpen at 100%", delegate { return PerfPlugin.Tune.Sharpen; }, delegate(bool value) { PerfPlugin.Sharpen.Value = value; });
            sharpen.KeepPreset = true;
            choices.Add(sharpen);
            var mip = Bool("Чёткие текстуры при FSR", "Sharp textures with FSR", delegate { return PerfPlugin.Tune.MipBias; }, delegate(bool value) { PerfPlugin.MipBias.Value = value; });
            mip.KeepPreset = true;
            choices.Add(mip);
        }

        // Menu position -> RenderScale config value (see RenderScale.Scales).
        static readonly int[] ScaleOrder = { 0, 6, 7, 1, 2, 3, 4, 5 };
        // Menu position -> Preset config value.
        static readonly int[] PresetOrder = { 1, 5, 3, 4 };

        static int WaterIndex()
        {
            int value = PerfPlugin.Tune.WaterReflectionSize;
            if (value < 0)
                return 0;
            if (value == 0)
                return 1;
            if (value <= 128)
                return 2;
            if (value <= 256)
                return 3;
            return 4;
        }

        static Choice Make(bool preset, string ru, string en, string[] ruLabels, string[] enLabels, Func<int> get, Action<int> set)
        {
            var choice = new Choice();
            choice.Preset = preset;
            choice.Title = russian ? ru : en;
            choice.Labels = russian ? ruLabels : enLabels;
            choice.Get = get;
            choice.Set = set;
            return choice;
        }

        static Choice Bool(string ru, string en, Func<bool> get, Action<bool> set)
        {
            return Make(false, ru, en,
                new[] { "Выкл", "Вкл" },
                new[] { "Off", "On" },
                delegate { return get() ? 1 : 0; },
                delegate(int index) { set(index == 1); });
        }
    }
}
