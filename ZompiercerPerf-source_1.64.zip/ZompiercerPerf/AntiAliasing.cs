using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

namespace ZompiercerPerf
{
    // Anti-aliasing of the game's PostProcessLayer (post-processing v2), the same field the game's
    // own TAA toggle writes (VideoSettings.SetTAA). The game rewrites it on video apply and when the
    // character spawns; its value then becomes the original, and the mod's choice is applied again.
    static class AntiAliasing
    {
        sealed class Saved
        {
            public PostProcessLayer Layer;
            public PostProcessLayer.Antialiasing Original, Applied;
        }

        static readonly List<Saved> Layers = new List<Saved>();
        static float nextScan, nextApply;

        // Config: 0 as in the game, 1 off, 2 FXAA, 3 SMAA, 4 TAA.
        public static void Tick()
        {
            var tune = PerfPlugin.Tune;
            int mode = tune.Bypass || tune.Preset == 0 ? 0 : tune.AntiAliasing;
            if (mode == 0)
            {
                Restore();
                return;
            }
            float now = Time.unscaledTime;
            if (now >= nextScan)
            {
                nextScan = now + 5f;
                Layers.RemoveAll(saved => saved.Layer == null);
                foreach (var layer in Object.FindObjectsOfType<PostProcessLayer>())
                    if (!Known(layer))
                        Layers.Add(new Saved { Layer = layer, Original = layer.antialiasingMode, Applied = layer.antialiasingMode });
            }
            if (now < nextApply)
                return;
            nextApply = now + .5f;
            var wanted = (PostProcessLayer.Antialiasing)(mode - 1);
            foreach (var saved in Layers)
            {
                if (saved.Layer == null)
                    continue;
                var current = saved.Layer.antialiasingMode;
                if (current != saved.Applied)
                    saved.Original = current; // the game applied its own setting meanwhile
                if (current != wanted)
                    saved.Layer.antialiasingMode = wanted;
                saved.Applied = wanted;
            }
        }

        static bool Known(PostProcessLayer layer)
        {
            foreach (var saved in Layers)
                if (saved.Layer == layer)
                    return true;
            return false;
        }

        public static void Restore()
        {
            foreach (var saved in Layers)
                if (saved.Layer != null && saved.Layer.antialiasingMode == saved.Applied)
                    saved.Layer.antialiasingMode = saved.Original;
            Layers.Clear();
            nextScan = nextApply = 0f;
        }

        public static string Describe()
        {
            foreach (var saved in Layers)
                if (saved.Layer != null)
                    return "сглаживание " + Name(saved.Layer.antialiasingMode);
            return "";
        }

        static string Name(PostProcessLayer.Antialiasing mode)
        {
            switch (mode)
            {
                case PostProcessLayer.Antialiasing.FastApproximateAntialiasing: return "FXAA";
                case PostProcessLayer.Antialiasing.SubpixelMorphologicalAntialiasing: return "SMAA";
                case PostProcessLayer.Antialiasing.TemporalAntialiasing: return "TAA";
                default: return "выкл";
            }
        }
    }
}
