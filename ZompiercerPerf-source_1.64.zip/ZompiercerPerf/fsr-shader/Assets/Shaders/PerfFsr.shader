// AMD FidelityFX Super Resolution 1.0 (EASU + RCAS), 32-bit float path.
// Port of ffx_fsr1.h for Unity's built-in pipeline. Original: Copyright (c) 2021 Advanced Micro Devices, Inc.
// MIT license, see LICENSE-FSR.txt next to the mod DLL.
Shader "Hidden/ZompiercerPerf/FSR"
{
    Properties { _MainTex ("Source", 2D) = "black" {} }

    CGINCLUDE
    #include "UnityCG.cginc"

    Texture2D _MainTex;
    SamplerState sampler_MainTex;
    float4 _Con0, _Con1, _Con2, _Con3; // FsrEasuCon
    float4 _OutSize;                  // output width, height, 1/width, 1/height
    float _Linear;                    // 1: textures hold linear values (linear color space)
    float _Sharpness;                 // RCAS: exp2(-stops)

    // FSR expects perceptual input: sRGB render targets return linear values in linear color space.
    float4 ToGamma4(float4 c) { return _Linear > 0.5 ? float4(LinearToGammaSpaceExact(c.x), LinearToGammaSpaceExact(c.y), LinearToGammaSpaceExact(c.z), LinearToGammaSpaceExact(c.w)) : c; }
    float3 ToLinear(float3 c) { return _Linear > 0.5 ? GammaToLinearSpace(c) : c; }

    // ---------------------------------------------------------------- EASU
    void EasuSet(inout float2 dir, inout float len, float2 pp, bool biS, bool biT, bool biU, bool biV,
        float lA, float lB, float lC, float lD, float lE)
    {
        // Bilinear weight of this 2x2 quad position, '+' pattern around lC:
        //    a
        //  b c d
        //    e
        float w = 0;
        if (biS) w = (1 - pp.x) * (1 - pp.y);
        if (biT) w = pp.x * (1 - pp.y);
        if (biU) w = (1 - pp.x) * pp.y;
        if (biV) w = pp.x * pp.y;
        float dc = lD - lC;
        float cb = lC - lB;
        float lenX = max(abs(dc), abs(cb));
        lenX = rcp(max(lenX, 1e-8));
        float dirX = lD - lB;
        dir.x += dirX * w;
        lenX = saturate(abs(dirX) * lenX);
        lenX *= lenX;
        len += lenX * w;
        float ec = lE - lC;
        float ca = lC - lA;
        float lenY = max(abs(ec), abs(ca));
        lenY = rcp(max(lenY, 1e-8));
        float dirY = lE - lA;
        dir.y += dirY * w;
        lenY = saturate(abs(dirY) * lenY);
        lenY *= lenY;
        len += lenY * w;
    }

    void EasuTap(inout float3 aC, inout float aW, float2 off, float2 dir, float2 len, float lob, float clp, float3 c)
    {
        float2 v;
        v.x = (off.x * dir.x) + (off.y * dir.y);
        v.y = (off.x * (-dir.y)) + (off.y * dir.x);
        v *= len;
        float d2 = v.x * v.x + v.y * v.y;
        d2 = min(d2, clp);
        // (25/16 * (2/5 * x^2 - 1)^2 - (25/16 - 1)) * (1/4 * x^2 - 1)^2 approximation of lanczos2
        float wB = (2.0 / 5.0) * d2 - 1;
        float wA = lob * d2 - 1;
        wB *= wB;
        wA *= wA;
        wB = (25.0 / 16.0) * wB - (25.0 / 16.0 - 1.0);
        float w = wB * wA;
        aC += c * w;
        aW += w;
    }

    float4 FragEasu(v2f_img i) : SV_Target
    {
        float2 ip = floor(i.uv * _OutSize.xy);
        float2 pp = ip * _Con0.xy + _Con0.zw;
        float2 fp = floor(pp);
        pp -= fp;
        // 12-tap kernel around F:
        //    b c
        //  e f g h
        //  i j k l
        //    n o
        float2 p0 = fp * _Con1.xy + _Con1.zw;
        float2 p1 = p0 + _Con2.xy;
        float2 p2 = p0 + _Con2.zw;
        float2 p3 = p0 + _Con3.xy;
        float4 bczzR = ToGamma4(_MainTex.GatherRed(sampler_MainTex, p0));
        float4 bczzG = ToGamma4(_MainTex.GatherGreen(sampler_MainTex, p0));
        float4 bczzB = ToGamma4(_MainTex.GatherBlue(sampler_MainTex, p0));
        float4 ijfeR = ToGamma4(_MainTex.GatherRed(sampler_MainTex, p1));
        float4 ijfeG = ToGamma4(_MainTex.GatherGreen(sampler_MainTex, p1));
        float4 ijfeB = ToGamma4(_MainTex.GatherBlue(sampler_MainTex, p1));
        float4 klhgR = ToGamma4(_MainTex.GatherRed(sampler_MainTex, p2));
        float4 klhgG = ToGamma4(_MainTex.GatherGreen(sampler_MainTex, p2));
        float4 klhgB = ToGamma4(_MainTex.GatherBlue(sampler_MainTex, p2));
        float4 zzonR = ToGamma4(_MainTex.GatherRed(sampler_MainTex, p3));
        float4 zzonG = ToGamma4(_MainTex.GatherGreen(sampler_MainTex, p3));
        float4 zzonB = ToGamma4(_MainTex.GatherBlue(sampler_MainTex, p3));
        // Luma times 2.
        float4 bczzL = bczzB * 0.5 + (bczzR * 0.5 + bczzG);
        float4 ijfeL = ijfeB * 0.5 + (ijfeR * 0.5 + ijfeG);
        float4 klhgL = klhgB * 0.5 + (klhgR * 0.5 + klhgG);
        float4 zzonL = zzonB * 0.5 + (zzonR * 0.5 + zzonG);
        float bL = bczzL.x, cL = bczzL.y;
        float iL = ijfeL.x, jL = ijfeL.y, fL = ijfeL.z, eL = ijfeL.w;
        float kL = klhgL.x, lL = klhgL.y, hL = klhgL.z, gL = klhgL.w;
        float oL = zzonL.z, nL = zzonL.w;
        float2 dir = 0;
        float len = 0;
        EasuSet(dir, len, pp, true, false, false, false, bL, eL, fL, gL, jL);
        EasuSet(dir, len, pp, false, true, false, false, cL, fL, gL, hL, kL);
        EasuSet(dir, len, pp, false, false, true, false, fL, iL, jL, kL, nL);
        EasuSet(dir, len, pp, false, false, false, true, gL, jL, kL, lL, oL);
        // Normalize with approximation, and cleanup close to zero.
        float2 dir2 = dir * dir;
        float dirR = dir2.x + dir2.y;
        bool zro = dirR < (1.0 / 32768.0);
        dirR = rsqrt(max(dirR, 1e-12));
        dirR = zro ? 1 : dirR;
        dir.x = zro ? 1 : dir.x;
        dir *= dirR;
        // Transform from {0 to 2} to {0 to 1} range, and shape with square.
        len = len * 0.5;
        len *= len;
        // Stretch kernel {1.0 vert|horz, to sqrt(2.0) on diagonal}.
        float stretch = (dir.x * dir.x + dir.y * dir.y) * rcp(max(abs(dir.x), abs(dir.y)));
        // Anisotropic length after rotation: x up to 'stretch', y down to 0.5 on edges.
        float2 len2 = float2(1 + (stretch - 1) * len, 1 - 0.5 * len);
        // Negative lobe strength from 0.5 (no edge) to 0.21 (edge).
        float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;
        float clp = rcp(lob);
        float3 b = float3(bczzR.x, bczzG.x, bczzB.x);
        float3 c = float3(bczzR.y, bczzG.y, bczzB.y);
        float3 iC = float3(ijfeR.x, ijfeG.x, ijfeB.x);
        float3 j = float3(ijfeR.y, ijfeG.y, ijfeB.y);
        float3 f = float3(ijfeR.z, ijfeG.z, ijfeB.z);
        float3 e = float3(ijfeR.w, ijfeG.w, ijfeB.w);
        float3 k = float3(klhgR.x, klhgG.x, klhgB.x);
        float3 l = float3(klhgR.y, klhgG.y, klhgB.y);
        float3 h = float3(klhgR.z, klhgG.z, klhgB.z);
        float3 g = float3(klhgR.w, klhgG.w, klhgB.w);
        float3 o = float3(zzonR.z, zzonG.z, zzonB.z);
        float3 n = float3(zzonR.w, zzonG.w, zzonB.w);
        // Deringing range of the 2x2 nearest.
        float3 min4 = min(min(f, g), min(j, k));
        float3 max4 = max(max(f, g), max(j, k));
        float3 aC = 0;
        float aW = 0;
        EasuTap(aC, aW, float2( 0, -1) - pp, dir, len2, lob, clp, b);
        EasuTap(aC, aW, float2( 1, -1) - pp, dir, len2, lob, clp, c);
        EasuTap(aC, aW, float2(-1,  1) - pp, dir, len2, lob, clp, iC);
        EasuTap(aC, aW, float2( 0,  1) - pp, dir, len2, lob, clp, j);
        EasuTap(aC, aW, float2( 0,  0) - pp, dir, len2, lob, clp, f);
        EasuTap(aC, aW, float2(-1,  0) - pp, dir, len2, lob, clp, e);
        EasuTap(aC, aW, float2( 1,  1) - pp, dir, len2, lob, clp, k);
        EasuTap(aC, aW, float2( 2,  1) - pp, dir, len2, lob, clp, l);
        EasuTap(aC, aW, float2( 2,  0) - pp, dir, len2, lob, clp, h);
        EasuTap(aC, aW, float2( 1,  0) - pp, dir, len2, lob, clp, g);
        EasuTap(aC, aW, float2( 1,  2) - pp, dir, len2, lob, clp, o);
        EasuTap(aC, aW, float2( 0,  2) - pp, dir, len2, lob, clp, n);
        float3 pix = min(max4, max(min4, aC * rcp(aW)));
        // Stays in perceptual space for RCAS (the intermediate texture is not sRGB).
        return float4(pix, 1);
    }

    // ---------------------------------------------------------------- RCAS
    #define FSR_RCAS_LIMIT (0.25 - (1.0 / 16.0))

    float4 FragRcas(v2f_img i) : SV_Target
    {
        int2 ip = int2(floor(i.uv * _OutSize.xy));
        int2 mx = int2(_OutSize.xy) - 1;
        //    b
        //  d e f
        //    h
        float3 b = _MainTex.Load(int3(clamp(ip + int2( 0, -1), 0, mx), 0)).rgb;
        float3 d = _MainTex.Load(int3(clamp(ip + int2(-1,  0), 0, mx), 0)).rgb;
        float3 e = _MainTex.Load(int3(ip, 0)).rgb;
        float3 f = _MainTex.Load(int3(clamp(ip + int2( 1,  0), 0, mx), 0)).rgb;
        float3 h = _MainTex.Load(int3(clamp(ip + int2( 0,  1), 0, mx), 0)).rgb;
        // Luma times 2.
        float bL = b.b * 0.5 + (b.r * 0.5 + b.g);
        float dL = d.b * 0.5 + (d.r * 0.5 + d.g);
        float eL = e.b * 0.5 + (e.r * 0.5 + e.g);
        float fL = f.b * 0.5 + (f.r * 0.5 + f.g);
        float hL = h.b * 0.5 + (h.r * 0.5 + h.g);
        // Noise detection.
        float nz = 0.25 * bL + 0.25 * dL + 0.25 * fL + 0.25 * hL - eL;
        float range = max(max(max(bL, dL), max(eL, fL)), hL) - min(min(min(bL, dL), min(eL, fL)), hL);
        nz = saturate(abs(nz) * rcp(max(range, 1e-5)));
        nz = -0.5 * nz + 1.0;
        // Min and max of ring.
        float3 mn4 = min(min(b, d), min(f, h));
        float3 mx4 = max(max(b, d), max(f, h));
        // Limiters, these need to be high precision RCPs.
        float2 peakC = float2(1.0, -1.0 * 4.0);
        float3 hitMin = min(mn4, e) * rcp(max(4.0 * mx4, 1e-5));
        float3 hitMax = (peakC.x - max(mx4, e)) * rcp(min(4.0 * mn4 + peakC.y, -1e-5));
        float3 lobeRGB = max(-hitMin, hitMax);
        float lobe = max(-FSR_RCAS_LIMIT, min(max(max(lobeRGB.r, lobeRGB.g), lobeRGB.b), 0.0)) * _Sharpness;
        lobe *= nz;
        float rcpL = rcp(4.0 * lobe + 1.0);
        float3 pix = (lobe * b + lobe * d + lobe * h + lobe * f + e) * rcpL;
        return float4(ToLinear(saturate(pix)), 1);
    }
    ENDCG

    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass // 0: EASU, low-resolution scene -> output-size intermediate
        {
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment FragEasu
            #pragma target 5.0
            ENDCG
        }
        Pass // 1: RCAS, intermediate -> screen
        {
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment FragRcas
            #pragma target 5.0
            ENDCG
        }
    }
    Fallback Off
}
