using System.IO;
using UnityEditor;
using UnityEngine.Rendering;

// Batch mode: Unity.exe -batchmode -quit -projectPath fsr-shader -executeMethod BuildFsrBundle.Build -logFile build.log
public static class BuildFsrBundle
{
    const string Output = "Build";

    public static void Build()
    {
        // Variants for every API a Windows player of the game may run on (DX11 is the game's default).
        PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.StandaloneWindows64, false);
        PlayerSettings.SetGraphicsAPIs(BuildTarget.StandaloneWindows64, new[] {
            GraphicsDeviceType.Direct3D11, GraphicsDeviceType.Direct3D12,
            GraphicsDeviceType.Vulkan, GraphicsDeviceType.OpenGLCore });
        Directory.CreateDirectory(Output);
        var build = new AssetBundleBuild {
            assetBundleName = "zompiercerperf-fsr.bundle",
            assetNames = new[] { "Assets/Shaders/PerfFsr.shader" }
        };
        var manifest = BuildPipeline.BuildAssetBundles(Output, new[] { build },
            BuildAssetBundleOptions.ChunkBasedCompression | BuildAssetBundleOptions.StrictMode,
            BuildTarget.StandaloneWindows64);
        // 2020.1 in batch mode once stayed alive after the build and kept growing until Windows crashed:
        // leave explicitly instead of relying on -quit.
        EditorApplication.Exit(manifest == null ? 1 : 0);
    }
}
