using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace ZompiercerPerf
{
    // Visual ownership only: original meshes, shared materials and all colliders remain untouched.
    static class WorldLod
    {
        sealed class Visual
        {
            public Renderer Renderer;
            public Material[] Original, Fades;
            public bool Hidden, UsingFade, Hard;
            public float Alpha = 1f;
            public int Queue = 3008;
        }
        sealed class Prop
        {
            public int Id;
            public Visual High, Low;
            public MeshFilter Filter;
            public Mesh Mesh;
            public Transform Parent;
            public float Near, Far, Shown = 1f, Detail;
            public bool Live, TriedMesh;
        }
        sealed class NativeGroup
        {
            public int Id;
            public LODGroup Group;
            public LOD[] Lods;
            public Visual[] Visuals;
            public float[] Weights;
            public float[] Thresholds;
            public int Level;
            public Transform Parent;
        }
        const int MaxProps = 4096, MaxGenerated = 256;
        const float FadeSeconds = .65f;
        static readonly List<Prop> Props = new List<Prop>();
        static readonly HashSet<int> Ids = new HashSet<int>();
        static readonly List<Prop> Live = new List<Prop>();
        static readonly Stack<Transform> Scan = new Stack<Transform>();
        static readonly List<NativeGroup> Groups = new List<NativeGroup>();
        static readonly HashSet<int> GroupIds = new HashSet<int>();
        static readonly HashSet<Renderer> GroupRenderers = new HashSet<Renderer>();
        static int cursor, liveCursor, groupCursor, generated;
        static float nextScan, nextMesh;
        static bool active;

        public static void Tick()
        {
            var manager = GlobalManager.global;
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0 || PerfPlugin.Tune.PropLod == 0
                || manager == null || manager.controlledChar == null)
            { Restore(); return; }
            active = true;
            var player = manager.controlledChar.GetTransform;
            if (player == null) player = manager.controlledChar.transform;
            StepScan(player.position);
            WatchSlice(player.position);
            RefreshLive(player.position);
            RefreshGroups();
        }
        public static void Restore()
        {
            if (!active) return;
            foreach (var prop in Props) Release(prop);
            foreach (var saved in Groups) ReleaseGroup(saved);
            Props.Clear(); Ids.Clear(); Live.Clear(); Scan.Clear(); Groups.Clear(); GroupIds.Clear(); GroupRenderers.Clear();
            ObjectMeshLod.Clear();
            cursor = liveCursor = groupCursor = generated = 0;
            nextScan = 0f;
            nextMesh = 0f;
            active = false;
        }
        static void StepScan(Vector3 origin)
        {
            if (Scan.Count == 0)
            {
                if (Time.unscaledTime < nextScan) return;
                nextScan = Time.unscaledTime + 3f;
                Prune();
                // Spread discovery over frames rather than scanning every renderer at once.
                for (int s = 0; s < SceneManager.sceneCount; s++)
                {
                    var scene = SceneManager.GetSceneAt(s);
                    if (!scene.isLoaded) continue;
                    foreach (var root in scene.GetRootGameObjects()) Scan.Push(root.transform);
                }
            }
            for (int n = 0; n < 96 && Scan.Count > 0; n++)
            {
                var node = Scan.Pop();
                if (node == null || !node.gameObject.activeInHierarchy || node.name == "__PerfObjectLOD") continue;
                for (int c = 0; c < node.childCount; c++) Scan.Push(node.GetChild(c));
                var group = node.GetComponent<LODGroup>();
                if (group != null) ConsiderGroup(group);
                var renderer = node.GetComponent<MeshRenderer>();
                if (renderer != null) Consider(renderer, origin);
            }
        }
        static void ConsiderGroup(LODGroup group)
        {
            if (!group.enabled || GroupIds.Contains(group.GetInstanceID()) || Protected(group) || Groups.Count >= 768) return;
            // SpeedTree already blends. Other groups are taken over, including ones whose
            // inactive levels the game has disabled — those were previously rejected entirely.
            if (group.fadeMode == LODFadeMode.SpeedTree) return;
            // GDOC occlusion culling and game scripts switch LOD renderers off themselves. Forcing them
            // on showed hidden models and made GDOC restore stale states (objects stayed invisible).
            var lods = group.GetLODs();
            if (lods.Length < 2 || lods.Length > 8) return;
            var visuals = new List<Visual>();
            var renderers = new HashSet<Renderer>();
            foreach (var lod in lods)
                foreach (var renderer in lod.renderers)
                {
                    if (renderer == null) continue;
                    if (!renderer.enabled || renderer.forceRenderingOff || Protected(renderer) || GroupRenderers.Contains(renderer)
                        || Ids.Contains(renderer.GetInstanceID()) || !renderers.Add(renderer))
                        return;
                    bool hard = !(renderer is MeshRenderer) || renderer.HasPropertyBlock() || !Supported(renderer.sharedMaterials);
                    visuals.Add(new Visual {
                        Renderer = renderer, Original = renderer.sharedMaterials, Alpha = -1f,
                        Hard = hard
                    });
                }
            if (visuals.Count == 0) return;
            var saved = new NativeGroup { Id = group.GetInstanceID(), Group = group, Lods = lods, Parent = group.transform.parent,
                Visuals = visuals.ToArray(), Weights = new float[lods.Length + 1], Thresholds = new float[lods.Length] };
            for (int i = 0; i < lods.Length; i++) saved.Thresholds[i] = lods[i].screenRelativeTransitionHeight;
            saved.Level = GroupLevel(saved);
            saved.Weights[saved.Level] = 1f; // the final slot explicitly represents native culling
            // Standard fades. Anything else in the same group switches on the active level,
            // so one incompatible renderer no longer drops the whole group back to a hard pop.
            group.enabled = false;
            ApplyGroup(saved);
            Groups.Add(saved); GroupIds.Add(saved.Id);
            foreach (var renderer in renderers) GroupRenderers.Add(renderer);
        }
        static bool Protected(Component component)
        {
            if (LanCompatibility.Owns(component) || component.GetComponentInParent<Zompiercer.Inventory.InventoryItem>() != null
                || component.GetComponentInParent<NPC>() != null || component.GetComponentInParent<Zompiercer.Train.TrainCar>() != null
                || component.GetComponentInParent<ZombieAIController>() != null || component.GetComponentInParent<Animator>() != null
                || component.GetComponentInParent<Rigidbody>() != null
                || component.GetComponentInParent<Bearroll.GDOC_Occludee>() != null) return true;
            var manager = GlobalManager.global;
            if (manager == null) return false;
            if (manager.controlledChar != null && component.transform.IsChildOf(manager.controlledChar.transform)) return true;
            return manager.MainCamera != null && component.transform.IsChildOf(manager.MainCamera.transform);
        }
        static bool Supported(Material[] materials)
        {
            if (materials == null || materials.Length == 0) return false;
            foreach (var mat in materials)
            {
                if (mat == null || mat.shader == null) return false;
                string shader = mat.shader.name;
                if (shader != "Standard" && shader != "Standard (Specular setup)") return false;
                // Custom shaders, wind, glass and cutout foliage retain their original rendering.
                if (!mat.HasProperty("_Mode") || mat.GetFloat("_Mode") != 0f) return false;
                if (mat.IsKeywordEnabled("_ALPHATEST_ON") || mat.IsKeywordEnabled("_ALPHABLEND_ON")
                    || mat.IsKeywordEnabled("_ALPHAPREMULTIPLY_ON")) return false;
                var texture = mat.GetTexture("_MainTex");
                // Standard's fade variant multiplies albedo alpha unless alpha is already used for smoothness.
                // Do not turn packed/unknown albedo alpha into unintended transparency during a transition.
                if (texture != null && !mat.IsKeywordEnabled("_SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A")
                    && UnityEngine.Experimental.Rendering.GraphicsFormatUtility.HasAlphaChannel(texture.graphicsFormat)) return false;
            }
            return true;
        }
        static void Consider(MeshRenderer renderer, Vector3 origin)
        {
            int id = renderer.GetInstanceID();
            if (Ids.Contains(id) || GroupRenderers.Contains(renderer) || !renderer.enabled || renderer.forceRenderingOff || Protected(renderer) || renderer.isPartOfStaticBatch
                || renderer.GetComponentInParent<LODGroup>() != null || renderer.HasPropertyBlock()) return;
            var materials = renderer.sharedMaterials;
            if (!Supported(materials)) return;
            var size = renderer.bounds.size;
            float largest = Mathf.Max(size.x, Mathf.Max(size.y, size.z));
            // Large scenery used to be ignored and then popped at the clip plane.
            if (largest < .03f || largest > 80f) return;
            float clip = 220f;
            var camera = Camera.main;
            if (camera != null) clip = Mathf.Max(80f, camera.farClipPlane * .92f);
            float upper = Mathf.Min(clip, Mathf.Max(220f, largest * 14f));
            float far = Mathf.Clamp(40f + largest * 18f, 45f, upper);
            if (Props.Count >= MaxProps && !MakeRoom(renderer.bounds.center)) return;
            var filter = renderer.GetComponent<MeshFilter>();
            var prop = new Prop { Id = id, High = new Visual { Renderer = renderer, Original = materials }, Parent = renderer.transform.parent,
                Near = far * .72f, Far = far, Filter = filter, Mesh = filter != null ? filter.sharedMesh : null };
            prop.Shown = Visibility(prop, Vector3.Distance(renderer.bounds.center, origin));
            Props.Add(prop); Ids.Add(id);
            ApplyAlpha(prop.High, prop.Shown);
        }
        static void WatchSlice(Vector3 origin)
        {
            int steps = Mathf.Min(160, Props.Count);
            for (int n = 0; n < steps && Props.Count > 0; n++)
            {
                if (cursor >= Props.Count) cursor = 0;
                var prop = Props[cursor];
                if (!Valid(prop, false)) { Forget(prop); continue; }
                cursor++;
                float distance = Vector3.Distance(prop.High.Renderer.bounds.center, origin);
                if (!prop.TriedMesh && generated < MaxGenerated && Time.unscaledTime >= nextMesh && distance < prop.Far)
                { nextMesh = Time.unscaledTime + .05f; BuildLow(prop); }
                float visibility = Visibility(prop, distance), detail = Detail(prop, distance);
                if (!prop.Live && (Mathf.Abs(visibility - prop.Shown) > .0001f || Mathf.Abs(detail - prop.Detail) > .0001f))
                { prop.Live = true; Live.Add(prop); }
            }
        }
        static void RefreshLive(Vector3 origin)
        {
            int steps = Mathf.Min(192, Live.Count);
            for (int n = 0; n < steps && Live.Count > 0; n++)
            {
                if (liveCursor >= Live.Count) liveCursor = 0;
                var prop = Live[liveCursor];
                if (!Valid(prop, false)) { Forget(prop); continue; }
                float distance = Vector3.Distance(prop.High.Renderer.bounds.center, origin);
                float target = Visibility(prop, distance), detail = Detail(prop, distance);
                prop.Shown = LodTransition.Step(prop.Shown, target, Time.unscaledDeltaTime, FadeSeconds);
                prop.Detail = LodTransition.Step(prop.Detail, detail, Time.unscaledDeltaTime, FadeSeconds);
                float front = prop.Shown * (1f - prop.Detail);
                ApplyAlpha(prop.High, front);
                if (prop.Low != null) ApplyAlpha(prop.Low, LodTransition.CompositeAlpha(prop.Shown * prop.Detail, front));
                if (prop.Shown == target && prop.Detail == detail)
                { prop.Live = false; Live.RemoveAt(liveCursor); }
                else liveCursor++;
            }
        }
        static float Visibility(Prop prop, float distance)
        {
            float scale = PerfPlugin.Tune.PropLod >= 2 ? .82f : 1f;
            return 1f - LodTransition.Weight(distance, prop.Near * scale, prop.Far * scale);
        }
        static float Detail(Prop prop, float distance)
        { return prop.Low == null ? 0f : (distance > prop.Far * (prop.Detail >= .5f ? .38f : .42f) ? 1f : 0f); }
        // Protected() walks the hierarchy several times; per frame it is repeated only after a reparent
        // (pick-up, carrying). The periodic prune repeats it for everything.
        static bool Valid(Prop prop, bool full)
        {
            var renderer = prop.High.Renderer;
            if (renderer == null) return false;
            var parent = renderer.transform.parent;
            if (parent != prop.Parent) { prop.Parent = parent; full = true; }
            return renderer.gameObject.activeInHierarchy && renderer.enabled
                && renderer.forceRenderingOff == prop.High.Hidden
                && !(full && Protected(renderer)) && !renderer.HasPropertyBlock()
                && Same(renderer.sharedMaterials, prop.High.UsingFade ? prop.High.Fades : prop.High.Original)
                && (prop.Filter == null || prop.Filter.sharedMesh == prop.Mesh);
        }
        static void BuildLow(Prop prop)
        {
            var source = prop.High.Renderer as MeshRenderer;
            if (source == null || prop.Mesh == null || source.additionalVertexStreams != null || source.isPartOfStaticBatch
                || source.lightmapIndex >= 0 && source.lightmapIndex < 65534)
            { prop.TriedMesh = true; return; }
            var mesh = ObjectMeshLod.GetReduced(prop.Mesh);
            prop.TriedMesh = ObjectMeshLod.IsComplete(prop.Mesh);
            // The worker may finish between the two calls; do not lose its completed result.
            if (mesh == null && prop.TriedMesh) mesh = ObjectMeshLod.GetReduced(prop.Mesh);
            if (mesh == null) return;
            var child = new GameObject("__PerfObjectLOD");
            child.hideFlags = HideFlags.DontSave;
            child.layer = source.gameObject.layer;
            child.transform.SetParent(source.transform, false);
            child.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = child.AddComponent<MeshRenderer>();
            renderer.forceRenderingOff = true;
            renderer.sharedMaterials = prop.High.Original;
            renderer.shadowCastingMode = source.shadowCastingMode;
            renderer.receiveShadows = source.receiveShadows;
            renderer.lightProbeUsage = source.lightProbeUsage;
            renderer.reflectionProbeUsage = source.reflectionProbeUsage;
            renderer.probeAnchor = source.probeAnchor;
            prop.Low = new Visual { Renderer = renderer, Original = prop.High.Original, Hidden = true, Alpha = 0f, Queue = 3007 };
            generated++;
        }
        static void ApplyAlpha(Visual visual, float alpha)
        {
            if (visual.Hard)
            {
                if (visual.Renderer == null) return;
                bool show = alpha >= .5f;
                if (visual.Alpha >= 0f && visual.Hidden == !show) return;
                visual.Renderer.forceRenderingOff = !show;
                visual.Hidden = !show;
                visual.Alpha = show ? 1f : 0f;
                return;
            }
            if (visual.Renderer == null || visual.Alpha == alpha) return;
            if (alpha <= 0f)
            {
                Solid(visual);
                visual.Renderer.forceRenderingOff = true; visual.Hidden = true; visual.Alpha = 0f;
                return;
            }
            if (visual.Hidden) { visual.Renderer.forceRenderingOff = false; visual.Hidden = false; }
            if (alpha >= 1f) { Solid(visual); visual.Alpha = 1f; return; }
            if (visual.Fades == null)
            {
                visual.Fades = new Material[visual.Original.Length];
                for (int i = 0; i < visual.Fades.Length; i++)
                {
                    var mat = new Material(visual.Original[i]);
                    mat.hideFlags = HideFlags.DontSave;
                    mat.SetFloat("_Mode", 2f);
                    mat.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
                    mat.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
                    mat.SetInt("_ZWrite", 0);
                    mat.SetOverrideTag("RenderType", "Transparent");
                    mat.DisableKeyword("_ALPHATEST_ON"); mat.EnableKeyword("_ALPHABLEND_ON");
                    mat.DisableKeyword("_ALPHAPREMULTIPLY_ON"); mat.renderQueue = visual.Queue;
                    visual.Fades[i] = mat;
                }
            }
            for (int i = 0; i < visual.Fades.Length; i++)
            {
                Color color = visual.Original[i].color;
                color.a = alpha; // opaque source alpha is ignored by its original shader
                visual.Fades[i].color = color;
            }
            if (!visual.UsingFade) visual.Renderer.sharedMaterials = visual.Fades;
            visual.UsingFade = true; visual.Alpha = alpha;
        }
        static void Solid(Visual visual)
        {
            if (visual.Renderer != null && visual.UsingFade)
            {
                var materials = visual.Renderer.sharedMaterials;
                bool changed = false;
                for (int i = 0; i < materials.Length; i++)
                    for (int j = 0; visual.Fades != null && j < visual.Fades.Length; j++)
                        if (materials[i] == visual.Fades[j])
                        { materials[i] = visual.Original[j]; changed = true; break; }
                if (changed) visual.Renderer.sharedMaterials = materials;
            }
            if (visual.Fades != null)
                foreach (var material in visual.Fades) if (material != null) UnityEngine.Object.Destroy(material);
            visual.Fades = null; visual.UsingFade = false;
        }
        static void Release(Prop prop)
        {
            Solid(prop.High);
            if (prop.High.Hidden && prop.High.Renderer != null && prop.High.Renderer.forceRenderingOff)
                prop.High.Renderer.forceRenderingOff = false;
            if (prop.Low != null)
            {
                Solid(prop.Low);
                if (prop.Low.Renderer != null)
                { prop.Low.Renderer.forceRenderingOff = true; UnityEngine.Object.Destroy(prop.Low.Renderer.gameObject); }
                generated--;
            }
        }
        static void Forget(Prop prop)
        { Release(prop); Props.Remove(prop); Live.Remove(prop); Ids.Remove(prop.Id); }
        static void Prune()
        {
            for (int i = Props.Count - 1; i >= 0; i--) if (!Valid(Props[i], true)) Forget(Props[i]);
            for (int i = Groups.Count - 1; i >= 0; i--)
                if (Groups[i].Group == null || Protected(Groups[i].Group))
                { ReleaseGroup(Groups[i]); GroupIds.Remove(Groups[i].Id); Groups.RemoveAt(i); }
        }
        static bool MakeRoom(Vector3 candidate)
        {
            var camera = Camera.main;
            if (camera == null || Vector3.Distance(candidate, camera.transform.position) > camera.farClipPlane) return false;
            // Recycle only beyond the camera clip plane, where restoring the original cannot pop into view.
            for (int i = 0; i < Props.Count; i++)
            {
                var prop = Props[i];
                if (prop.High.Renderer == null || Vector3.Distance(prop.High.Renderer.bounds.center, camera.transform.position)
                    > camera.farClipPlane + prop.High.Renderer.bounds.extents.magnitude)
                { Forget(prop); return true; }
            }
            return false;
        }
        static int GroupLevel(NativeGroup saved)
        {
            var camera = Camera.main;
            if (camera == null) return 0;
            var scale = saved.Group.transform.lossyScale;
            float size = saved.Group.size * Mathf.Max(Mathf.Abs(scale.x), Mathf.Max(Mathf.Abs(scale.y), Mathf.Abs(scale.z)));
            float denominator = camera.orthographic ? 2f * camera.orthographicSize : 2f * Mathf.Tan(camera.fieldOfView * Mathf.Deg2Rad * .5f)
                * Vector3.Distance(camera.transform.position, saved.Group.transform.TransformPoint(saved.Group.localReferencePoint));
            float height = size * QualitySettings.lodBias / Mathf.Max(.01f, denominator);
            return LodTransition.Level(height, saved.Thresholds, QualitySettings.maximumLODLevel);
        }
        static void RefreshGroups()
        {
            int steps = Mathf.Min(192, Groups.Count);
            for (int n = 0; n < steps && Groups.Count > 0; n++)
            {
                if (groupCursor >= Groups.Count) groupCursor = 0;
                var saved = Groups[groupCursor];
                bool valid = saved.Group != null && !saved.Group.enabled && saved.Group.gameObject.activeInHierarchy;
                if (valid && saved.Group.transform.parent != saved.Parent)
                { saved.Parent = saved.Group.transform.parent; valid = !Protected(saved.Group); }
                foreach (var visual in saved.Visuals)
                    if (visual.Renderer == null || !visual.Renderer.enabled || visual.Renderer.forceRenderingOff != visual.Hidden)
                        valid = false;
                    else if (!visual.Hard && (visual.Renderer.HasPropertyBlock()
                        || !Same(visual.Renderer.sharedMaterials, visual.UsingFade ? visual.Fades : visual.Original))) valid = false;
                if (!valid)
                { ReleaseGroup(saved); GroupIds.Remove(saved.Id); Groups.RemoveAt(groupCursor); continue; }
                int level = GroupLevel(saved);
                saved.Level = level;
                LodTransition.StepWeights(saved.Weights, level, Time.unscaledDeltaTime, FadeSeconds);
                ApplyGroup(saved);
                groupCursor++;
            }
        }
        static void ApplyGroup(NativeGroup saved)
        {
            int v = 0;
            float consumed = 0f;
            for (int i = 0; i < saved.Lods.Length; i++)
            {
                float fade = LodTransition.CompositeAlpha(saved.Weights[i], consumed);
                foreach (var renderer in saved.Lods[i].renderers)
                {
                    if (renderer == null) continue;
                    var visual = saved.Visuals[v++];
                    visual.Queue = 3008 - i;
                    float alpha = visual.Hard ? (i == saved.Level ? 1f : 0f) : fade;
                    ApplyAlpha(visual, alpha);
                }
                consumed += saved.Weights[i];
            }
        }
        static void ReleaseGroup(NativeGroup saved)
        {
            foreach (var visual in saved.Visuals)
            {
                Solid(visual);
                GroupRenderers.Remove(visual.Renderer);
                if (visual.Renderer == null) continue;
                // enabled is never changed here: it belongs to the game and GDOC.
                if (visual.Hidden && visual.Renderer.forceRenderingOff)
                    visual.Renderer.forceRenderingOff = false;
            }
            if (saved.Group != null && !saved.Group.enabled) saved.Group.enabled = true;
        }
        static bool Same(Material[] a, Material[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
    }
}
