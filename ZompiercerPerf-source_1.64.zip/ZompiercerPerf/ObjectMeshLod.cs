using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Rendering;

namespace ZompiercerPerf
{
    // Caller checks renderer/material eligibility and polls pending jobs on the main thread.
    // Clear only after callers have detached reduced meshes from their renderers.
    internal static class ObjectMeshLod
    {
        const int MaximumEntries = 384;
        const long MaximumCachedBytes = 24L * 1024 * 1024;
        const long MaximumInputBytes = 12L * 1024 * 1024;

        sealed class Entry
        {
            internal Mesh Source;
            internal Mesh Reduced;
            internal bool Complete;
            internal long Bytes;
        }

        static readonly Dictionary<int, Entry> Cache = new Dictionary<int, Entry>();
        static long cachedBytes;
        static Task<MeshLodPolicy.Data> worker;
        static Entry workerEntry;

        public static bool IsComplete(Mesh original)
        {
            if (original == null) return true;
            // Do not drain here: the caller may have just received null from
            // GetReduced. Draining now would mark a new success complete before
            // the caller has ever received the generated Mesh.
            Entry entry;
            if (Cache.TryGetValue(original.GetInstanceID(), out entry) && ReferenceEquals(entry.Source, original))
                return entry.Complete;
            return Cache.Count >= MaximumEntries;
        }

        public static Mesh GetReduced(Mesh original)
        {
            if (original == null) return null;
            DrainWorker();
            int id = original.GetInstanceID();
            Entry entry;
            if (Cache.TryGetValue(id, out entry) && ReferenceEquals(entry.Source, original))
                return entry.Reduced;
            // An invalidated worker remains occupied until its pure calculation
            // finishes, so Clear cannot cause overlapping generation jobs.
            if (Cache.Count >= MaximumEntries || worker != null) return null;

            // Unity may eventually reuse an instance ID after a source dies.
            if (entry != null)
            {
                if (entry.Reduced != null) UnityEngine.Object.Destroy(entry.Reduced);
                cachedBytes -= entry.Bytes;
            }

            entry = new Entry { Source = original, Complete = true };
            Cache[id] = entry;
            try
            {
                if (original.isReadable && original.vertexCount <= MeshLodPolicy.MaximumVertices &&
                    original.subMeshCount > 0 && original.subMeshCount <= 8 &&
                    original.blendShapeCount == 0 && original.colors32.Length == 0 &&
                    original.boneWeights.Length == 0 && original.bindposes.Length == 0 &&
                    original.uv2.Length == 0 && original.uv3.Length == 0 && original.uv4.Length == 0 &&
                    !HasHigherUvChannels(original))
                {
                    var source = Read(original);
                    if (source != null)
                    {
                        entry.Complete = false;
                        workerEntry = entry;
                        worker = Task.Run(() => MeshLodPolicy.Reduce(source));
                    }
                }
            }
            catch (Exception)
            {
                // Asset import state and custom mesh data can fail Unity's array getters.
                // A failed source is cached, so scanning never retries it every frame.
                entry.Complete = true;
                workerEntry = null;
                worker = null;
            }
            return null;
        }

        static bool HasHigherUvChannels(Mesh mesh)
        {
            var values = new List<Vector4>();
            for (int channel = 4; channel < 8; channel++)
            {
                values.Clear();
                mesh.GetUVs(channel, values);
                if (values.Count != 0) return true;
            }
            return false;
        }

        public static void Clear()
        {
            foreach (var entry in Cache.Values)
                if (entry.Reduced != null) UnityEngine.Object.Destroy(entry.Reduced);
            Cache.Clear();
            cachedBytes = 0;
            workerEntry = null;
        }

        static void DrainWorker()
        {
            if (worker == null || !worker.IsCompleted) return;
            var completed = worker;
            var entry = workerEntry;
            worker = null;
            workerEntry = null;
            try
            {
                MeshLodPolicy.Data geometry = completed.GetAwaiter().GetResult();
                if (entry != null && entry.Source != null && geometry != null)
                {
                    Entry current;
                    if (Cache.TryGetValue(entry.Source.GetInstanceID(), out current) && ReferenceEquals(entry, current))
                    {
                        long bytes = EstimateBytes(geometry);
                        if (bytes > 0 && cachedBytes + bytes <= MaximumCachedBytes)
                        {
                            entry.Reduced = Create(entry.Source, geometry);
                            entry.Bytes = bytes;
                            cachedBytes += bytes;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // A failed calculation or Unity mesh upload leaves original detail.
            }
            finally
            {
                if (entry != null) entry.Complete = true;
            }
        }

        static MeshLodPolicy.Data Read(Mesh source)
        {
            int count = source.vertexCount;
            if (count < 3 || count > MeshLodPolicy.MaximumVertices) return null;
            int triangles = 0;
            for (int i = 0; i < source.subMeshCount; i++)
            {
                if (source.GetTopology(i) != MeshTopology.Triangles) return null;
                long indices = source.GetIndexCount(i);
                if (indices % 3 != 0 || indices / 3 > MeshLodPolicy.MaximumTriangles - triangles) return null;
                triangles += (int)(indices / 3);
            }
            if (triangles < MeshLodPolicy.MinimumTriangles) return null;
            if ((long)count * 48 + (long)triangles * 12 > MaximumInputBytes) return null;
            var vertices = source.vertices;
            var normals = source.normals;
            var uv = source.uv;
            var tangents = source.tangents;
            if (vertices.Length != count || normals.Length != count ||
                (uv.Length != 0 && uv.Length != count) ||
                (tangents.Length != 0 && tangents.Length != count)) return null;
            var submeshes = new int[source.subMeshCount][];
            for (int i = 0; i < submeshes.Length; i++)
            {
                submeshes[i] = source.GetIndices(i);
            }
            long sourceBytes = (long)count * (24 + (uv.Length == count ? 8 : 0) +
                (tangents.Length == count ? 16 : 0)) + (long)triangles * 12;
            if (sourceBytes > MaximumInputBytes) return null;
            var data = new MeshLodPolicy.Data
            {
                Positions = new float[count * 3], Normals = new float[count * 3],
                Uv = uv.Length == count ? new float[count * 2] : null,
                Tangents = tangents.Length == count ? new float[count * 4] : null,
                Submeshes = submeshes
            };
            for (int i = 0; i < count; i++)
            {
                data.Positions[i * 3] = vertices[i].x;
                data.Positions[i * 3 + 1] = vertices[i].y;
                data.Positions[i * 3 + 2] = vertices[i].z;
                data.Normals[i * 3] = normals[i].x;
                data.Normals[i * 3 + 1] = normals[i].y;
                data.Normals[i * 3 + 2] = normals[i].z;
                if (data.Uv != null)
                {
                    data.Uv[i * 2] = uv[i].x;
                    data.Uv[i * 2 + 1] = uv[i].y;
                }
                if (data.Tangents != null)
                {
                    data.Tangents[i * 4] = tangents[i].x;
                    data.Tangents[i * 4 + 1] = tangents[i].y;
                    data.Tangents[i * 4 + 2] = tangents[i].z;
                    data.Tangents[i * 4 + 3] = tangents[i].w;
                }
            }
            return data;
        }

        static long EstimateBytes(MeshLodPolicy.Data data)
        {
            long size = (long)data.Positions.Length * 4 + (long)data.Normals.Length * 4;
            if (data.Uv != null) size += (long)data.Uv.Length * 4;
            if (data.Tangents != null) size += (long)data.Tangents.Length * 4;
            for (int i = 0; i < data.Submeshes.Length; i++) size += (long)data.Submeshes[i].Length * 4;
            return size;
        }

        static Mesh Create(Mesh original, MeshLodPolicy.Data data)
        {
            int count = data.Positions.Length / 3;
            var vertices = new Vector3[count];
            var normals = new Vector3[count];
            var uv = data.Uv == null ? null : new Vector2[count];
            var tangents = data.Tangents == null ? null : new Vector4[count];
            for (int i = 0; i < count; i++)
            {
                vertices[i] = new Vector3(data.Positions[i * 3], data.Positions[i * 3 + 1], data.Positions[i * 3 + 2]);
                normals[i] = new Vector3(data.Normals[i * 3], data.Normals[i * 3 + 1], data.Normals[i * 3 + 2]);
                if (uv != null) uv[i] = new Vector2(data.Uv[i * 2], data.Uv[i * 2 + 1]);
                if (tangents != null)
                    tangents[i] = new Vector4(data.Tangents[i * 4], data.Tangents[i * 4 + 1],
                        data.Tangents[i * 4 + 2], data.Tangents[i * 4 + 3]);
            }
            var mesh = new Mesh();
            try
            {
                mesh.name = original.name + " (Perf reduced)";
                mesh.hideFlags = HideFlags.DontSave;
                mesh.vertices = vertices;
                mesh.normals = normals;
                if (uv != null) mesh.uv = uv;
                if (tangents != null) mesh.tangents = tangents;
                mesh.subMeshCount = data.Submeshes.Length;
                for (int s = 0; s < data.Submeshes.Length; s++)
                    mesh.SetTriangles(data.Submeshes[s], s, false);
                // Maintain the original culling bounds through a LOD transition.
                mesh.bounds = original.bounds;
                return mesh;
            }
            catch
            {
                UnityEngine.Object.Destroy(mesh);
                throw;
            }
        }
    }
}
