using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Rendering;
using UnityEngine.InputSystem;

namespace ZompiercerPerf
{
    [BepInPlugin("local.zompiercer.perf", "Zompiercer Perf", "1.64")]
    public class PerfPlugin : BaseUnityPlugin
    {
        public static ConfigEntry<bool> CacheMainCamera;
        public static ConfigEntry<bool> DistanceLod;
        public static ConfigEntry<float> NearDistance;
        public static ConfigEntry<float> FarDistance;
        public static ConfigEntry<int> MidInterval;
        public static ConfigEntry<int> FarInterval;
        public static ConfigEntry<int> IdleInterval;
        public static ConfigEntry<bool> SliceAnimation;
        public static ConfigEntry<bool> NavAvoidance;
        public static ConfigEntry<float> AvoidanceLowDistance;
        public static ConfigEntry<float> AvoidanceOffDistance;
        public static ConfigEntry<bool> AnimatorCulling;
        public static ConfigEntry<float> ShadowOffDistance;
        public static ConfigEntry<float> HeadOffDistance;
        public static ConfigEntry<int> WaterReflectionSize;
        public static ConfigEntry<bool> BenchmarkAuto;
        public static ConfigEntry<bool> Bypass;
        public static ConfigEntry<int> Preset;
        public static ConfigEntry<int> TextureLimit;
        public static ConfigEntry<int> ShadowMeters;
        public static ConfigEntry<int> ShadowMode;
        public static ConfigEntry<int> ShadowRes;
        public static ConfigEntry<int> Cascades;
        public static ConfigEntry<int> FarClip;
        public static ConfigEntry<int> Lod;
        public static ConfigEntry<int> PixelLights;
        public static ConfigEntry<int> Aniso;
        public static ConfigEntry<bool> SoftParticles;
        public static ConfigEntry<bool> SoftVegetation;
        public static ConfigEntry<bool> RealtimeProbes;
        public static ConfigEntry<bool> HeavyEffects;
        public static ConfigEntry<bool> BloomOn;
        public static ConfigEntry<bool> SunOnlyShadows;
        public static ConfigEntry<int> TerrainDetail;
        public static ConfigEntry<int> ParticleCull;
        public static ConfigEntry<int> ParticleBudget;
        public static ConfigEntry<bool> StreamingMips;
        public static ConfigEntry<int> VegetationMode;
        public static ConfigEntry<int> ZombieShadowMode;
        public static ConfigEntry<int> HeadMode;
        public static ConfigEntry<int> CharacterLod;
        public static ConfigEntry<int> PropLod;
        public static ConfigEntry<int> RenderScaleIndex;
        public static ConfigEntry<int> Upscaler;
        public static ConfigEntry<int> Sharpness;
        public static ConfigEntry<bool> Sharpen;
        public static ConfigEntry<bool> MipBias;
        public static ConfigEntry<int> TargetFps;
        public static ConfigEntry<int> SmallShadowsMode;
        public static ConfigEntry<int> CloudsMode;
        public static ConfigEntry<int> VolumeLightMode;
        public static ConfigEntry<int> GrassDistanceMode;
        public static ConfigEntry<int> GrassDensityMode;
        public static ConfigEntry<int> WaterUpdateMode;
        public static ConfigEntry<int> AntiAliasingMode;
        public static ConfigEntry<int> ProbeUpdateMode;
        public static PerfPlugin Instance;
        // Runtime-only override for the comparison benchmark; the saved Bypass preference is untouched.
        public static ForcedMode ForcedMode;

        public static Tune Tune = new Tune();
        Harmony harmony;
        bool ready, configDirty;

        public void Awake()
        {
            CacheMainCamera = Config.Bind("Camera", "CacheMainCamera", true,
                "Unity 2020.1 ищет камеру по тегу на каждый Camera.main. Кэш убирает этот поиск.");
            DistanceLod = Config.Bind("Zombies", "DistanceLod", true,
                "Визуальный LOD зомби. ИИ и его таймеры не пропускаются; в LAN этот LOD остаётся под управлением сетевого мода.");
            NearDistance = Config.Bind("Zombies", "NearDistance", 36f,
                "Ближе этой дистанции до игрока ИИ и анимация идут каждый кадр.");
            FarDistance = Config.Bind("Zombies", "FarDistance", 64f,
                "Дальше этой дистанции ИИ идёт с FarInterval, если зомби никого не бьёт.");
            MidInterval = Config.Bind("Zombies", "MidInterval", 2, "Каждые N кадров между Near и Far.");
            FarInterval = Config.Bind("Zombies", "FarInterval", 4, "Каждые N кадров дальше Far.");
            IdleInterval = Config.Bind("Zombies", "IdleInterval", 8,
                "Спящие и статичные зомби дальше NearDistance.");
            SliceAnimation = Config.Bind("Zombies", "SliceAnimation", true,
                "Совместимость старого конфига: обновления параметров анимации больше не пропускаются.");
            NavAvoidance = Config.Bind("Zombies", "NavAvoidance", true,
                "Дальние зомби не считают взаимное избегание на NavMesh. Вблизи возвращается как было.");
            AvoidanceLowDistance = Config.Bind("Zombies", "AvoidanceLowDistance", 14f, "Метры, с которых избегание упрощается.");
            AvoidanceOffDistance = Config.Bind("Zombies", "AvoidanceOffDistance", 28f, "Метры, с которых избегание выключается.");
            AnimatorCulling = Config.Bind("Zombies", "AnimatorCulling", true,
                "Аниматор зомби не пишет кости, пока модель за кадром. На экране картинка та же.");
            ShadowOffDistance = Config.Bind("Zombies", "ShadowOffDistance", 45f,
                "Дальше этой дистанции зомби не отбрасывают тень. 0 — не трогать тени.");
            HeadOffDistance = Config.Bind("Zombies", "HeadOffDistance", 22f,
                "Дальше этой дистанции голова зомби не поворачивается к целям. 0 — не трогать.");
            WaterReflectionSize = Config.Bind("Water", "ReflectionSize", 256,
                "Потолок отражений AQUAS: -1 выкл, 0 как в игре, иначе пиксели стороны.");
            BenchmarkAuto = Config.Bind("Perf", "Benchmark", false,
                "При запуске прогнать бенчмарк первой локации. То же делает аргумент -benchmark. Вручную — F5 в главном меню (F8 занята панелью LAN).");
            Bypass = Config.Bind("Perf", "Bypass", false, "Игра как без мода: мод ничего не меняет, меню остаётся.");
            Preset = Config.Bind("Graphics", "Preset", 5, "1 максимум, 5 лучший баланс, 3 минимум, 4 своё. Значения 0 и 2 из старых версий переводятся в 5.");
            TextureLimit = Config.Bind("Graphics", "TextureLimit", 0, "0 высокое ... 3 очень низкое.");
            ShadowMeters = Config.Bind("Graphics", "ShadowMeters", 3, "Индекс дальности теней.");
            ShadowMode = Config.Bind("Graphics", "ShadowMode", 2, "0 выкл, 1 жёсткие, 2 все.");
            ShadowRes = Config.Bind("Graphics", "ShadowResolution", 1, "0 низкое ... 3 очень высокое.");
            Cascades = Config.Bind("Graphics", "ShadowCascades", 1, "0 = один каскад, 1 = два, 2 = четыре.");
            FarClip = Config.Bind("Graphics", "FarClip", 2, "0 как в игре, дальше — короче обзор.");
            Lod = Config.Bind("Graphics", "Lod", 1, "Индекс детализации моделей.");
            PixelLights = Config.Bind("Graphics", "PixelLights", 1, "Индекс числа пиксельных источников.");
            Aniso = Config.Bind("Graphics", "Anisotropic", 1, "0 выкл, 1 вкл, 2 принудительно.");
            SoftParticles = Config.Bind("Graphics", "SoftParticles", false, "Мягкие частицы.");
            SoftVegetation = Config.Bind("Graphics", "SoftVegetation", false, "Мягкая растительность.");
            RealtimeProbes = Config.Bind("Graphics", "RealtimeProbes", false, "Обновление отражений в реальном времени.");
            HeavyEffects = Config.Bind("Graphics", "HeavyEffects", false, "AO, отражения экрана, смаз и глубина резкости.");
            BloomOn = Config.Bind("Graphics", "Bloom", true, "Свечение постобработки.");
            SunOnlyShadows = Config.Bind("Graphics", "SunOnlyShadows", true, "Тени только у направленного света.");
            TerrainDetail = Config.Bind("Graphics", "TerrainDetail", 1, "0 близко, 1 средне, 2 далеко, 3 как в игре.");
            ParticleCull = Config.Bind("Graphics", "ParticleCull", 2, "0 выкл, дальше дистанция зацикленных частиц.");
            ParticleBudget = Config.Bind("Graphics", "ParticleBudget", 1, "Индекс бюджета столкновений частиц.");
            StreamingMips = Config.Bind("Graphics", "StreamingMips", false, "Подгружать крупные текстуры по мере нужды.");
            VegetationMode = Config.Bind("Graphics", "VegetationMode", 2, "0 каждый кадр, 1 при движении камеры, 2 реже.");
            ZombieShadowMode = Config.Bind("Graphics", "ZombieShadows", 2, "0 не трогать, дальше дистанция отключения тени зомби.");
            HeadMode = Config.Bind("Graphics", "HeadTracking", 2, "0 не трогать, дальше дистанция поворота головы.");
            CharacterLod = Config.Bind("Graphics", "CharacterLod", 1, "0 выкл, 1 мягкий LOD костей, 2 сильный.");
            PropLod = Config.Bind("Graphics", "PropLod", 1, "0 выкл, 1 прятать мелкие предметы дальше, 2 ближе.");
            RenderScaleIndex = Config.Bind("Graphics", "RenderScale", 0,
                "Разрешение 3D-сцены: 0 = 100%, 6 = 90%, 7 = 85%, 1 = 77%, 2 = 67%, 3 = 59%, 4 = 50%, 5 = авто по FPS. Интерфейс остаётся в полном разрешении. Профили его не меняют.");
            Upscaler = Config.Bind("Graphics", "Upscaler", 0, "Растяжка уменьшенной сцены: 0 FSR 1, 1 простая (билинейная).");
            Sharpness = Config.Bind("Graphics", "FsrSharpness", 1, "Резкость FSR: 0 низкая, 1 средняя, 2 высокая.");
            Sharpen = Config.Bind("Graphics", "SharpenFullRes", false, "Резкость FSR и при масштабе 100% (убирает мыло от TAA игры).");
            MipBias = Config.Bind("Graphics", "FsrMipBias", true, "При уменьшенном рендере брать более детальные уровни текстур, чтобы они не мылились.");
            TargetFps = Config.Bind("Graphics", "AutoScaleTarget", 1, "Цель авто-масштаба: 0 = 45, 1 = 60, 2 = 75, 3 = 90, 4 = 120, 5 = 144 FPS.");
            SmallShadowsMode = Config.Bind("Graphics", "SmallShadows", 2, "Тени мелких предметов: 0 как в игре, 1 до 20 м, 2 до 35 м, 3 до 50 м.");
            CloudsMode = Config.Bind("Graphics", "Clouds", 2, "Облака Enviro: 0 как в игре, 1 высокие, 2 средние, 3 низкие, 4 плоские.");
            VolumeLightMode = Config.Bind("Graphics", "VolumeLight", 1, "Объёмный свет Enviro: 0 как в игре, 1 половина, 2 четверть разрешения, 3 выкл.");
            GrassDistanceMode = Config.Bind("Graphics", "GrassDistance", 2, "Дальность травы: 0 как в игре, 1 = 80%, 2 = 65%, 3 = 50%, 4 = 35%.");
            GrassDensityMode = Config.Bind("Graphics", "GrassDensity", 0, "Плотность травы: 0 как в игре, 1 = 80%, 2 = 60%, 3 = 40%.");
            AntiAliasingMode = Config.Bind("Graphics", "AntiAliasing", 0,
                "Сглаживание пост-обработки: 0 как в игре (её переключатель TAA), 1 выкл, 2 FXAA, 3 SMAA, 4 TAA. Профили его не меняют.");
            ProbeUpdateMode = Config.Bind("Graphics", "ReflectionProbeUpdate", 0,
                "Отражения окружения (небо и мир в отражениях): 0 как в игре, 1 не чаще раза в 0,5 с, 2 не чаще раза в 2 с. Профили его не меняют.");
            WaterUpdateMode = Config.Bind("Water", "ReflectionInterval", 1, "Отражения воды: 0 каждый кадр, 1 через кадр, 2 каждый третий кадр.");

            Instance = this;
            MigratePresets();
            Tune.Pull();
            harmony = new Harmony("local.zompiercer.perf");
            try
            {
                harmony.PatchAll(Assembly.GetExecutingAssembly());
                GraphicsApply.Patch(harmony);
                GraphicsMenu.Patch(harmony);
                RenderScale.Patch(harmony);
                ReflectionUpdates.Patch(harmony);
                Config.SettingChanged += SettingsChanged;
                UnityEngine.SceneManagement.SceneManager.sceneUnloaded += SceneUnloaded;
                ready = true;
                Benchmark.Boot();
                Logger.LogInfo("Zompiercer Perf 1.64: обратимые настройки, масштаб рендера с FSR 1, сравнительный бенчмарк, совместимость с LAN.");
            }
            catch (Exception ex)
            {
                harmony.UnpatchSelf();
                Tune.Bypass = true;
                GraphicsApply.RestoreVanilla();
                Logger.LogError("Perf hooks were not installed; changes disabled: " + ex);
            }
        }

        // 1.4.0 removed the "game" (0) and old "balanced" (2) profiles. "Game" becomes the mode switch,
        // so its users keep the unmodified game; the old balance becomes the new best balance.
        static void MigratePresets()
        {
            if (Preset.Value == 0)
            {
                Bypass.Value = true;
                Preset.Value = 5;
            }
            else if (Preset.Value != 1 && Preset.Value != 3 && Preset.Value != 4 && Preset.Value != 5)
                Preset.Value = 5;
        }

        void SettingsChanged(object sender, SettingChangedEventArgs args)
        {
            if (ReferenceEquals(args.ChangedSetting, BenchmarkAuto)) return;
            configDirty = true;
        }

        void SceneUnloaded(UnityEngine.SceneManagement.Scene scene)
        {
            CamMotion.Sampled = false;
            GraphicsApply.ReleaseScene();
            Benchmark.OnSceneUnloaded();
        }

        public void LateUpdate()
        {
            if (!ready) return;
            Benchmark.Late();
            RenderScale.Tick();
        }

        public void Update()
        {
            if (!ready) return;
            if (configDirty)
            {
                configDirty = false;
                RenderScale.ResetFailure();
                bool wasOptimized = !Tune.Bypass && Tune.Preset != 0;
                Tune.Pull();
                if (!wasOptimized && !Tune.Bypass && Tune.Preset != 0)
                    GraphicsApply.TurnOn();
                else
                    GraphicsApply.ApplyNow();
            }
            GraphicsApply.Pump();
            WorldLod.Tick();
            SmallShadows.Tick();
            SkyQuality.Tick();
            AntiAliasing.Tick();
            ReflectionUpdates.Tick();
            Benchmark.Tick();
            var keyboard = Keyboard.current;
            if (keyboard != null && keyboard.f6Key.wasPressedThisFrame && !Typing())
                QuickToggle();
        }

        // F6: compare in place. Runtime only, like the comparison benchmark: the saved choice is untouched.
        void QuickToggle()
        {
            if (Benchmark.Running)
                return;
            bool off = ForcedMode != ForcedMode.Vanilla;
            Force(off ? ForcedMode.Vanilla : ForcedMode.None);
            Toast(off ? "Мод выключен до F6 (настройки сохранены)" : (Tune.Bypass || Tune.Preset == 0
                ? "F6: в настройках выбран режим без оптимизации" : "Мод включен"));
        }

        static string toast;
        static float toastUntil;
        static GUIStyle toastStyle;

        public static void Toast(string text)
        {
            toast = text;
            toastUntil = Time.realtimeSinceStartup + 2.5f;
        }

        static void DrawToast()
        {
            if (toast == null)
                return;
            if (Time.realtimeSinceStartup >= toastUntil)
            {
                toast = null;
                return;
            }
            if (toastStyle == null)
            {
                toastStyle = new GUIStyle(GUI.skin.label) { fontSize = 18, alignment = TextAnchor.MiddleCenter };
                toastStyle.normal.textColor = Color.white;
            }
            var box = new Rect(Screen.width * .5f - 240f, Screen.height - 96f, 480f, 40f);
            Color color = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, .62f);
            GUI.DrawTexture(box, Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(box, toast, toastStyle);
            GUI.color = color;
        }

        public static void Force(ForcedMode mode)
        {
            bool was = !Tune.Bypass && Tune.Preset != 0;
            ForcedMode = mode;
            Tune.Pull();
            bool now = !Tune.Bypass && Tune.Preset != 0;
            if (!now)
                GraphicsApply.TurnOff();
            else if (!was)
                GraphicsApply.TurnOn();
            else
                GraphicsApply.ApplyNow();
        }

        public void SetOptimization(bool enabled)
        {
            Bypass.Value = !enabled;
            ForcedMode = ForcedMode.None; // an explicit menu choice ends a temporary F6 switch
            Tune.Pull();
            if (!enabled)
                GraphicsApply.TurnOff();
            else
                GraphicsApply.TurnOn();
            configDirty = false;
        }

        static bool Typing()
        {
            var events = UnityEngine.EventSystems.EventSystem.current;
            if (events == null || events.currentSelectedGameObject == null)
                return false;
            return events.currentSelectedGameObject.GetComponent<UnityEngine.UI.InputField>() != null;
        }

        public void LogInfo(string message) { Logger.LogInfo(message); }
        public void LogWarning(string message) { Logger.LogWarning(message); }
        public void LogError(string message) { Logger.LogError(message); }

        public void OnGUI()
        {
            if (!ready) return;
            GraphicsMenu.Draw();
            DrawToast();
            Benchmark.Draw();
        }

        public void OnDestroy()
        {
            Config.SettingChanged -= SettingsChanged;
            UnityEngine.SceneManagement.SceneManager.sceneUnloaded -= SceneUnloaded;
            ready = false;
            try { Benchmark.Shutdown(); } catch (Exception ex) { Logger.LogWarning("Benchmark shutdown: " + ex.Message); }
            try { RenderScale.Release(); } catch (Exception ex) { Logger.LogWarning("Render scale shutdown: " + ex.Message); }
            Tune.Bypass = true; // runtime restoration only; preserve the user's saved preference
            try { GraphicsApply.RestoreVanilla(); } catch (Exception ex) { Logger.LogWarning("Perf restoration: " + ex.Message); }
            harmony?.UnpatchSelf();
            if (ReferenceEquals(Instance, this)) Instance = null;
        }
    }

    public enum ForcedMode { None, Vanilla, Optimized }

    public sealed class Tune
    {
        public bool CacheMainCamera = true;
        public bool DistanceLod = true;
        public float NearDistance = 36f;
        public float FarDistance = 64f;
        public int MidInterval = 2;
        public int FarInterval = 4;
        public int IdleInterval = 8;
        public bool SliceAnimation = true;
        public bool NavAvoidance = true;
        public float AvoidanceLowDistance = 14f;
        public float AvoidanceOffDistance = 28f;
        public bool AnimatorCulling = true;
        public float ShadowOffDistance = 45f;
        public float HeadOffDistance = 22f;
        public bool ThrottleBillboards = true;
        public int BillboardInterval = 2;
        public int WaterReflectionSize = 256;
        public int Preset = 2;
        public int TextureLimit;
        public int ShadowMeters = 3;
        public int ShadowMode = 2;
        public int ShadowRes = 1;
        public int Cascades = 1;
        public int FarClip = 2;
        public int Lod = 1;
        public int PixelLights = 1;
        public int Aniso = 1;
        public bool SoftParticles;
        public bool SoftVegetation;
        public bool RealtimeProbes;
        public bool HeavyEffects;
        public bool BloomOn = true;
        public bool SunOnlyShadows = true;
        public int TerrainDetail = 1;
        public int ParticleCull = 2;
        public int ParticleBudget = 1;
        public bool StreamingMips;
        public bool Bypass;
        public int VegetationMode = 2;
        public int ZombieShadowMode = 2;
        public int HeadMode = 2;
        public int CharacterLod = 1;
        public int PropLod = 1;
        public int RenderScale;
        public int Upscaler;
        public int Sharpness = 1;
        public bool Sharpen;
        public bool MipBias = true;
        public int TargetFps = 1;
        public int SmallShadows = 2;
        public int Clouds = 2;
        public int VolumeLight = 1;
        public int GrassDistance = 2;
        public int GrassDensity;
        public int WaterUpdate = 1;
        public int AntiAliasing;
        public int ProbeUpdate;

        public void Pull()
        {
            CacheMainCamera = PerfPlugin.CacheMainCamera.Value;
            DistanceLod = PerfPlugin.DistanceLod.Value;
            NearDistance = PerfPolicy.Distance(PerfPlugin.NearDistance.Value, 36f, 8f, 1000f);
            FarDistance = PerfPolicy.Distance(PerfPlugin.FarDistance.Value, 64f, NearDistance + 1f, 2000f);
            MidInterval = Mathf.Clamp(PerfPlugin.MidInterval.Value, 1, 12);
            FarInterval = Mathf.Clamp(PerfPlugin.FarInterval.Value, 1, 20);
            IdleInterval = Mathf.Clamp(PerfPlugin.IdleInterval.Value, 1, 30);
            SliceAnimation = PerfPlugin.SliceAnimation.Value;
            NavAvoidance = PerfPlugin.NavAvoidance.Value;
            AvoidanceLowDistance = PerfPolicy.Distance(PerfPlugin.AvoidanceLowDistance.Value, 14f, 4f, 1000f);
            AvoidanceOffDistance = PerfPolicy.Distance(PerfPlugin.AvoidanceOffDistance.Value, 28f, AvoidanceLowDistance + 1f, 2000f);
            AnimatorCulling = PerfPlugin.AnimatorCulling.Value;
            ShadowOffDistance = Mathf.Max(0f, PerfPlugin.ShadowOffDistance.Value);
            HeadOffDistance = Mathf.Max(0f, PerfPlugin.HeadOffDistance.Value);
            WaterReflectionSize = PerfPlugin.WaterReflectionSize.Value;
            Preset = Mathf.Clamp(PerfPlugin.Preset.Value, 0, 5);
            TextureLimit = Mathf.Clamp(PerfPlugin.TextureLimit.Value, 0, 3);
            ShadowMeters = Mathf.Clamp(PerfPlugin.ShadowMeters.Value, 0, 5);
            ShadowMode = Mathf.Clamp(PerfPlugin.ShadowMode.Value, 0, 2);
            ShadowRes = Mathf.Clamp(PerfPlugin.ShadowRes.Value, 0, 3);
            Cascades = Mathf.Clamp(PerfPlugin.Cascades.Value, 0, 2);
            FarClip = Mathf.Clamp(PerfPlugin.FarClip.Value, 0, 4);
            Lod = Mathf.Clamp(PerfPlugin.Lod.Value, 0, 4);
            PixelLights = Mathf.Clamp(PerfPlugin.PixelLights.Value, 0, 3);
            Aniso = Mathf.Clamp(PerfPlugin.Aniso.Value, 0, 2);
            SoftParticles = PerfPlugin.SoftParticles.Value;
            SoftVegetation = PerfPlugin.SoftVegetation.Value;
            RealtimeProbes = PerfPlugin.RealtimeProbes.Value;
            HeavyEffects = PerfPlugin.HeavyEffects.Value;
            BloomOn = PerfPlugin.BloomOn.Value;
            SunOnlyShadows = PerfPlugin.SunOnlyShadows.Value;
            TerrainDetail = Mathf.Clamp(PerfPlugin.TerrainDetail.Value, 0, 3);
            ParticleCull = Mathf.Clamp(PerfPlugin.ParticleCull.Value, 0, 3);
            ParticleBudget = Mathf.Clamp(PerfPlugin.ParticleBudget.Value, 0, 3);
            StreamingMips = PerfPlugin.StreamingMips.Value;
            Bypass = PerfPlugin.ForcedMode == ForcedMode.Vanilla
                || PerfPlugin.ForcedMode != ForcedMode.Optimized && PerfPlugin.Bypass.Value;
            VegetationMode = Mathf.Clamp(PerfPlugin.VegetationMode.Value, 0, 2);
            ZombieShadowMode = Mathf.Clamp(PerfPlugin.ZombieShadowMode.Value, 0, 4);
            HeadMode = Mathf.Clamp(PerfPlugin.HeadMode.Value, 0, 3);
            CharacterLod = Mathf.Clamp(PerfPlugin.CharacterLod.Value, 0, 2);
            PropLod = Mathf.Clamp(PerfPlugin.PropLod.Value, 0, 2);
            RenderScale = Mathf.Clamp(PerfPlugin.RenderScaleIndex.Value, 0, ZompiercerPerf.RenderScale.Scales.Length - 1);
            Upscaler = Mathf.Clamp(PerfPlugin.Upscaler.Value, 0, 1);
            Sharpness = Mathf.Clamp(PerfPlugin.Sharpness.Value, 0, 2);
            Sharpen = PerfPlugin.Sharpen.Value;
            MipBias = PerfPlugin.MipBias.Value;
            TargetFps = Mathf.Clamp(PerfPlugin.TargetFps.Value, 0, 5);
            SmallShadows = Mathf.Clamp(PerfPlugin.SmallShadowsMode.Value, 0, 3);
            Clouds = Mathf.Clamp(PerfPlugin.CloudsMode.Value, 0, 4);
            VolumeLight = Mathf.Clamp(PerfPlugin.VolumeLightMode.Value, 0, 3);
            GrassDistance = Mathf.Clamp(PerfPlugin.GrassDistanceMode.Value, 0, 4);
            GrassDensity = Mathf.Clamp(PerfPlugin.GrassDensityMode.Value, 0, 3);
            WaterUpdate = Mathf.Clamp(PerfPlugin.WaterUpdateMode.Value, 0, 2);
            AntiAliasing = Mathf.Clamp(PerfPlugin.AntiAliasingMode.Value, 0, 4);
            ProbeUpdate = Mathf.Clamp(PerfPlugin.ProbeUpdateMode.Value, 0, 2);
            if (VegetationMode == 0)
            {
                ThrottleBillboards = false;
                BillboardInterval = 1;
            }
            else if (VegetationMode == 1)
            {
                ThrottleBillboards = true;
                BillboardInterval = 1;
            }
            else
            {
                ThrottleBillboards = true;
                BillboardInterval = 2;
            }
            ShadowOffDistance = GraphicsTables.ZombieShadowDistance(ZombieShadowMode);
            HeadOffDistance = GraphicsTables.HeadDistance(HeadMode);
        }
    }

    static class CamMotion
    {
        public static bool Sampled;
        public static bool Moved = true;
        public static uint Version;
        static Vector3 lastPos;
        static Quaternion lastRot;
        static Transform lastCamera;

        public static void Sample(GlobalManager manager)
        {
            var camera = Camera.main;
            var transform = camera == null ? null : camera.transform;
            if (transform != lastCamera) { lastCamera = transform; Sampled = false; }
            if (transform == null)
            {
                Sampled = false;
                Moved = true;
                return;
            }
            Vector3 pos = transform.position;
            Quaternion rot = transform.rotation;
            if (!Sampled)
            {
                Sampled = true;
                Moved = true;
                lastPos = pos;
                lastRot = rot;
                Version = unchecked(Version + 1);
                return;
            }
            Moved = (pos - lastPos).sqrMagnitude > 0.04f || Quaternion.Angle(rot, lastRot) > 0.5f;
            if (Moved)
            {
                lastPos = pos;
                lastRot = rot;
                Version = unchecked(Version + 1);
            }
        }
    }

    static class ZombieLod
    {
        static readonly System.Runtime.CompilerServices.ConditionalWeakTable<ZombieAIController, ZState> States =
            new System.Runtime.CompilerServices.ConditionalWeakTable<ZombieAIController, ZState>();
        static readonly List<WeakReference> Tracked = new List<WeakReference>();

        sealed class ZState
        {
            public ObstacleAvoidanceType Avoidance;
            public bool AvoidanceSaved;
            public ObstacleAvoidanceType Applied = (ObstacleAvoidanceType)(-1);
            public Renderer[] Renderers;
            public ShadowCastingMode[] Shadows;
            public bool ShadowsFar;
            public bool HeadDisabledByMod;
            public SkinnedMeshRenderer[] Skins;
            public SkinQuality[] SkinOriginal;
            public int SkinBand;
            public Animator Animator;
            public AnimatorCullingMode Culling;
            public bool CullingSaved;
        }

        public static bool Busy(ZombieAIController zombie)
        {
            return zombie.doingFireAnimation
                || zombie.Staggered
                || zombie.WakesUp
                || zombie.attackRayActivator != 0
                || zombie.attackRayActivatorHunterAnimation
                || zombie.attackRayActivatorDoorAnimation
                || zombie.RunToExplode;
        }

        public static bool TryPlayerDistance(ZombieAIController zombie, out float distance)
        {
            distance = 0f;
            var manager = GlobalManager.global;
            if (manager == null || manager.controlledChar == null)
                return false;
            Transform player = manager.controlledChar.GetTransform;
            if (player == null)
                player = manager.controlledChar.transform;
            Transform self = zombie.thisTransform != null ? zombie.thisTransform : zombie.transform;
            distance = Vector3.Distance(self.position, player.position);
            return true;
        }

        static ZState StateOf(ZombieAIController zombie)
        {
            ZState state;
            if (!States.TryGetValue(zombie, out state))
            {
                state = new ZState();
                States.Add(zombie, state);
                if (Tracked.Count % 128 == 0) Tracked.RemoveAll(reference => reference.Target as ZombieAIController == null);
                Tracked.Add(new WeakReference(zombie));
            }
            return state;
        }

        public static void Release(ZombieAIController zombie)
        {
            if (zombie == null)
                return;
            ZState state;
            if (!States.TryGetValue(zombie, out state))
                return;
            if (zombie.navMeshAgent != null)
                RestoreAvoidance(state, zombie.navMeshAgent);
            RestoreShadows(state);
            RestoreHead(state, zombie);
            RestoreSkin(state);
            RestoreCulling(state);
            States.Remove(zombie);
            Tracked.RemoveAll(reference => ReferenceEquals(reference.Target, zombie));
        }

        public static void ApplySideCosts(ZombieAIController zombie, float distance)
        {
            var tune = PerfPlugin.Tune;
            var state = StateOf(zombie);
            if (zombie.zombieAnimation != null && zombie.zombieAnimation.animator != null)
            {
                var animator = zombie.zombieAnimation.animator;
                if (tune.AnimatorCulling && distance > tune.NearDistance)
                {
                    if (animator.cullingMode == AnimatorCullingMode.AlwaysAnimate)
                    {
                        state.Animator = animator; state.Culling = animator.cullingMode; state.CullingSaved = true;
                        animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
                    }
                }
                else RestoreCulling(state);
            }

            if (zombie.navMeshAgent != null)
            {
                if (tune.NavAvoidance)
                    ApplyAvoidance(state, zombie.navMeshAgent, distance);
                else
                    RestoreAvoidance(state, zombie.navMeshAgent);
            }

            if (tune.ShadowOffDistance > 0f)
                ApplyShadows(state, zombie, distance);
            else
                RestoreShadows(state);

            if (tune.HeadOffDistance > 0f)
                ApplyHead(state, zombie, distance);
            else
                RestoreHead(state, zombie);
            ApplySkinLod(state, zombie, distance);
        }

        static void ApplyAvoidance(ZState state, NavMeshAgent agent, float distance)
        {
            if (!state.AvoidanceSaved)
            {
                state.Avoidance = agent.obstacleAvoidanceType;
                state.AvoidanceSaved = true;
            }
            ObstacleAvoidanceType next = state.Avoidance;
            if (distance >= PerfPlugin.Tune.AvoidanceOffDistance)
                next = ObstacleAvoidanceType.NoObstacleAvoidance;
            else if (distance >= PerfPlugin.Tune.AvoidanceLowDistance)
                next = ObstacleAvoidanceType.LowQualityObstacleAvoidance;
            if (next == state.Applied)
                return;
            agent.obstacleAvoidanceType = next;
            state.Applied = next;
        }

        static void RestoreAvoidance(ZState state, NavMeshAgent agent)
        {
            if (!state.AvoidanceSaved || state.Applied == state.Avoidance)
                return;
            if (agent.obstacleAvoidanceType == state.Applied) agent.obstacleAvoidanceType = state.Avoidance;
            state.Applied = state.Avoidance;
        }

        static void RestoreCulling(ZState state)
        {
            if (!state.CullingSaved) return;
            if (state.Animator != null && state.Animator.cullingMode == AnimatorCullingMode.CullUpdateTransforms)
                state.Animator.cullingMode = state.Culling;
            state.CullingSaved = false;
        }

        static void RestoreShadows(ZState state)
        {
            if (state.Renderers == null || !state.ShadowsFar)
                return;
            state.ShadowsFar = false;
            for (int i = 0; i < state.Renderers.Length; i++)
            {
                if (state.Renderers[i] != null)
                    state.Renderers[i].shadowCastingMode = state.Shadows[i];
            }
        }

        static void RestoreHead(ZState state, ZombieAIController zombie)
        {
            if (!state.HeadDisabledByMod || zombie.headTracking == null)
                return;
            zombie.headTracking.enabled = true;
            state.HeadDisabledByMod = false;
        }

        static void ApplyShadows(ZState state, ZombieAIController zombie, float distance)
        {
            if (state.Renderers == null)
            {
                var found = zombie.GetComponentsInChildren<Renderer>(true);
                var meshes = new List<Renderer>(found.Length);
                for (int i = 0; i < found.Length; i++)
                {
                    if (found[i] is MeshRenderer || found[i] is SkinnedMeshRenderer)
                        meshes.Add(found[i]);
                }
                state.Renderers = meshes.ToArray();
                state.Shadows = new ShadowCastingMode[state.Renderers.Length];
                for (int i = 0; i < state.Renderers.Length; i++)
                    state.Shadows[i] = state.Renderers[i].shadowCastingMode;
            }

            float limit = PerfPlugin.Tune.ShadowOffDistance;
            bool far = state.ShadowsFar ? distance > limit - 18f : distance >= limit + 12f;
            if (far == state.ShadowsFar)
                return;
            state.ShadowsFar = far;
            for (int i = 0; i < state.Renderers.Length; i++)
            {
                var renderer = state.Renderers[i];
                if (renderer == null)
                    continue;
                renderer.shadowCastingMode = far ? ShadowCastingMode.Off : state.Shadows[i];
            }
        }

        static void ApplySkinLod(ZState state, ZombieAIController zombie, float distance)
        {
            EnsureSkins(state, zombie);
            if (state.Skins == null)
                return;
            int mode = PerfPlugin.Tune.CharacterLod;
            int band = SkinBand(state.SkinBand, distance, mode);
            if (band == state.SkinBand)
                return;
            state.SkinBand = band;
            SkinQuality quality = band <= 0 ? SkinQuality.Auto : (band == 1 ? SkinQuality.Bone2 : SkinQuality.Bone1);
            for (int i = 0; i < state.Skins.Length; i++)
            {
                if (state.Skins[i] == null)
                    continue;
                state.Skins[i].quality = band <= 0 ? state.SkinOriginal[i] : quality;
            }
        }

        static int SkinBand(int current, float distance, int mode)
        {
            if (mode <= 0)
                return 0;
            float midIn = mode == 1 ? 34f : 16f;
            float midOut = mode == 1 ? 46f : 28f;
            float farIn = mode == 1 ? 64f : 40f;
            float farOut = mode == 1 ? 80f : 52f;
            if (current >= 2)
            {
                if (distance < midIn)
                    return 0;
                if (distance < farIn)
                    return 1;
                return 2;
            }
            if (current == 1)
            {
                if (distance >= farOut)
                    return 2;
                if (distance < midIn)
                    return 0;
                return 1;
            }
            if (distance >= farOut)
                return 2;
            if (distance >= midOut)
                return 1;
            return 0;
        }

        static void EnsureSkins(ZState state, ZombieAIController zombie)
        {
            if (state.Skins != null)
                return;
            var found = zombie.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            state.Skins = found;
            state.SkinOriginal = new SkinQuality[found.Length];
            for (int i = 0; i < found.Length; i++)
                state.SkinOriginal[i] = found[i].quality;
        }

        static void RestoreSkin(ZState state)
        {
            if (state.Skins == null)
                return;
            state.SkinBand = 0;
            for (int i = 0; i < state.Skins.Length; i++)
            {
                if (state.Skins[i] != null)
                    state.Skins[i].quality = state.SkinOriginal[i];
            }
        }

        public static void ReleaseAll()
        {
            var previous = Tracked.ToArray();
            Tracked.Clear();
            for (int i = previous.Length - 1; i >= 0; i--)
            {
                var zombie = previous[i].Target as ZombieAIController;
                if (zombie != null) Release(zombie);
            }
        }

        static void ApplyHead(ZState state, ZombieAIController zombie, float distance)
        {
            var head = zombie.headTracking;
            if (head == null)
                return;
            if (!state.HeadDisabledByMod && head.enabled && distance > PerfPlugin.Tune.HeadOffDistance)
            {
                head.enabled = false;
                state.HeadDisabledByMod = true;
            }
            else if (state.HeadDisabledByMod && distance <= PerfPlugin.Tune.HeadOffDistance)
            {
                head.enabled = true;
                state.HeadDisabledByMod = false;
            }
        }
    }

    [HarmonyPatch(typeof(Camera), "get_main")]
    static class CameraMainCache
    {
        static Camera cached;
        static int frame = -1;

        static bool Prefix(ref Camera __result)
        {
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0 || !PerfPlugin.Tune.CacheMainCamera)
                return true;
            if (cached != null && cached.isActiveAndEnabled && cached.CompareTag("MainCamera") && frame == Time.frameCount)
            {
                __result = cached;
                return false;
            }
            return true;
        }

        static void Postfix(Camera __result)
        {
            cached = __result;
            frame = Time.frameCount;
        }
    }

    [HarmonyPatch(typeof(GlobalManager), "Update")]
    static class GlobalManagerTick
    {
        static void Postfix(GlobalManager __instance)
        {
            if (!PerfPlugin.Tune.Bypass && PerfPlugin.Tune.Preset != 0 && PerfPlugin.Tune.ThrottleBillboards)
                CamMotion.Sample(__instance);
        }
    }

    [HarmonyPatch(typeof(ZombieAIController), "Update")]
    static class ZombieAiPatch
    {
        static void Prefix(ZombieAIController __instance)
        {
            // Never skip native AI or overwrite DistanceToPlayer: native timers
            // and the LAN target/attack prefix must run on every scheduled Update.
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0 || !PerfPlugin.Tune.DistanceLod || LanCompatibility.Active || __instance.dead)
            {
                ZombieLod.Release(__instance);
                return;
            }
            float distance;
            if (!ZombieLod.TryPlayerDistance(__instance, out distance))
                return;
            ZombieLod.ApplySideCosts(__instance, distance);
        }
    }

    [HarmonyPatch(typeof(EnviroVegetationInstance), "LateUpdate")]
    static class VegetationBillboard
    {
        sealed class Seen { public uint Version; }
        static readonly System.Runtime.CompilerServices.ConditionalWeakTable<EnviroVegetationInstance, Seen> States =
            new System.Runtime.CompilerServices.ConditionalWeakTable<EnviroVegetationInstance, Seen>();
        static bool Prefix(EnviroVegetationInstance __instance)
        {
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0 || !PerfPlugin.Tune.ThrottleBillboards)
                return true;
            if (!CamMotion.Sampled) return true;
            Seen state;
            if (!States.TryGetValue(__instance, out state))
            {
                States.Add(__instance, new Seen { Version = CamMotion.Version });
                return true;
            }
            int interval = PerfPlugin.Tune.BillboardInterval;
            if (!PerfPolicy.BillboardDue(state.Version, CamMotion.Version, interval, __instance.GetInstanceID(), Time.frameCount)) return false;
            state.Version = CamMotion.Version;
            return true;
        }
    }

    [HarmonyPatch(typeof(AQUAS_Reflection), "OnWillRenderObject")]
    static class WaterReflections
    {
        sealed class SizeState { public int Original, Applied; public bool Changed, Rendered; }
        static readonly System.Runtime.CompilerServices.ConditionalWeakTable<AQUAS_Reflection, SizeState> Sizes =
            new System.Runtime.CompilerServices.ConditionalWeakTable<AQUAS_Reflection, SizeState>();
        static readonly List<WeakReference> Tracked = new List<WeakReference>();

        public static void RestoreSizes()
        {
            for (int i = Tracked.Count - 1; i >= 0; i--)
            {
                var water = Tracked[i].Target as AQUAS_Reflection;
                if (water == null) { Tracked.RemoveAt(i); continue; }
                SizeState state;
                if (Sizes.TryGetValue(water, out state) && state.Changed)
                {
                    if (water.m_TextureSize == state.Applied) water.m_TextureSize = state.Original;
                    state.Changed = false;
                }
            }
        }

        static bool Prefix(AQUAS_Reflection __instance)
        {
            SizeState state;
            if (!Sizes.TryGetValue(__instance, out state))
            {
                state = new SizeState { Original = __instance.m_TextureSize };
                if (Tracked.Count % 64 == 0) Tracked.RemoveAll(reference => reference.Target as AQUAS_Reflection == null);
                Sizes.Add(__instance, state); Tracked.Add(new WeakReference(__instance));
            }
            if (!state.Changed || __instance.m_TextureSize != state.Applied) state.Original = __instance.m_TextureSize;
            bool vanilla = PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0;
            int cap = vanilla ? 0 : PerfPlugin.Tune.WaterReflectionSize;
            if (cap < 0) return false;
            // Reuse the last reflection on skipped frames; the first one is always rendered.
            int interval = vanilla ? 1 : PerfPlugin.Tune.WaterUpdate + 1;
            if (interval > 1 && state.Rendered && (Time.frameCount + (__instance.GetInstanceID() & 0xff)) % interval != 0)
                return false;
            state.Rendered = true;
            int size = cap == 0 ? state.Original : Math.Min(state.Original, cap);
            __instance.m_TextureSize = size;
            state.Applied = size; state.Changed = size != state.Original;
            return true;
        }
    }
}
