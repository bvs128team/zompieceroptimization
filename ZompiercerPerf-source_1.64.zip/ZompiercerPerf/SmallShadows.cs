using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace ZompiercerPerf
{
    // Small props stop casting shadows beyond a distance; up close everything is as in the game.
    // Discovery walks the scene a few nodes per frame. A shadow mode changed by someone else
    // (GDOC occlusion culling, game scripts) is adopted as the new original instead of fought.
    static class SmallShadows
    {
        sealed class Caster
        {
            public MeshRenderer Renderer;
            public ShadowCastingMode Original, Applied;
            public bool Far;
        }

        const float MaxSize = 2.5f;      // largest bounds side counted as "small", metres
        const float Hysteresis = 6f;
        const int MaxCasters = 12000;
        static readonly List<Caster> Casters = new List<Caster>();
        static readonly HashSet<int> Known = new HashSet<int>();
        static readonly Stack<Transform> Scan = new Stack<Transform>();
        static int cursor;
        static float nextScan;
        static bool active;

        public static int Count { get { return Casters.Count; } }

        public static void Tick()
        {
            var tune = PerfPlugin.Tune;
            float limit = GraphicsTables.SmallShadowDistance(tune.SmallShadows);
            var manager = GlobalManager.global;
            var camera = manager != null && manager.MainCamera != null ? manager.MainCamera : null;
            if (tune.Bypass || tune.Preset == 0 || limit <= 0f || camera == null || manager.controlledChar == null)
            {
                Restore();
                return;
            }
            active = true;
            StepScan(manager);
            Refresh(camera.transform.position, limit);
        }

        static void StepScan(GlobalManager manager)
        {
            if (Scan.Count == 0)
            {
                if (Time.unscaledTime < nextScan)
                    return;
                nextScan = Time.unscaledTime + 5f;
                Casters.RemoveAll(caster => caster.Renderer == null);
                Known.Clear();
                foreach (var caster in Casters) Known.Add(caster.Renderer.GetInstanceID());
                for (int s = 0; s < SceneManager.sceneCount; s++)
                {
                    var scene = SceneManager.GetSceneAt(s);
                    if (scene.isLoaded)
                        foreach (var root in scene.GetRootGameObjects()) Scan.Push(root.transform);
                }
            }
            var player = manager.controlledChar.transform;
            var view = manager.MainCamera != null ? manager.MainCamera.transform : null;
            for (int n = 0; n < 64 && Scan.Count > 0; n++)
            {
                var node = Scan.Pop();
                if (node == null || !node.gameObject.activeInHierarchy || node == player || node == view
                    || node.name.StartsWith("__Perf"))
                    continue;
                // Zombies have their own distance shadows; their subtree is skipped as a whole.
                if (node.GetComponent<ZombieAIController>() != null)
                    continue;
                for (int c = 0; c < node.childCount; c++) Scan.Push(node.GetChild(c));
                var renderer = node.GetComponent<MeshRenderer>();
                if (renderer != null)
                    Consider(renderer);
            }
        }

        static void Consider(MeshRenderer renderer)
        {
            if (Casters.Count >= MaxCasters || !renderer.enabled || Known.Contains(renderer.GetInstanceID()))
                return;
            var mode = renderer.shadowCastingMode;
            if (mode != ShadowCastingMode.On && mode != ShadowCastingMode.TwoSided)
                return;
            var size = renderer.bounds.size;
            if (Mathf.Max(size.x, Mathf.Max(size.y, size.z)) > MaxSize)
                return;
            Known.Add(renderer.GetInstanceID());
            Casters.Add(new Caster { Renderer = renderer, Original = mode, Applied = mode });
        }

        static void Refresh(Vector3 eye, float limit)
        {
            int steps = Mathf.Min(400, Casters.Count);
            for (int n = 0; n < steps; n++)
            {
                if (cursor >= Casters.Count) cursor = 0;
                var caster = Casters[cursor++];
                var renderer = caster.Renderer;
                if (renderer == null)
                    continue;
                var current = renderer.shadowCastingMode;
                if (current != caster.Applied)
                {
                    caster.Original = current; // someone else set it: that is the game's value now
                    caster.Applied = current;
                }
                float sqr = (renderer.bounds.center - eye).sqrMagnitude;
                float edge = caster.Far ? limit - Hysteresis : limit + Hysteresis;
                caster.Far = sqr > edge * edge;
                bool castsNormally = caster.Original == ShadowCastingMode.On || caster.Original == ShadowCastingMode.TwoSided;
                var wanted = caster.Far && castsNormally ? ShadowCastingMode.Off : caster.Original;
                if (wanted != current)
                {
                    renderer.shadowCastingMode = wanted;
                    caster.Applied = wanted;
                }
            }
        }

        public static void Restore()
        {
            if (!active)
                return;
            for (int i = 0; i < Casters.Count; i++)
            {
                var caster = Casters[i];
                if (caster.Renderer != null && caster.Renderer.shadowCastingMode == caster.Applied)
                    caster.Renderer.shadowCastingMode = caster.Original;
            }
            Casters.Clear();
            Known.Clear();
            Scan.Clear();
            cursor = 0;
            nextScan = 0f;
            active = false;
        }
    }
}
