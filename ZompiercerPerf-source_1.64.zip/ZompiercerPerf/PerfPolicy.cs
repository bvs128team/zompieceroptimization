using System;

namespace ZompiercerPerf
{
    internal static class PerfPolicy
    {
        internal static bool BillboardDue(uint shown, uint latest, int interval, int id, int frame)
        { return shown != latest && (interval <= 1 || frame % interval == (id & int.MaxValue) % interval); }
        // Benchmark stuck test over fixed time windows, so it does not depend on the frame rate.
        // Returns true when a window closed; the caller then moves its anchor to the current position.
        internal static bool StuckStep(ref float window, ref float stuck, float frameSeconds, float movedSinceAnchor,
            float windowSeconds, float minimumMove)
        {
            window += Math.Max(0f, frameSeconds);
            if (window < windowSeconds) return false;
            if (movedSinceAnchor < minimumMove) stuck += window;
            else stuck = 0f;
            window = 0f;
            return true;
        }
        internal static float Distance(float value, float fallback, float minimum, float maximum)
        {
            if (float.IsNaN(value) || float.IsInfinity(value)) value = fallback;
            return Math.Max(minimum, Math.Min(maximum, value));
        }
    }
}
