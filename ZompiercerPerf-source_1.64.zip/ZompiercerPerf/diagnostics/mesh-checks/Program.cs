using System;
using System.Collections.Generic;
using System.Diagnostics;
using ZompiercerPerf;

static class Program
{
    static void Check(bool pass, string name)
    {
        if (!pass) throw new Exception("FAIL: " + name);
        Console.WriteLine("PASS: " + name);
    }

    static MeshLodPolicy.Data Grid(int segments, bool split, bool seam)
    {
        int width = segments + 1;
        int count = width * width;
        var data = new MeshLodPolicy.Data
        {
            Positions = new float[count * 3], Normals = new float[count * 3],
            Uv = new float[count * 2], Tangents = new float[count * 4],
            Submeshes = split ? new int[2][] : new int[1][]
        };
        for (int y = 0; y < width; y++)
        for (int x = 0; x < width; x++)
        {
            int i = y * width + x;
            data.Positions[i * 3] = x / (float)segments;
            data.Positions[i * 3 + 1] = y / (float)segments;
            data.Normals[i * 3 + 2] = 1;
            data.Uv[i * 2] = x / (float)segments;
            data.Uv[i * 2 + 1] = y / (float)segments;
            data.Tangents[i * 4] = data.Tangents[i * 4 + 3] = 1;
        }
        var first = new List<int>();
        var second = new List<int>();
        for (int y = 0; y < segments; y++)
        for (int x = 0; x < segments; x++)
        {
            int a = y * width + x, b = a + 1, c = a + width, d = c + 1;
            var target = split && x >= segments / 2 ? second : first;
            target.Add(a); target.Add(b); target.Add(c);
            target.Add(b); target.Add(d); target.Add(c);
        }
        data.Submeshes[0] = first.ToArray();
        if (split) data.Submeshes[1] = second.ToArray();
        if (!seam) return data;

        // Independent duplicate seam vertices on the right half carry shifted UVs.
        // The left half keeps its original indices and positions.
        var p = new List<float>(data.Positions);
        var n = new List<float>(data.Normals);
        var uv = new List<float>(data.Uv);
        var t = new List<float>(data.Tangents);
        var copies = new Dictionary<int, int>();
        for (int j = 0; j < data.Submeshes[1].Length; j++)
        {
            int original = data.Submeshes[1][j];
            if (original % width != segments / 2) continue;
            int copy;
            if (!copies.TryGetValue(original, out copy))
            {
                copy = p.Count / 3;
                copies[original] = copy;
                for (int k = 0; k < 3; k++) { p.Add(data.Positions[original * 3 + k]); n.Add(data.Normals[original * 3 + k]); }
                uv.Add(data.Uv[original * 2] + 0.5f); uv.Add(data.Uv[original * 2 + 1]);
                for (int k = 0; k < 4; k++) t.Add(data.Tangents[original * 4 + k]);
            }
            data.Submeshes[1][j] = copy;
        }
        data.Positions = p.ToArray(); data.Normals = n.ToArray();
        data.Uv = uv.ToArray(); data.Tangents = t.ToArray();
        return data;
    }

    static int Triangles(MeshLodPolicy.Data data)
    {
        int total = 0;
        foreach (int[] submesh in data.Submeshes) total += submesh.Length / 3;
        return total;
    }

    static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }

    static void Validate(MeshLodPolicy.Data source, MeshLodPolicy.Data output)
    {
        Check(output != null, "eligible grid reduces");
        Check(output.Positions.Length <= source.Positions.Length * 0.8, "at least 20% fewer vertices");
        Check(Triangles(output) <= Triangles(source) * 0.8, "at least 20% fewer triangles");
        Check(output.Submeshes.Length == source.Submeshes.Length, "submesh count retained");
        int count = output.Positions.Length / 3;
        foreach (int[] submesh in output.Submeshes)
        {
            Check(submesh.Length > 0, "nonempty submesh");
            foreach (int index in submesh) CheckIndex(index, count);
            for (int j = 0; j < submesh.Length; j += 3)
            {
                int a = submesh[j], b = submesh[j + 1], c = submesh[j + 2];
                if (a == b || b == c || a == c) throw new Exception("FAIL: degenerate output indices");
                float ax = output.Positions[a * 3], ay = output.Positions[a * 3 + 1];
                float bx = output.Positions[b * 3], by = output.Positions[b * 3 + 1];
                float cx = output.Positions[c * 3], cy = output.Positions[c * 3 + 1];
                if ((bx - ax) * (cy - ay) - (by - ay) * (cx - ax) <= 0)
                    throw new Exception("FAIL: degenerate or flipped output face");
            }
        }
        foreach (float value in output.Positions) CheckFinite(value);
        foreach (float value in output.Normals) CheckFinite(value);
        foreach (float value in output.Uv) CheckFinite(value);
        foreach (float value in output.Tangents) CheckFinite(value);
        bool within = true;
        for (int i = 0; i < count; i++)
            within &= output.Positions[i * 3] >= 0 && output.Positions[i * 3] <= 1 &&
                output.Positions[i * 3 + 1] >= 0 && output.Positions[i * 3 + 1] <= 1;
        Check(within, "reduced positions remain inside source bounds");
    }

    static void CheckIndex(int index, int count)
    {
        if ((uint)index >= count) throw new Exception("FAIL: output index range");
    }
    static void CheckFinite(float value)
    {
        if (!Finite(value)) throw new Exception("FAIL: finite output attributes");
    }

    static void Main()
    {
        var grid = Grid(80, false, false);
        int originalChecksum = grid.Submeshes[0][100] + (int)(grid.Positions[303] * 1000);
        Validate(grid, MeshLodPolicy.Reduce(grid));
        Check(originalChecksum == grid.Submeshes[0][100] + (int)(grid.Positions[303] * 1000), "source arrays unchanged");

        var split = Grid(80, true, true);
        var reduced = MeshLodPolicy.Reduce(split);
        Validate(split, reduced);
        bool leftSeam = false, rightSeam = false;
        for (int i = 0; i < reduced.Positions.Length / 3; i++)
        {
            if (Math.Abs(reduced.Positions[i * 3] - 0.5f) > 0.000001f) continue;
            if (Math.Abs(reduced.Uv[i * 2] - 0.5f) < 0.000001f) leftSeam = true;
            if (Math.Abs(reduced.Uv[i * 2] - 1f) < 0.000001f) rightSeam = true;
        }
        Check(leftSeam && rightSeam, "duplicate UV seam preserved");

        var hard = Grid(80, true, true);
        int firstDuplicate = 81 * 81;
        for (int i = firstDuplicate; i < hard.Positions.Length / 3; i++)
        {
            hard.Normals[i * 3] = 1;
            hard.Normals[i * 3 + 2] = 0;
        }
        var hardReduced = MeshLodPolicy.Reduce(hard);
        Check(hardReduced != null, "hard-normal seam mesh reduces");
        bool hardNormal = false;
        for (int i = 0; i < hardReduced.Positions.Length / 3; i++)
            if (Math.Abs(hardReduced.Positions[i * 3] - 0.5f) < 0.000001f &&
                hardReduced.Normals[i * 3] == 1 && hardReduced.Normals[i * 3 + 2] == 0)
                hardNormal = true;
        Check(hardNormal, "hard normal seam preserved");

        var invalid = Grid(80, false, false);
        invalid.Submeshes[0][0] = invalid.Positions.Length / 3;
        Check(MeshLodPolicy.Reduce(invalid) == null, "out-of-range source index rejected");
        invalid = Grid(80, false, false);
        invalid.Submeshes[0][1] = invalid.Submeshes[0][0];
        Check(MeshLodPolicy.Reduce(invalid) == null, "degenerate source face rejected");
        invalid = Grid(80, false, false);
        invalid.Normals[0] = float.NaN;
        Check(MeshLodPolicy.Reduce(invalid) == null, "nonfinite attribute rejected");
        Check(MeshLodPolicy.Reduce(Grid(10, false, false)) == null, "small mesh rejected");
        Check(MeshLodPolicy.Reduce(Grid(120, false, false)) == null, "large mesh rejected before work"); // 121^2 > MaximumVertices (12000)
        foreach (int segments in new[] { 40, 80, 100 })
        {
            var caseMesh = Grid(segments, false, false);
            var watch = Stopwatch.StartNew();
            var caseResult = MeshLodPolicy.Reduce(caseMesh);
            watch.Stop();
            Console.WriteLine("INFO: " + caseMesh.Positions.Length / 3 + " vertices, " +
                Triangles(caseMesh) + " triangles: " + watch.ElapsedMilliseconds + " ms; result " +
                (caseResult == null ? "rejected" : Triangles(caseResult).ToString() + " triangles"));
        }
        Console.WriteLine("PASS: mesh policy checks complete");
    }
}
