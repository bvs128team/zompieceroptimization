using System;
using ZompiercerPerf;

int passed = 0;
void Check(bool condition, string name, bool quiet = false)
{
    if (!condition) throw new Exception("FAIL: " + name);
    passed++;
    if (!quiet) Console.WriteLine("PASS: " + name);
}

Check(PerfPolicy.Distance(float.NaN, 40f, 10f, 100f) == 40f, "NaN uses fallback");
Check(PerfPolicy.Distance(float.PositiveInfinity, 40f, 10f, 100f) == 40f, "positive infinity uses fallback");
Check(PerfPolicy.Distance(float.NegativeInfinity, 40f, 10f, 100f) == 40f, "negative infinity uses fallback");
Check(PerfPolicy.Distance(1f, 40f, 10f, 100f) == 10f, "distance clamps low");
Check(PerfPolicy.Distance(120f, 40f, 10f, 100f) == 100f, "distance clamps high");
Check(PerfPolicy.Distance(60f, 40f, 10f, 100f) == 60f, "distance preserves valid value");
Check(!PerfPolicy.BillboardDue(7, 7, 4, 0, 0), "unchanged camera does not refresh");
Check(PerfPolicy.BillboardDue(7, 8, 1, 0, 0), "interval one refreshes immediately");

// Every phase eventually sees a change, even if the frame when it changed was skipped.
for (int interval = 2; interval <= 16; interval++)
for (int id = -3; id <= 3; id++)
for (int changedAt = 0; changedAt < interval; changedAt++)
{
    int due = 0;
    for (int frame = changedAt + 1; frame <= changedAt + interval; frame++)
        if (PerfPolicy.BillboardDue(7, 8, interval, id, frame)) due++;
    Check(due == 1, $"billboard catch-up interval={interval} id={id} phase={changedAt}", true);
}
Console.WriteLine("PASS: billboard refresh catches every interval/id/change phase");
Check(LodTransition.Weight(0, 40, 60) == 0, "near object retains full detail");
Check(LodTransition.Weight(100, 40, 60) == 1, "far object reaches target LOD");
Check(LodTransition.Weight(50, 40, 60) == .5f, "transition midpoint");
Check(LodTransition.Weight(float.NaN, 40, 60) == 0, "invalid distance retains original");
foreach (float fps in new[] { 20f, 30f, 60f, 144f })
{
    float shown = 0f;
    int frames = 0;
    while (shown < 1f && frames < 500)
    {
        float previous = shown;
        shown = LodTransition.Step(shown, 1f, 1f / fps, .65f);
        Check(shown > previous && shown <= 1f, "fade-in monotonic and bounded", true);
        frames++;
    }
    Check(shown == 1f && frames / fps >= .64f && frames / fps < .72f, "fade duration independent of frame rate");
    float reversal = LodTransition.Step(.6f, 0f, 1f / fps, .65f);
    Check(reversal < .6f && reversal > 0f, "direction reversal does not snap");
    frames = 0;
    while (shown > 0f && frames++ < 500) shown = LodTransition.Step(shown, 0f, 1f / fps, .65f);
    Check(shown == 0f, "fade-out reaches exact hidden endpoint");
}
Check(LodTransition.Step(0f, 1f, 10f, .65f) < .08f, "teleport or hitch cannot instantly reveal object");
Check(LodTransition.Step(1f, 0f, 10f, .65f) > .92f, "teleport or hitch cannot instantly hide object");
Check(LodTransition.Step(.4f, 1f, 0f, .65f) == .4f, "zero elapsed time preserves fade");
Check(LodTransition.Step(.4f, 1f, -.5f, .65f) == .4f, "negative elapsed time preserves fade");
Check(LodTransition.Step(.5f, .5f, .01f, .65f) == .5f, "settled fade remains settled");
for (int visible = 0; visible <= 10; visible++)
for (int detail = 0; detail <= 100; detail++)
{
    float opacity = visible / 10f;
    float front = opacity * (1f - detail / 100f);
    float back = LodTransition.CompositeAlpha(opacity * detail / 100f, front);
    float composed = front + back * (1f - front);
    Check(Math.Abs(composed - opacity) < .00001f, "LOD blend preserves intended opacity", true);
}
Console.WriteLine("PASS: high/low composition has no midpoint transparency gap");
var levels = new[] { .6f, .3f, .05f };
Check(LodTransition.Level(.8f, levels, 0) == 0, "native LOD0 near camera");
Check(LodTransition.Level(.4f, levels, 0) == 1, "native LOD1 threshold preserved");
Check(LodTransition.Level(.1f, levels, 0) == 2, "native LOD2 threshold preserved");
Check(LodTransition.Level(.01f, levels, 0) == 3, "native culling threshold preserved");
Check(LodTransition.Level(.8f, levels, 1) == 1, "native maximumLODLevel respected");
var weights = new[] { 0f, 0f, 0f, 1f };
LodTransition.StepWeights(weights, 0, 1f / 60f, .65f);
Check(weights[0] > 0 && weights[0] < .03f && weights[3] > .97f, "native cull-to-visible starts gradually");
for (int frame = 0; frame < 50; frame++) LodTransition.StepWeights(weights, 0, 1f / 60f, .65f);
Check(weights[0] == 1 && weights[3] == 0, "native fade-in reaches full detail");
LodTransition.StepWeights(weights, 2, .05f, .65f);
LodTransition.StepWeights(weights, 1, .05f, .65f);
Check(Math.Abs(weights[0] + weights[1] + weights[2] + weights[3] - 1f) < .00001f,
    "rapid tier changes preserve total coverage including cull");
for (int frame = 0; frame < 50; frame++) LodTransition.StepWeights(weights, 3, 1f / 60f, .65f);
Check(weights[3] == 1 && weights[0] == 0 && weights[1] == 0 && weights[2] == 0, "native fade-out reaches cull");
// Benchmark stuck test (1.64 review): walking at 4 m/s must never count as stuck at any frame rate,
// standing still must switch the goal after the 2.2 s limit, a single hitch must not break it.
foreach (int fps in new[] { 30, 60, 90, 120, 144, 240, 360 })
{
    foreach (float speed in new[] { 0f, 1.5f, 4f })
    {
        float window = 0f, stuck = 0f, anchor = 0f, x = 0f, firstSwitch = -1f, dt = 1f / fps;
        int switches = 0;
        for (int frame = 0; frame < fps * 30; frame++)
        {
            float step = frame == fps * 10 ? .6f : dt; // one long hitch in the middle
            x += speed * step;
            if (PerfPolicy.StuckStep(ref window, ref stuck, step, x - anchor, .5f, .35f)) anchor = x;
            if (stuck > 2.2f) { stuck = 0f; switches++; if (firstSwitch < 0f) firstSwitch = frame * dt; }
        }
        if (speed > 0f)
            Check(switches == 0, $"walking {speed} m/s at {fps} FPS is never stuck", true);
        else
            Check(switches > 0 && firstSwitch >= 2.2f && firstSwitch <= 3.1f, $"standing still at {fps} FPS switches goal after 2.2-3.1 s", true);
    }
}
Console.WriteLine($"PASS: {passed} pure policy cases");
