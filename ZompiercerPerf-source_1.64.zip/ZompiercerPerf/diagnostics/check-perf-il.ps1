param(
    [string]$GameRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path,
    [string]$ModPath = (Join-Path $PSScriptRoot '..\bin\Release\net472\ZompiercerPerf.dll')
)

$ErrorActionPreference = 'Stop'
$passed = 0
function Check([bool]$condition, [string]$description) {
    if (-not $condition) { throw "FAIL: $description" }
    $script:passed++
    Write-Host "PASS: $description"
}
function TypeOf($assembly, [string]$name) {
    foreach ($type in $assembly.MainModule.Types) {
        if ($type.FullName -eq $name -or $type.Name -eq $name) { return $type }
        foreach ($nested in $type.NestedTypes) {
            if ($nested.FullName -eq $name -or $nested.Name -eq $name) { return $nested }
        }
    }
    return $null
}
function MethodOf($type, [string]$name) {
    if ($null -eq $type) { return $null }
    return @($type.Methods | Where-Object Name -eq $name)
}
function BodyOf($method) {
    if ($null -eq $method -or -not $method.HasBody) { return @() }
    return @($method.Body.Instructions)
}
function Calls($method, [string]$typeName, [string]$methodName) {
    return @((BodyOf $method) | Where-Object {
        $_.Operand -is [Mono.Cecil.MethodReference] -and
        $_.Operand.DeclaringType.FullName -eq $typeName -and
        $_.Operand.Name -eq $methodName
    })
}
function Strings($method) {
    return @((BodyOf $method) | Where-Object { $_.OpCode.Name -eq 'ldstr' } | ForEach-Object { [string]$_.Operand })
}
function PatchTarget($type, [string]$targetType, [string]$targetMethod) {
    foreach ($attribute in $type.CustomAttributes) {
        if ($attribute.AttributeType.Name -ne 'HarmonyPatch') { continue }
        $values = @($attribute.ConstructorArguments | ForEach-Object Value)
        if (@($values | Where-Object { $_ -is [Mono.Cecil.TypeReference] -and $_.Name -eq $targetType }).Count -gt 0 -and
            @($values | Where-Object { $_ -is [string] -and $_ -eq $targetMethod }).Count -gt 0) { return $true }
    }
    return $false
}

$cecilPath = Join-Path $GameRoot 'BepInEx\core\Mono.Cecil.dll'
$gamePath = Join-Path $GameRoot 'Zompiercer_Data\Managed\Assembly-CSharp.dll'
$lanPath = Join-Path $GameRoot 'BepInEx\plugins\ZompiercerLAN.dll'
foreach ($path in @($cecilPath, $gamePath, $ModPath, $lanPath)) {
    Check (Test-Path -LiteralPath $path -PathType Leaf) "required assembly exists: $([IO.Path]::GetFileName($path))"
}
Add-Type -Path $cecilPath
$game = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($gamePath)
$mod = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($ModPath)
$lan = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($lanPath)
try {
    $plugin = TypeOf $mod 'PerfPlugin'
    $pluginMetadata = @($plugin.CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' })
    Check ($pluginMetadata.Count -eq 1 -and @($pluginMetadata[0].ConstructorArguments).Count -eq 3 -and
        [string]$pluginMetadata[0].ConstructorArguments[2].Value -ceq '1.64') 'plugin metadata declares exact version 1.64'

    $ai = TypeOf $mod 'ZombieAiPatch'
    $aiPrefix = @(MethodOf $ai 'Prefix')[0]
    Check ($null -ne $aiPrefix -and $aiPrefix.ReturnType.FullName -eq 'System.Void') 'Zombie AI prefix cannot skip native Update'
    Check (PatchTarget $ai 'ZombieAIController' 'Update') 'Zombie AI patch targets native Update'
    Check (@(MethodOf (TypeOf $game 'ZombieAIController') 'Update').Count -gt 0) 'native ZombieAIController.Update exists'
    Check (@((BodyOf $aiPrefix) | Where-Object { $_.OpCode.Name -eq 'stfld' -and $_.Operand.Name -eq 'DistanceToPlayer' }).Count -eq 0) 'AI prefix does not overwrite DistanceToPlayer'
    Check ($null -eq (TypeOf $mod 'ZombieAnimationUpdatePatch')) 'removed animation Update patch type is absent'
    $animationPatches = @($mod.MainModule.Types | ForEach-Object { $_.NestedTypes } | Where-Object { PatchTarget $_ 'ZombieAnimation' 'Update' })
    Check ($animationPatches.Count -eq 0) 'no nested Harmony patch targets ZombieAnimation.Update'

    $nativeAi = @(MethodOf (TypeOf $game 'ZombieAIController') 'Update')[0]
    Check ((Calls $nativeAi 'UnityEngine.Time' 'get_deltaTime').Count -gt 0) 'native AI Update advances time based on deltaTime'

    $camera = TypeOf $mod 'CoreCameraCache'
    $cameraMethods = @($camera.Methods | Where-Object { $_.HasBody })
    $directCamera = @($cameraMethods | ForEach-Object { BodyOf $_ } | Where-Object {
        $_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.DeclaringType.Name -eq 'GlobalManager' -and $_.Operand.Name -eq 'MainCamera'
    })
    Check ($directCamera.Count -eq 0) 'camera cache does not read GlobalManager.MainCamera field'

    $menu = TypeOf $mod 'GraphicsMenu'
    $menuPatch = @(MethodOf $menu 'Patch')[0]
    $menuNames = @('VideoOptionButton', 'AudioOptionButton', 'ControlInOptionButton', 'MouseOptionButton', 'ControlInOptionGamepadButton', 'DifficultyOptionButton', 'BackToOptionsButton', 'CancelOption', 'ExitOptionInGameButton', 'OptionInGameButton')
    $menuStrings = Strings $menuPatch
    Check (@($menuNames | Where-Object { $_ -notin $menuStrings }).Count -eq 0) 'graphics menu lists ten navigation hooks'
    $gui = TypeOf $game 'GUIManager'
    Check (@($menuNames | Where-Object { @(MethodOf $gui $_).Count -eq 0 }).Count -eq 0) 'all ten GUIManager methods exist in installed game'
    Check ((Calls $menuPatch 'HarmonyLib.Harmony' 'Patch').Count -gt 0) 'graphics menu dynamically registers postfixes'
    Check (@(MethodOf $menu 'HideIfCovered').Count -gt 0) 'graphics menu postfix exists'
    $remember = TypeOf $mod 'RememberManager'
    Check ((PatchTarget $remember 'GUIManager' 'Start') -and @(MethodOf $remember 'Postfix').Count -gt 0) 'GUIManager.Start manager capture patch exists'

    $graphics = TypeOf $mod 'GraphicsApply'
    $graphicsPatch = @(MethodOf $graphics 'Patch')[0]
    Check ((Strings $graphicsPatch) -contains 'SetQualityLevel') 'quality hook enumerates SetQualityLevel overloads'
    Check ((Calls $graphicsPatch 'HarmonyLib.Harmony' 'Patch').Count -gt 0) 'quality hook registers postfixes'
    Check (@(MethodOf $graphics 'OnGameQualityChanged').Count -gt 0) 'quality change postfix exists'

    $apply = @(MethodOf $graphics 'Apply')[0]
    $applyBody = BodyOf $apply
    $bypassReads = @($applyBody | Where-Object { $_.OpCode.Name -eq 'ldfld' -and $_.Operand.DeclaringType.FullName -eq 'ZompiercerPerf.Tune' -and $_.Operand.Name -eq 'Bypass' })
    $presetReads = @($applyBody | Where-Object { $_.OpCode.Name -eq 'ldfld' -and $_.Operand.DeclaringType.FullName -eq 'ZompiercerPerf.Tune' -and $_.Operand.Name -eq 'Preset' })
    $restoreCalls = Calls $apply 'ZompiercerPerf.GraphicsApply' 'RestoreVanilla'
    Check ($bypassReads.Count -eq 1 -and $presetReads.Count -eq 1 -and $restoreCalls.Count -eq 1) 'apply checks both disable modes and has one shared full-restore call'
    $bypassIndex = [array]::IndexOf($applyBody, $bypassReads[0])
    $presetIndex = [array]::IndexOf($applyBody, $presetReads[0])
    $restoreGate = $applyBody[$presetIndex + 2]
    $bypassBranch = $applyBody[$bypassIndex + 1]
    $presetBranch = $applyBody[$presetIndex + 1]
    Check ($bypassBranch.OpCode.Name -like 'brtrue*' -and [object]::ReferenceEquals($bypassBranch.Operand, $restoreGate) -and
        $presetBranch.OpCode.Name -like 'brtrue*' -and
        $restoreGate.OpCode.Name -eq 'ldsfld' -and $restoreGate.Operand.Name -eq 'restored' -and
        $restoreGate.Offset -lt $restoreCalls[0].Offset -and $restoreCalls[0].Offset -lt $presetBranch.Operand.Offset) 'Bypass true and preset zero enter the shared restore branch before optimized apply'

    $restore = @(MethodOf $graphics 'RestoreVanilla')[0]
    $restoreBody = BodyOf $restore
    $restoreParts = Calls $restore 'ZompiercerPerf.GraphicsApply' 'TryRestore'
    $restoreTargets = @($restoreBody | Where-Object { $_.OpCode.Name -eq 'ldftn' } | ForEach-Object { $_.Operand.DeclaringType.FullName + '::' + $_.Operand.Name })
    Check ($restoreParts.Count -eq 9 -and
        $restoreTargets -contains 'ZompiercerPerf.ReflectionUpdates::Restore' -and
        $restoreTargets -contains 'ZompiercerPerf.AntiAliasing::Restore' -and
        $restoreTargets -contains 'ZompiercerPerf.SmallShadows::Restore' -and
        $restoreTargets -contains 'ZompiercerPerf.SkyQuality::Restore' -and
        $restoreTargets -contains 'ZompiercerPerf.GraphicsApply::RestoreWorld' -and
        $restoreTargets -contains 'ZompiercerPerf.WaterReflections::RestoreSizes' -and
        $restoreTargets -contains 'ZompiercerPerf.WorldLod::Restore' -and
        $restoreTargets -contains 'ZompiercerPerf.ZombieLod::ReleaseAll') 'full restore independently attempts graphics, world, water, world LOD, zombies, small shadows, sky, anti-aliasing and reflection probes'
    $qualityDelegate = @($restoreBody | Where-Object { $_.OpCode.Name -eq 'ldftn' -and $_.Operand.Name -like '<RestoreVanilla>*' })
    Check ($qualityDelegate.Count -eq 1) 'full restore has a dedicated quality delegate'
    $qualityLambda = $qualityDelegate[0].Operand.Resolve()
    $qualityLambdaBody = BodyOf $qualityLambda
    $qualityCall = Calls $qualityLambda 'ZompiercerPerf.GraphicsApply' 'ApplyQuality'
    $qualityCallIndex = [array]::IndexOf($qualityLambdaBody, $qualityCall[0])
    Check ($qualityCall.Count -eq 1 -and $qualityCallIndex -gt 0 -and
        $qualityLambdaBody[$qualityCallIndex - 1].OpCode.Name -eq 'ldc.i4.1' -and
        @($qualityLambdaBody | Where-Object { $_.OpCode.Name -eq 'ldfld' -and $_.Operand.Name -in @('Bypass','Preset') }).Count -eq 0) 'vanilla restore passes true to ApplyQuality without consulting active mode'
    $tryRestore = @(MethodOf $graphics 'TryRestore')[0]
    $tryRestoreBody = BodyOf $tryRestore
    $failedWrites = @($tryRestoreBody | Where-Object { $_.OpCode.Name -eq 'stsfld' -and $_.Operand.Name -eq 'failed' })
    $failedWriteIndex = if ($failedWrites.Count -eq 1) { [array]::IndexOf($tryRestoreBody, $failedWrites[0]) } else { -1 }
    Check (@($tryRestore.Body.ExceptionHandlers | Where-Object { $_.HandlerType -eq [Mono.Cecil.Cil.ExceptionHandlerType]::Catch -and $_.CatchType.FullName -eq 'System.Exception' }).Count -eq 1 -and
        $failedWriteIndex -gt 0 -and $tryRestoreBody[$failedWriteIndex - 1].OpCode.Name -eq 'ldc.i4.1') 'each restore part catches failure and leaves retry enabled'
    $qualityApply = @(MethodOf $graphics 'ApplyQuality')[0]
    $baseFields = @('BaseTexture','BaseShadows','BaseShadowRes','BaseCascades','BaseShadowDistance','BaseLod','BasePixelLights','BaseAniso','BaseSoftParticles','BaseSoftVeg','BaseProbes','BaseParticleBudget','BaseStreaming')
    $qualityFields = @((BodyOf $qualityApply) | Where-Object { $_.OpCode.Name -eq 'ldsfld' -and $_.Operand.DeclaringType.FullName -eq 'ZompiercerPerf.GraphicsApply' } | ForEach-Object { $_.Operand.Name })
    Check (@($baseFields | Where-Object { $_ -notin $qualityFields }).Count -eq 0 -and
        (Calls $qualityApply 'ZompiercerPerf.GraphicsApply' 'ApplyPost').Count -eq 1 -and
        (Calls $qualityApply 'ZompiercerPerf.GraphicsApply' 'ApplyFarClip').Count -eq 1) 'vanilla quality covers saved Unity values, postprocessing, and camera far clip'
    $menuChange = @(MethodOf $menu 'Change')[0]
    Check (@((BodyOf $menuChange) | Where-Object { $_.Operand -is [Mono.Cecil.FieldReference] -and $_.Operand.DeclaringType.FullName -eq 'ZompiercerPerf.PerfPlugin' -and $_.Operand.Name -eq 'Bypass' }).Count -eq 0 -and
        (Calls $menuChange 'ZompiercerPerf.PerfPlugin' 'SetOptimization').Count -eq 1) 'graphics choice changes leave Bypass untouched outside the Mode control'
    $configUpdate = @(MethodOf $plugin 'Update')[0]
    Check ((Calls $configUpdate 'ZompiercerPerf.GraphicsApply' 'TurnOn').Count -eq 1 -and
        (Calls $configUpdate 'ZompiercerPerf.GraphicsApply' 'ApplyNow').Count -eq 1) 'config changes can re-enable optimization or apply immediate disable'

    $unityCorePath = Join-Path $GameRoot 'Zompiercer_Data\Managed\UnityEngine.CoreModule.dll'
    Check (Test-Path $unityCorePath) 'Unity core assembly exists'
    $unity = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($unityCorePath)
    try {
        $quality = TypeOf $unity 'UnityEngine.QualitySettings'
        Check (@(MethodOf $quality 'SetQualityLevel').Count -gt 0) 'installed Unity exposes SetQualityLevel overloads'
    } finally { $unity.Dispose() }

    # 1.64: the F9 statistics, the FPS counter, the method profiler and perf-profile.txt were removed.
    Check ($null -eq (TypeOf $mod 'FrameProfile')) 'no method profiler (no profiling Harmony patches)'
    Check ($null -eq (TypeOf $mod 'FpsStats')) 'no FPS counter or statistics panel'
    $allCalls = @($mod.MainModule.Types | ForEach-Object { $_.Methods; $_.NestedTypes | ForEach-Object { $_.Methods } } |
        ForEach-Object { BodyOf $_ } | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] } | ForEach-Object { $_.Operand })
    Check (@($allCalls | Where-Object { $_.Name -eq 'get_f9Key' }).Count -eq 0) 'F9 is not bound'
    Check (@($allCalls | Where-Object { $_.DeclaringType.FullName -like 'UnityEngine.Profiling.*' }).Count -eq 0) 'no Unity profiler recorders'
    Check (@($allCalls | Where-Object { $_.DeclaringType.FullName -eq 'System.Threading.Thread' -and $_.Name -eq '.ctor' }).Count -eq 0) 'no background threads for logs'
    Check (@($mod.MainModule.Types | ForEach-Object { $_.Methods; $_.NestedTypes | ForEach-Object { $_.Methods } } |
        Where-Object { (Strings $_) -contains 'perf-profile.txt' }).Count -eq 0) 'perf-profile.txt is not written'

    $compat = TypeOf $mod 'LanCompatibility'
    $getters = @((TypeOf $lan 'LanPlugin').Methods | Where-Object Name -eq 'get_Connected')
    Check ($getters.Count -gt 0 -and $getters[0].ReturnType.FullName -eq 'System.Boolean') 'installed LAN plugin exposes bool Connected getter'
    Check ((Strings @(MethodOf $compat 'get_Active')[0]) -contains 'Connected') 'LAN compatibility resolves Connected by name'

    Check ((Calls @(MethodOf $graphics 'ApplyPost')[0] 'ZompiercerPerf.GraphicsApply' 'RestorePosts').Count -gt 0) 'vanilla postprocessing restores tracked profiles including detached ones'
    Check ((Calls @(MethodOf $graphics 'RestorePosts')[0] 'System.Collections.Generic.List`1<ZompiercerPerf.GraphicsApply/SavedPost>' 'Clear').Count -gt 0) 'restored profile ownership is cleared for later native recapture'
    Check ((Strings @(MethodOf $graphics 'TurnOff')[0]) -notcontains 'ApplyVideoSetting') 'bypass never invokes full native resolution/video apply'
    Check ((Calls @(MethodOf $graphics 'ApplyAnimators')[0] 'UnityEngine.Object' 'FindObjectsOfType').Count -eq 0) 'global animator throttling is removed'
    Check ((Calls @(MethodOf $graphics 'ReleaseScene')[0] 'ZompiercerPerf.WorldLod' 'Restore').Count -gt 0) 'scene unload restores prop ownership and clears graphics caches'
    Check ((Calls @(MethodOf (TypeOf $mod 'ZombieLod') 'Release')[0] 'System.Runtime.CompilerServices.ConditionalWeakTable`2<ZombieAIController,ZompiercerPerf.ZombieLod/ZState>' 'Remove').Count -gt 0) 'released zombies discard old native baselines before reuse'

    $unity = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($unityCorePath)
    $harmonyBindings = 0
    try {
        foreach ($patch in @(@('CameraMainCache','Camera','get_main'),@('GlobalManagerTick','GlobalManager','Update'),@('ZombieAiPatch','ZombieAIController','Update'),@('VegetationBillboard','EnviroVegetationInstance','LateUpdate'),@('WaterReflections','AQUAS_Reflection','OnWillRenderObject'),@('RememberManager','GUIManager','Start'))) {
            $patchType = TypeOf $mod $patch[0]
            $targetType = TypeOf $game $patch[1]
            if ($null -eq $targetType) { $targetType = TypeOf $unity $patch[1] }
            $target = @(MethodOf $targetType $patch[2])[0]
            Check ($null -ne $target -and (PatchTarget $patchType $patch[1] $patch[2])) ('Harmony target exists: '+$patch[1]+'.'+$patch[2])
            foreach ($method in $patchType.Methods | Where-Object { $_.Name -in @('Prefix','Postfix') }) {
                foreach ($parameter in $method.Parameters) {
                    if ($parameter.Name -eq '__instance') { Check ($parameter.ParameterType.FullName -eq $targetType.FullName) ('Harmony instance type: '+$patch[0]) }
                    elseif ($parameter.Name -eq '__result') { Check ($parameter.ParameterType.FullName.TrimEnd('&') -eq $target.ReturnType.FullName) ('Harmony result type: '+$patch[0]) }
                    else { throw ('Unchecked Harmony parameter '+$parameter.Name) }
                }
                $harmonyBindings++
            }
        }
    } finally { $unity.Dispose() }
    Check ($harmonyBindings -eq 7) 'all seven attributed Harmony prefix/postfix bindings checked'
    $refs = @($mod.MainModule.AssemblyReferences | ForEach-Object Name)
    Check (@($refs | Where-Object { $_ -match '(?i)^(Mirror|LiteNetLib|Unity\.Transport|Steamworks|ENet)' }).Count -eq 0) 'plugin adds no direct network assembly references'
    Write-Host "PASS: $passed offline metadata/IL checks. Native Harmony patch application and gameplay still require an in-game run."
} finally {
    $lan.Dispose(); $mod.Dispose(); $game.Dispose()
}
