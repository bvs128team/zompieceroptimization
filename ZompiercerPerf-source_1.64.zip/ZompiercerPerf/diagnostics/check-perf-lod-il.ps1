param([string]$ModPath = (Join-Path $PSScriptRoot '../bin/Release/net472/ZompiercerPerf.dll'))
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot '../../BepInEx/core/Mono.Cecil.dll')
$mod=[Mono.Cecil.AssemblyDefinition]::ReadAssembly($ModPath)
$passed=0
function Check([bool]$condition,[string]$name){if(!$condition){throw "FAIL: $name"};$script:passed++;Write-Output "PASS: $name"}
function Types($type){$type;foreach($nested in $type.NestedTypes){Types $nested}}
function Calls($methods,[string]$type,[string]$name){@($methods | ForEach-Object {if($_.HasBody){$_.Body.Instructions}} | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.DeclaringType.FullName -eq $type -and $_.Operand.Name -eq $name })}
try {
 $types=@($mod.MainModule.Types|ForEach-Object {Types $_})
 $world=@($types|Where-Object FullName -eq 'ZompiercerPerf.WorldLod')[0]
 $methods=@($world.Methods)
 Check ((Calls $methods 'UnityEngine.Renderer' 'set_enabled').Count -eq 0) 'LOD never overwrites gameplay renderer.enabled'
 Check ((Calls $methods 'UnityEngine.Renderer' 'set_forceRenderingOff').Count -gt 0) 'LOD uses its own rendering suppression'
 Check ((Calls $methods 'UnityEngine.GameObject' 'SetActive').Count -eq 0) 'LOD never disables gameplay objects'
 Check ((Calls $methods 'UnityEngine.LODGroup' 'set_crossFadeAnimationDuration').Count -eq 0) 'LOD never changes global native transition duration'
 Check ((Calls $methods 'UnityEngine.LODGroup' 'SetLODs').Count -eq 0) 'authored native LOD geometry and thresholds are preserved'
 Check ((Calls $methods 'UnityEngine.LODGroup' 'ForceLOD').Count -eq 0) 'LOD never leaves a forced native level'
 Check ((Calls $methods 'UnityEngine.Object' 'FindObjectsOfType').Count -eq 0) 'LOD discovery uses incremental hierarchy traversal'
 Check ((Calls @($methods|Where-Object Name -eq 'Restore') 'ZompiercerPerf.ObjectMeshLod' 'Clear').Count -eq 1) 'disable clears owned reduced meshes'
 Check ((Calls @($methods|Where-Object Name -eq 'RefreshGroups') 'ZompiercerPerf.LodTransition' 'StepWeights').Count -eq 1) 'native groups use tested smooth weights including cull state'
 Check ((Calls @($methods|Where-Object Name -eq 'Supported') 'UnityEngine.Experimental.Rendering.GraphicsFormatUtility' 'HasAlphaChannel').Count -eq 1) 'packed albedo alpha is excluded from fade rendering'
 $helper=@($types|Where-Object FullName -eq 'ZompiercerPerf.ObjectMeshLod')[0]
 Check ((Calls @($helper.Methods|Where-Object Name -eq 'GetReduced') 'System.Threading.Tasks.Task' 'Run').Count -eq 1) 'mesh reduction is scheduled on background Task'
 $workers=@($types|Where-Object FullName -like 'ZompiercerPerf.ObjectMeshLod/*'|ForEach-Object {$_.Methods}|Where-Object { (Calls @($_) 'ZompiercerPerf.MeshLodPolicy' 'Reduce').Count -gt 0 })
 Check ($workers.Count -eq 1) 'single pure reduction worker delegate exists'
 $unityCalls=@($workers|ForEach-Object {$_.Body.Instructions}|Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.DeclaringType.FullName -like 'UnityEngine.*' })
 Check ($unityCalls.Count -eq 0) 'background worker never calls Unity'
 Check ((Calls @($helper.Methods|Where-Object Name -eq 'Clear') 'System.Threading.Tasks.Task' 'Wait').Count -eq 0) 'disable never waits for background geometry'
 $pure=@($types|Where-Object {$_.FullName -like 'ZompiercerPerf.MeshLodPolicy*' -or $_.FullName -eq 'ZompiercerPerf.LodTransition'}|ForEach-Object {$_.Methods})
 Check (@($pure|ForEach-Object {if($_.HasBody){$_.Body.Instructions}}|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.DeclaringType.FullName -like 'UnityEngine.*'}).Count -eq 0) 'tested mesh and transition policies are Unity-free'
 $newTypes=@($types|Where-Object {$_.FullName -match 'ZompiercerPerf\.(WorldLod|ObjectMeshLod|MeshLodPolicy|LodTransition)'})
 $newCalls=@($newTypes|ForEach-Object {$_.Methods}|ForEach-Object {if($_.HasBody){$_.Body.Instructions}}|Where-Object {$_.Operand -is [Mono.Cecil.MethodReference]}|ForEach-Object {$_.Operand})
 Check (@($newCalls|Where-Object {$_.DeclaringType.FullName -match '^(System\.Net\.|System\.IO\.|System\.Diagnostics\.Process|Microsoft\.Win32\.)'}).Count -eq 0) 'new LOD code has no network, filesystem, process or registry calls'
 Check (@($newTypes|ForEach-Object {$_.Methods}|Where-Object IsPInvokeImpl).Count -eq 0) 'new LOD code adds no native imports'
 Check (@($newCalls|Where-Object {$_.Name -like 'set_*' -and $_.DeclaringType.FullName -match 'Collider|Rigidbody|NavMeshAgent'}).Count -eq 0) 'LOD never changes physics or navigation state'
 Write-Output "PASS: $passed LOD/worker/security IL contracts; runtime visuals remain untested."
} finally {$mod.Dispose()}
