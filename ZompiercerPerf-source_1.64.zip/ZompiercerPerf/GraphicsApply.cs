using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.PostProcessing;
using Zompiercer.GUI;
using UnityEngine.Rendering;

namespace ZompiercerPerf
{
    static class GraphicsTables
    {
        public static float ShadowDistance(int index)
        {
            if (index <= 0 && GraphicsApply.HaveBaseline)
                return GraphicsApply.BaseShadowDistance;
            float[] values = { 70f, 25f, 40f, 70f, 110f, 180f };
            if (index < 0 || index >= values.Length)
                index = 3;
            return values[index];
        }

        public static float LodBias(int index)
        {
            if (PerfPlugin.Tune.Preset == 0 && GraphicsApply.HaveBaseline)
                return GraphicsApply.BaseLod;
            float[] values = { 0.45f, 0.7f, 1f, 1.4f, 2f };
            if (index < 0 || index >= values.Length)
                index = 1;
            return values[index];
        }

        public static float FarClip(int index)
        {
            if (index <= 0)
                return 0f;
            float[] values = { 0f, 500f, 900f, 1400f, 2200f };
            if (index >= values.Length)
                index = 0;
            return values[index];
        }

        public static int Cascades(int index)
        {
            if (index <= 0)
                return 1;
            if (index == 1)
                return 2;
            return 4;
        }

        public static int PixelLights(int index)
        {
            if (index <= 0)
                return 0;
            if (index == 1)
                return 1;
            if (index == 2)
                return 2;
            return 4;
        }

        public static int ParticleBudget(int index)
        {
            int[] values = { 4, 16, 64, 256 };
            if (index < 0 || index >= values.Length)
                index = 1;
            return values[index];
        }

        public static float ParticleCullDistance(int index)
        {
            if (index <= 0)
                return 0f;
            if (index == 1)
                return 25f;
            if (index == 2)
                return 45f;
            return 80f;
        }

        public static float ZombieShadowDistance(int index)
        {
            if (index <= 0)
                return 0f;
            if (index == 1)
                return 25f;
            if (index == 2)
                return 45f;
            if (index == 3)
                return 80f;
            return 9999f;
        }

        public static float SmallShadowDistance(int index)
        {
            if (index <= 0)
                return 0f;
            if (index == 1)
                return 20f;
            if (index == 2)
                return 35f;
            return 50f;
        }

        public static float GrassDistance(int index)
        {
            float[] values = { 1f, .8f, .65f, .5f, .35f };
            return values[Mathf.Clamp(index, 0, values.Length - 1)];
        }

        public static float GrassDensity(int index)
        {
            float[] values = { 1f, .8f, .6f, .4f };
            return values[Mathf.Clamp(index, 0, values.Length - 1)];
        }

        public static float HeadDistance(int index)
        {
            if (index <= 0)
                return 0f;
            if (index == 1)
                return 12f;
            if (index == 2)
                return 22f;
            return 40f;
        }

        public static int Nearest(float value, float a, float b, float c, float d, float e, float f)
        {
            float[] values = { a, b, c, d, e, f };
            int best = 0;
            float error = Mathf.Abs(value - values[0]);
            for (int i = 1; i < values.Length; i++)
            {
                float next = Mathf.Abs(value - values[i]);
                if (next < error)
                {
                    error = next;
                    best = i;
                }
            }
            return best;
        }
    }

    static class GraphicsPresets
    {
        public static void Write(int preset)
        {
            if (preset == 4)
            {
                PerfPlugin.Preset.Value = 4;
                PerfPlugin.Tune.Pull();
                return;
            }
            // Since 1.4.0 three profiles: maximum (1), best balance (5) and minimum (3); 4 is "custom".
            // The game's own look is the mode switch ("Как без мода", F6), so 0 and the old balance (2)
            // are read as the best balance.
            if (preset == 1)
            {
                Extras(0, 0, 0, 0, 0, 0);
                Scale(0, 1, false);
                Fill(1, true, true, true, 0, 5, 2, 2, 2, 0, 2, 3, 2, true, true, true, true, true, false, 2, 0, 3, false, 0, 512, 0, 0);
            }
            else if (preset == 3)
            {
                Extras(1, 3, 2, 4, 2, 2);
                Scale(2, 1, false);
                Fill(3, true, true, true, 1, 1, 1, 0, 0, 1, 0, 0, 0, false, false, false, false, false, true, 1, 1, 0, true, 2, 128, 1, 1);
            }
            else
            {
                // The author's own tuned setup of 2026-10-22.
                Extras(2, 2, 0, 2, 3, 1);
                Scale(7, 2, true);
                PerfPlugin.Upscaler.Value = 0;
                PerfPlugin.MipBias.Value = true;
                PerfPlugin.TargetFps.Value = 5;
                Fill(5, false, false, false, 1, 4, 2, 1, 2, 0, 4, 3, 2, true, false, true, true, true, false, 3, 0, 3, false, 0, 512, 0, 0);
            }
        }

        static void Scale(int renderScale, int sharpness, bool sharpen)
        {
            PerfPlugin.RenderScaleIndex.Value = renderScale;
            PerfPlugin.Sharpness.Value = sharpness;
            PerfPlugin.Sharpen.Value = sharpen;
        }

        static void Extras(int smallShadows, int clouds, int volumeLight, int grassDistance, int grassDensity, int waterUpdate)
        {
            PerfPlugin.SmallShadowsMode.Value = smallShadows;
            PerfPlugin.CloudsMode.Value = clouds;
            PerfPlugin.VolumeLightMode.Value = volumeLight;
            PerfPlugin.GrassDistanceMode.Value = grassDistance;
            PerfPlugin.GrassDensityMode.Value = grassDensity;
            PerfPlugin.WaterUpdateMode.Value = waterUpdate;
        }

        static void Fill(int preset, bool zombies, bool culling, bool avoid, int tex, int shadowMeters, int shadowMode, int shadowRes, int cascades, int far, int lod, int lights, int aniso, bool softParticles, bool softVeg, bool probes, bool heavy, bool bloom, bool sunOnly, int terrain, int particles, int budget, bool streaming, int vegetation, int water, int zombieShadows, int heads)
        {
            PerfPlugin.Preset.Value = preset;
            PerfPlugin.DistanceLod.Value = zombies;
            PerfPlugin.SliceAnimation.Value = zombies;
            PerfPlugin.AnimatorCulling.Value = culling;
            PerfPlugin.NavAvoidance.Value = avoid;
            PerfPlugin.TextureLimit.Value = tex;
            PerfPlugin.ShadowMeters.Value = shadowMeters;
            PerfPlugin.ShadowMode.Value = shadowMode;
            PerfPlugin.ShadowRes.Value = shadowRes;
            PerfPlugin.Cascades.Value = cascades;
            PerfPlugin.FarClip.Value = far;
            PerfPlugin.Lod.Value = lod;
            PerfPlugin.PixelLights.Value = lights;
            PerfPlugin.Aniso.Value = aniso;
            PerfPlugin.SoftParticles.Value = softParticles;
            PerfPlugin.SoftVegetation.Value = softVeg;
            PerfPlugin.RealtimeProbes.Value = probes;
            PerfPlugin.HeavyEffects.Value = heavy;
            PerfPlugin.BloomOn.Value = bloom;
            PerfPlugin.SunOnlyShadows.Value = sunOnly;
            PerfPlugin.TerrainDetail.Value = terrain;
            PerfPlugin.ParticleCull.Value = particles;
            PerfPlugin.ParticleBudget.Value = budget;
            PerfPlugin.StreamingMips.Value = streaming;
            PerfPlugin.VegetationMode.Value = vegetation;
            PerfPlugin.WaterReflectionSize.Value = water;
            PerfPlugin.ZombieShadowMode.Value = zombieShadows;
            PerfPlugin.HeadMode.Value = heads;
            int characters = 0;
            int props = 0;
            if (preset == 2)
            {
                characters = 1;
                props = 1;
            }
            else if (preset == 3)
            {
                characters = 2;
                props = 2;
            }
            PerfPlugin.CharacterLod.Value = characters;
            PerfPlugin.PropLod.Value = props;
            PerfPlugin.Tune.Pull();
        }
    }

    static class GraphicsApply
    {
        public static bool HaveBaseline;
        public static bool Applying;
        public static float BaseShadowDistance = 70f;
        public static float BaseLod = 1f;
        public static float BaseFarClip = 1000f;
        public static int BaseTexture;
        public static ShadowQuality BaseShadows = ShadowQuality.All;
        public static ShadowResolution BaseShadowRes = ShadowResolution.High;
        public static int BaseCascades = 2;
        public static int BasePixelLights = 2;
        public static AnisotropicFiltering BaseAniso = AnisotropicFiltering.Enable;
        public static bool BaseSoftParticles = true;
        public static bool BaseSoftVeg = true;
        public static bool BaseProbes;
        public static bool BaseAo = true;
        public static bool BaseSsr = true;
        public static bool BaseMotion = true;
        public static bool BaseDof = true;
        public static bool BaseBloom = true;
        public static int BaseParticleBudget = 64;
        public static bool BaseStreaming;

        static float sawGameAt = -1f;
        static float nextApply;
        static bool pendingQuality;
        static bool restored;
        static bool failed;
        static int worldTick;
        static readonly Dictionary<Camera, float> CameraFar = new Dictionary<Camera, float>();
        static readonly List<Camera> DeadCameras = new List<Camera>();
        static readonly List<SavedLight> Lights = new List<SavedLight>();
        static readonly List<SavedTerrain> Terrains = new List<SavedTerrain>();
        static readonly List<SavedParticle> Particles = new List<SavedParticle>();
        static readonly List<Animator> CulledAnimators = new List<Animator>();
        static int lightScan = -1000;
        static int particleScan = -1000;
        static PostProcessingBehaviour[] postFound;
        static float nextPostScan;

        // Applied remembers what this mod last wrote. A different live value means the game
        // changed it since, so that becomes the value to restore instead of a stale capture.
        sealed class SavedLight
        {
            public Light Light;
            public LightShadows Shadows;
            public LightShadows Applied;
        }

        sealed class SavedTerrain
        {
            public Terrain Terrain;
            public float Detail;
            public float Trees;
            public float Billboard;
            public float Basemap;
            public float Error;
            public float Density;
            public float AppliedDetail, AppliedTrees, AppliedBillboard, AppliedBasemap, AppliedError, AppliedDensity;
        }

        sealed class SavedParticle
        {
            public ParticleSystem System;
            public bool Emission;
            public bool Applied;
        }

        sealed class SavedPost
        {
            public PostProcessingProfile Profile;
            public bool Ao, Ssr, Motion, Dof, Bloom;
        }

        static readonly List<SavedPost> Posts = new List<SavedPost>();

        public static void Patch(Harmony harmony)
        {
            var postfix = new HarmonyMethod(typeof(GraphicsApply), "OnGameQualityChanged");
            var methods = typeof(QualitySettings).GetMethods(BindingFlags.Public | BindingFlags.Static);
            for (int i = 0; i < methods.Length; i++)
            {
                if (methods[i].Name == "SetQualityLevel")
                    harmony.Patch(methods[i], null, postfix);
            }
        }

        public static void Pump()
        {
            if (pendingQuality)
            {
                pendingQuality = false;
                if (!HaveBaseline)
                {
                    Capture();
                    HaveBaseline = true;
                    int preset = PerfPlugin.Preset.Value;
                    if (preset != 0 && preset != 4 && !PerfPlugin.Bypass.Value)
                        GraphicsPresets.Write(preset);
                }
                PerfPlugin.Tune.Pull();
                ApplyNow();
                nextApply = Time.realtimeSinceStartup + 1f;
                return;
            }
            if (!HaveBaseline)
            {
                if (sawGameAt < 0f)
                    sawGameAt = Time.realtimeSinceStartup;
                if (Time.realtimeSinceStartup - sawGameAt < 8f)
                    return;
                pendingQuality = true;
                return;
            }
            if (Time.realtimeSinceStartup < nextApply)
                return;
            nextApply = Time.realtimeSinceStartup + 1f;
            PerfPlugin.Tune.Pull();
            Apply();
        }

        public static void ApplyNow()
        {
            worldTick = 2;
            nextPostScan = 0f;
            Apply();
        }

        public static void OnGameQualityChanged()
        {
            if (Applying)
                return;
            RestorePosts();
            RestoreWorld();
            if (HaveBaseline)
                Capture();
            if (!PerfPlugin.Tune.Bypass)
                pendingQuality = true;
        }

        public static void TurnOff()
        {
            // Restore only our own changes. Calling the game's full video apply
            // here would also reset resolution, fullscreen, AA and frame limits.
            failed = false;
            RestoreVanilla();
            restored = !failed;
        }
        public static void TurnOn()
        {
            failed = false;
            restored = false;
            // Let Pump observe the game's finished video setup before taking
            // the first baseline. A menu toggle can arrive before that setup.
            ApplyNow();
        }

        public static void RestoreVanilla()
        {
            Applying = true;
            failed = false;
            try
            {
                if (HaveBaseline)
                    TryRestore("графика", delegate { ApplyQuality(true); });
                TryRestore("объекты мира", RestoreWorld);
                TryRestore("отражения воды", WaterReflections.RestoreSizes);
                TryRestore("LOD мира", WorldLod.Restore);
                TryRestore("зомби", ZombieLod.ReleaseAll);
                TryRestore("тени мелочи", SmallShadows.Restore);
                TryRestore("небо Enviro", SkyQuality.Restore);
                TryRestore("сглаживание", AntiAliasing.Restore);
                TryRestore("отражения окружения", ReflectionUpdates.Restore);
            }
            finally { Applying = false; }
        }

        static void TryRestore(string part, Action restore)
        {
            try { restore(); }
            catch (Exception ex)
            {
                failed = true;
                if (PerfPlugin.Instance != null)
                    PerfPlugin.Instance.LogError("Не удалось вернуть " + part + ": " + ex);
            }
        }

        public static void Apply()
        {
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0)
            {
                if (!restored)
                {
                    RestoreVanilla();
                    restored = !failed;
                }
                return;
            }
            restored = false;
            if (!HaveBaseline || failed)
                return;
            Applying = true;
            try
            {
                ApplyQuality(false);
                worldTick++;
                if (worldTick % 3 == 0)
                    ApplyWorld();
            }
            catch (Exception ex)
            {
                failed = true;
                if (PerfPlugin.Instance != null)
                    PerfPlugin.Instance.LogError("Графика не применилась: " + ex);
            }
            Applying = false;
        }

        static void Capture()
        {
            BaseShadowDistance = QualitySettings.shadowDistance;
            BaseLod = QualitySettings.lodBias;
            BaseTexture = QualitySettings.masterTextureLimit;
            BaseShadows = QualitySettings.shadows;
            BaseShadowRes = QualitySettings.shadowResolution;
            BaseCascades = QualitySettings.shadowCascades;
            BasePixelLights = QualitySettings.pixelLightCount;
            BaseAniso = QualitySettings.anisotropicFiltering;
            BaseSoftParticles = QualitySettings.softParticles;
            BaseSoftVeg = QualitySettings.softVegetation;
            BaseProbes = QualitySettings.realtimeReflectionProbes;
            BaseParticleBudget = QualitySettings.particleRaycastBudget;
            BaseStreaming = QualitySettings.streamingMipmapsActive;
            var camera = Camera.main;
            if (camera != null && camera.farClipPlane > 1f)
                BaseFarClip = camera.farClipPlane;
            RememberCameras();
            CapturePost();
        }

        static void CapturePost()
        {
            var found = UnityEngine.Object.FindObjectsOfType<PostProcessingBehaviour>();
            for (int i = 0; i < found.Length; i++)
            {
                var profile = found[i].profile;
                if (profile == null)
                    continue;
                var saved = RememberPost(profile);
                if (i == 0)
                {
                    BaseAo = saved.Ao;
                    BaseSsr = saved.Ssr;
                    BaseMotion = saved.Motion;
                    BaseDof = saved.Dof;
                    BaseBloom = saved.Bloom;
                }
            }
        }

        static SavedPost RememberPost(PostProcessingProfile profile)
        {
            for (int i = 0; i < Posts.Count; i++)
                if (Posts[i].Profile == profile)
                    return Posts[i];
            var saved = new SavedPost {
                Profile = profile,
                Ao = profile.ambientOcclusion.enabled,
                Ssr = profile.screenSpaceReflection.enabled,
                Motion = profile.motionBlur.enabled,
                Dof = profile.depthOfField.enabled,
                Bloom = profile.bloom.enabled
            };
            Posts.Add(saved);
            return saved;
        }

        static void AdoptCustom()
        {
            PerfPlugin.Preset.Value = 4;
            PerfPlugin.TextureLimit.Value = Mathf.Clamp(QualitySettings.masterTextureLimit, 0, 3);
            PerfPlugin.ShadowMeters.Value = ShadowIndex();
            PerfPlugin.ShadowMode.Value = ShadowModeIndex();
            PerfPlugin.ShadowRes.Value = ShadowResIndex();
            PerfPlugin.Cascades.Value = CascadeIndex();
            PerfPlugin.PixelLights.Value = PixelIndex();
            PerfPlugin.Aniso.Value = AnisoIndex();
            PerfPlugin.SoftParticles.Value = QualitySettings.softParticles;
            PerfPlugin.SoftVegetation.Value = QualitySettings.softVegetation;
            PerfPlugin.RealtimeProbes.Value = QualitySettings.realtimeReflectionProbes;
            PerfPlugin.ParticleBudget.Value = BudgetIndex();
            PerfPlugin.Lod.Value = LodIndex();
            PerfPlugin.Tune.Pull();
        }

        public static int TextureIndex()
        {
            return Mathf.Clamp(HaveBaseline ? BaseTexture : QualitySettings.masterTextureLimit, 0, 3);
        }

        public static int ShadowIndex()
        {
            float value = HaveBaseline ? BaseShadowDistance : QualitySettings.shadowDistance;
            return GraphicsTables.Nearest(value, BaseShadowDistance, 25f, 40f, 70f, 110f, 180f);
        }

        public static int ShadowModeIndex()
        {
            var mode = HaveBaseline ? BaseShadows : QualitySettings.shadows;
            if (mode == ShadowQuality.Disable)
                return 0;
            if (mode == ShadowQuality.HardOnly)
                return 1;
            return 2;
        }

        public static int ShadowResIndex()
        {
            var mode = HaveBaseline ? BaseShadowRes : QualitySettings.shadowResolution;
            if (mode == ShadowResolution.Low)
                return 0;
            if (mode == ShadowResolution.Medium)
                return 1;
            if (mode == ShadowResolution.High)
                return 2;
            return 3;
        }

        public static int CascadeIndex()
        {
            int value = HaveBaseline ? BaseCascades : QualitySettings.shadowCascades;
            if (value <= 1)
                return 0;
            if (value == 2)
                return 1;
            return 2;
        }

        public static int FarIndex()
        {
            return 0;
        }

        public static int LodIndex()
        {
            float value = HaveBaseline ? BaseLod : QualitySettings.lodBias;
            if (value < 0.55f)
                return 0;
            if (value < 0.85f)
                return 1;
            if (value < 1.2f)
                return 2;
            if (value < 1.6f)
                return 3;
            return 4;
        }

        public static int PixelIndex()
        {
            int value = HaveBaseline ? BasePixelLights : QualitySettings.pixelLightCount;
            if (value <= 0)
                return 0;
            if (value == 1)
                return 1;
            if (value == 2)
                return 2;
            return 3;
        }

        public static int AnisoIndex()
        {
            var mode = HaveBaseline ? BaseAniso : QualitySettings.anisotropicFiltering;
            if (mode == AnisotropicFiltering.Disable)
                return 0;
            if (mode == AnisotropicFiltering.ForceEnable)
                return 2;
            return 1;
        }

        public static int BudgetIndex()
        {
            int value = HaveBaseline ? BaseParticleBudget : QualitySettings.particleRaycastBudget;
            if (value <= 8)
                return 0;
            if (value <= 24)
                return 1;
            if (value <= 96)
                return 2;
            return 3;
        }

        static void ApplyQuality(bool vanilla)
        {
            var tune = PerfPlugin.Tune;
            SetInt(delegate { return QualitySettings.masterTextureLimit; }, delegate(int value) { QualitySettings.masterTextureLimit = value; }, vanilla ? BaseTexture : tune.TextureLimit);
            SetEnum(QualitySettings.shadows, vanilla ? BaseShadows : ShadowQualityOf(tune.ShadowMode), delegate(ShadowQuality value) { QualitySettings.shadows = value; });
            SetEnum(QualitySettings.shadowResolution, vanilla ? BaseShadowRes : ShadowResOf(tune.ShadowRes), delegate(ShadowResolution value) { QualitySettings.shadowResolution = value; });
            SetInt(delegate { return QualitySettings.shadowCascades; }, delegate(int value) { QualitySettings.shadowCascades = value; }, vanilla ? BaseCascades : GraphicsTables.Cascades(tune.Cascades));
            SetFloat(delegate { return QualitySettings.shadowDistance; }, delegate(float value) { QualitySettings.shadowDistance = value; }, vanilla ? BaseShadowDistance : GraphicsTables.ShadowDistance(tune.ShadowMeters), vanilla ? 0f : 0.05f);
            SetFloat(delegate { return QualitySettings.lodBias; }, delegate(float value) { QualitySettings.lodBias = value; }, vanilla ? BaseLod : GraphicsTables.LodBias(tune.Lod), vanilla ? 0f : 0.05f);
            SetInt(delegate { return QualitySettings.pixelLightCount; }, delegate(int value) { QualitySettings.pixelLightCount = value; }, vanilla ? BasePixelLights : GraphicsTables.PixelLights(tune.PixelLights));
            SetEnum(QualitySettings.anisotropicFiltering, vanilla ? BaseAniso : AnisoOf(tune.Aniso), delegate(AnisotropicFiltering value) { QualitySettings.anisotropicFiltering = value; });
            SetBool(delegate { return QualitySettings.softParticles; }, delegate(bool value) { QualitySettings.softParticles = value; }, vanilla ? BaseSoftParticles : tune.SoftParticles);
            SetBool(delegate { return QualitySettings.softVegetation; }, delegate(bool value) { QualitySettings.softVegetation = value; }, vanilla ? BaseSoftVeg : tune.SoftVegetation);
            SetBool(delegate { return QualitySettings.realtimeReflectionProbes; }, delegate(bool value) { QualitySettings.realtimeReflectionProbes = value; }, vanilla ? BaseProbes : tune.RealtimeProbes);
            SetInt(delegate { return QualitySettings.particleRaycastBudget; }, delegate(int value) { QualitySettings.particleRaycastBudget = value; }, vanilla ? BaseParticleBudget : GraphicsTables.ParticleBudget(tune.ParticleBudget));
            SetBool(delegate { return QualitySettings.streamingMipmapsActive; }, delegate(bool value) { QualitySettings.streamingMipmapsActive = value; }, vanilla ? BaseStreaming : tune.StreamingMips);
            ApplyPost(tune, vanilla);
            ApplyFarClip(tune, vanilla);
        }

        static void SetEnabled(UnityEngine.PostProcessing.PostProcessingModel model, bool value)
        {
            if (model != null && model.enabled != value)
                model.enabled = value;
        }

        static void SetFloat(Func<float> get, Action<float> set, float value, float tolerance)
        {
            if (Mathf.Abs(get() - value) > tolerance)
                set(value);
        }

        static void SetInt(Func<int> get, Action<int> set, int value)
        {
            if (get() != value)
                set(value);
        }

        static void SetBool(Func<bool> get, Action<bool> set, bool value)
        {
            if (get() != value)
                set(value);
        }

        static void SetEnum<T>(T current, T value, Action<T> set)
        {
            if (!current.Equals(value))
                set(value);
        }

        static ShadowQuality ShadowQualityOf(int index)
        {
            if (index <= 0)
                return ShadowQuality.Disable;
            if (index == 1)
                return ShadowQuality.HardOnly;
            return ShadowQuality.All;
        }

        static ShadowResolution ShadowResOf(int index)
        {
            if (index <= 0)
                return ShadowResolution.Low;
            if (index == 1)
                return ShadowResolution.Medium;
            if (index == 2)
                return ShadowResolution.High;
            return ShadowResolution.VeryHigh;
        }

        static AnisotropicFiltering AnisoOf(int index)
        {
            if (index <= 0)
                return AnisotropicFiltering.Disable;
            if (index == 2)
                return AnisotropicFiltering.ForceEnable;
            return AnisotropicFiltering.Enable;
        }

        static void ApplyPost(Tune tune, bool vanilla)
        {
            if (vanilla) { RestorePosts(); return; }
            // A full object search every second showed up as a periodic hitch; cameras rarely change.
            if (postFound == null || Time.realtimeSinceStartup >= nextPostScan)
            {
                postFound = UnityEngine.Object.FindObjectsOfType<PostProcessingBehaviour>();
                nextPostScan = Time.realtimeSinceStartup + 5f;
            }
            var found = postFound;
            var active = new HashSet<PostProcessingProfile>();
            foreach (var behaviour in found) if (behaviour != null && behaviour.profile != null) active.Add(behaviour.profile);
            for (int i = Posts.Count - 1; i >= 0; i--)
                if (Posts[i].Profile == null || !active.Contains(Posts[i].Profile))
                { RestorePost(Posts[i]); Posts.RemoveAt(i); }
            for (int i = 0; i < found.Length; i++)
            {
                if (found[i] == null)
                    continue;
                var profile = found[i].profile;
                if (profile == null)
                    continue;
                var saved = RememberPost(profile);
                SetEnabled(profile.ambientOcclusion, saved.Ao && (vanilla || tune.HeavyEffects));
                SetEnabled(profile.screenSpaceReflection, saved.Ssr && (vanilla || tune.HeavyEffects));
                SetEnabled(profile.motionBlur, saved.Motion && (vanilla || tune.HeavyEffects));
                SetEnabled(profile.depthOfField, saved.Dof && (vanilla || tune.HeavyEffects));
                SetEnabled(profile.bloom, saved.Bloom && (vanilla || tune.BloomOn));
            }
        }

        static void RestorePost(SavedPost saved)
        {
            if (saved.Profile == null) return;
            SetEnabled(saved.Profile.ambientOcclusion, saved.Ao);
            SetEnabled(saved.Profile.screenSpaceReflection, saved.Ssr);
            SetEnabled(saved.Profile.motionBlur, saved.Motion);
            SetEnabled(saved.Profile.depthOfField, saved.Dof);
            SetEnabled(saved.Profile.bloom, saved.Bloom);
        }

        static void RestorePosts()
        {
            foreach (var saved in Posts) RestorePost(saved);
            Posts.Clear();
            postFound = null;
        }

        static void RememberCameras()
        {
            DeadCameras.Clear();
            foreach (var pair in CameraFar)
                if (pair.Key == null)
                    DeadCameras.Add(pair.Key);
            for (int i = 0; i < DeadCameras.Count; i++)
                CameraFar.Remove(DeadCameras[i]);
            var cameras = Camera.allCameras;
            for (int i = 0; i < cameras.Length; i++)
            {
                var camera = cameras[i];
                if (camera == null || !camera.CompareTag("MainCamera") || camera.farClipPlane < 250f)
                    continue;
                if (!CameraFar.ContainsKey(camera))
                    CameraFar[camera] = camera.farClipPlane;
            }
        }

        static void ApplyFarClip(Tune tune, bool vanilla)
        {
            RememberCameras();
            float chosen = vanilla ? 0f : GraphicsTables.FarClip(tune.FarClip);
            foreach (var pair in CameraFar)
            {
                var camera = pair.Key;
                if (camera == null)
                    continue;
                float next = chosen <= 0f ? pair.Value : Mathf.Min(pair.Value, chosen);
                if (Mathf.Abs(camera.farClipPlane - next) > (vanilla ? 0f : 0.5f))
                    camera.farClipPlane = next;
            }
        }

        static void ApplyWorld()
        {
            Lights.RemoveAll(saved => saved.Light == null);
            Terrains.RemoveAll(saved => saved.Terrain == null);
            Particles.RemoveAll(saved => saved.System == null);
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0)
            {
                RestoreWorld();
                ZombieLod.ReleaseAll();
                return;
            }
            ApplyLights();
            ApplyTerrains();
            ApplyParticles();
            ApplyAnimators();
        }

        static void RestoreWorld()
        {
            for (int i = 0; i < Lights.Count; i++)
                if (Lights[i].Light != null && Lights[i].Light.shadows == Lights[i].Applied)
                    Lights[i].Light.shadows = Lights[i].Shadows;
            Lights.Clear();
            for (int i = 0; i < Terrains.Count; i++)
            {
                var saved = Terrains[i];
                if (saved.Terrain == null)
                    continue;
                AdoptTerrain(saved);
                saved.Terrain.detailObjectDistance = saved.Detail;
                saved.Terrain.detailObjectDensity = saved.Density;
                saved.Terrain.treeDistance = saved.Trees;
                saved.Terrain.treeBillboardDistance = saved.Billboard;
                saved.Terrain.basemapDistance = saved.Basemap;
                saved.Terrain.heightmapPixelError = saved.Error;
            }
            Terrains.Clear();
            for (int i = 0; i < Particles.Count; i++)
            {
                var saved = Particles[i];
                if (saved.System == null)
                    continue;
                var emission = saved.System.emission;
                if (emission.enabled == saved.Applied)
                    emission.enabled = saved.Emission;
            }
            Particles.Clear();
            RestoreAnimators();
            lightScan = particleScan = -1000;
        }

        public static void ReleaseScene()
        {
            RestoreWorld();
            RestorePosts();
            foreach (var saved in CameraFar)
                if (saved.Key != null) saved.Key.farClipPlane = saved.Value;
            CameraFar.Clear();
            WorldLod.Restore();
            ZombieLod.ReleaseAll();
            WaterReflections.RestoreSizes();
            SmallShadows.Restore();
            SkyQuality.Restore();
            AntiAliasing.Restore();
            ReflectionUpdates.Restore();
        }

        static void RestoreAnimators()
        {
            for (int i = 0; i < CulledAnimators.Count; i++)
            {
                var animator = CulledAnimators[i];
                if (animator != null && animator.cullingMode == AnimatorCullingMode.CullUpdateTransforms)
                    animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            }
            CulledAnimators.Clear();
        }

        static void ApplyLights()
        {
            if (Time.frameCount - lightScan > 900)
            {
                lightScan = Time.frameCount;
                var found = UnityEngine.Object.FindObjectsOfType<Light>();
                for (int i = 0; i < found.Length; i++)
                {
                    if (found[i] == null || found[i].type == LightType.Directional || KnownLight(found[i]))
                        continue;
                    var saved = new SavedLight();
                    saved.Light = found[i];
                    saved.Shadows = found[i].shadows;
                    saved.Applied = saved.Shadows;
                    Lights.Add(saved);
                }
            }
            bool sunOnly = !PerfPlugin.Tune.Bypass && PerfPlugin.Tune.SunOnlyShadows && PerfPlugin.Tune.Preset != 0;
            for (int i = 0; i < Lights.Count; i++)
            {
                var saved = Lights[i];
                if (saved.Light == null)
                    continue;
                if (saved.Light.shadows != saved.Applied)
                    saved.Shadows = saved.Light.shadows;
                saved.Applied = sunOnly ? LightShadows.None : saved.Shadows;
                if (saved.Light.shadows != saved.Applied)
                    saved.Light.shadows = saved.Applied;
            }
        }

        static bool KnownLight(Light light)
        {
            for (int i = 0; i < Lights.Count; i++)
            {
                if (Lights[i].Light == light)
                    return true;
            }
            return false;
        }

        static void ApplyTerrains()
        {
            var active = Terrain.activeTerrains;
            for (int i = 0; i < active.Length; i++)
            {
                if (active[i] == null || KnownTerrain(active[i]))
                    continue;
                var saved = new SavedTerrain();
                saved.Terrain = active[i];
                saved.Detail = active[i].detailObjectDistance;
                saved.Trees = active[i].treeDistance;
                saved.Billboard = active[i].treeBillboardDistance;
                saved.Basemap = active[i].basemapDistance;
                saved.Error = active[i].heightmapPixelError;
                saved.Density = active[i].detailObjectDensity;
                saved.AppliedDensity = saved.Density;
                saved.AppliedDetail = saved.Detail;
                saved.AppliedTrees = saved.Trees;
                saved.AppliedBillboard = saved.Billboard;
                saved.AppliedBasemap = saved.Basemap;
                saved.AppliedError = saved.Error;
                Terrains.Add(saved);
            }
            float detailMul = 1f;
            float treeMul = 1f;
            float errorAdd = 0f;
            float grassMul = 1f;
            float densityMul = 1f;
            int mode = PerfPlugin.Tune.TerrainDetail;
            if (!PerfPlugin.Tune.Bypass && PerfPlugin.Tune.Preset != 0)
            {
                // Grass has its own distance and density since 1.3.0; "Terrain" keeps trees, basemap and mesh error.
                grassMul = GraphicsTables.GrassDistance(PerfPlugin.Tune.GrassDistance);
                densityMul = GraphicsTables.GrassDensity(PerfPlugin.Tune.GrassDensity);
                if (mode == 0)
                {
                    detailMul = 0.35f;
                    treeMul = 0.45f;
                    errorAdd = 4f;
                }
                else if (mode == 1)
                {
                    detailMul = 0.65f;
                    treeMul = 0.75f;
                    errorAdd = 2f;
                }
            }
            for (int i = 0; i < Terrains.Count; i++)
            {
                var saved = Terrains[i];
                if (saved.Terrain == null)
                    continue;
                AdoptTerrain(saved);
                var terrain = saved.Terrain;
                saved.AppliedDetail = saved.Detail * grassMul;
                saved.AppliedDensity = saved.Density * densityMul;
                saved.AppliedTrees = saved.Trees * treeMul;
                saved.AppliedBillboard = saved.Billboard * treeMul;
                saved.AppliedBasemap = saved.Basemap * Mathf.Max(0.5f, detailMul);
                saved.AppliedError = saved.Error + errorAdd;
                // Read back what Unity stored: a clamped value must not look like a change by the game.
                if (terrain.detailObjectDistance != saved.AppliedDetail) { terrain.detailObjectDistance = saved.AppliedDetail; saved.AppliedDetail = terrain.detailObjectDistance; }
                if (terrain.treeDistance != saved.AppliedTrees) { terrain.treeDistance = saved.AppliedTrees; saved.AppliedTrees = terrain.treeDistance; }
                if (terrain.treeBillboardDistance != saved.AppliedBillboard) { terrain.treeBillboardDistance = saved.AppliedBillboard; saved.AppliedBillboard = terrain.treeBillboardDistance; }
                if (terrain.basemapDistance != saved.AppliedBasemap) { terrain.basemapDistance = saved.AppliedBasemap; saved.AppliedBasemap = terrain.basemapDistance; }
                if (terrain.heightmapPixelError != saved.AppliedError) { terrain.heightmapPixelError = saved.AppliedError; saved.AppliedError = terrain.heightmapPixelError; }
                if (terrain.detailObjectDensity != saved.AppliedDensity) { terrain.detailObjectDensity = saved.AppliedDensity; saved.AppliedDensity = terrain.detailObjectDensity; }
            }
        }

        static void AdoptTerrain(SavedTerrain saved)
        {
            // CTS/Gaia may set their own distances after the capture; those become the originals.
            var terrain = saved.Terrain;
            if (terrain.detailObjectDistance != saved.AppliedDetail) saved.Detail = terrain.detailObjectDistance;
            if (terrain.treeDistance != saved.AppliedTrees) saved.Trees = terrain.treeDistance;
            if (terrain.treeBillboardDistance != saved.AppliedBillboard) saved.Billboard = terrain.treeBillboardDistance;
            if (terrain.basemapDistance != saved.AppliedBasemap) saved.Basemap = terrain.basemapDistance;
            if (terrain.heightmapPixelError != saved.AppliedError) saved.Error = terrain.heightmapPixelError;
            if (terrain.detailObjectDensity != saved.AppliedDensity) saved.Density = terrain.detailObjectDensity;
        }

        static bool KnownTerrain(Terrain terrain)
        {
            for (int i = 0; i < Terrains.Count; i++)
            {
                if (Terrains[i].Terrain == terrain)
                    return true;
            }
            return false;
        }

        static void ApplyParticles()
        {
            if (Time.frameCount - particleScan > 900)
            {
                particleScan = Time.frameCount;
                var found = UnityEngine.Object.FindObjectsOfType<ParticleSystem>();
                Transform player = PlayerTransform();
                Transform camera = MainCameraTransform();
                for (int i = 0; i < found.Length; i++)
                {
                    var system = found[i];
                    if (system != null && (LanCompatibility.Owns(system) || system.GetComponentInParent<ZombieAIController>() != null ||
                        system.GetComponentInParent<ZombieFighterController>() != null || system.GetComponentInParent<NPC>() != null ||
                        system.GetComponentInParent<Zompiercer.Train.TrainCar>() != null || system.GetComponentInParent<Fireplace>() != null ||
                        system.GetComponentInParent<InteractingObjects>() != null || system.GetComponentInParent<SceneEventTrigger>() != null))
                        continue;
                    if (system == null || !system.main.loop || KnownParticle(system))
                        continue;
                    if (player != null && system.transform.IsChildOf(player))
                        continue;
                    if (camera != null && system.transform.IsChildOf(camera))
                        continue;
                    var saved = new SavedParticle();
                    saved.System = system;
                    saved.Emission = system.emission.enabled;
                    saved.Applied = saved.Emission;
                    Particles.Add(saved);
                }
            }
            float distance = GraphicsTables.ParticleCullDistance(PerfPlugin.Tune.ParticleCull);
            if (PerfPlugin.Tune.Bypass || PerfPlugin.Tune.Preset == 0)
                distance = 0f;
            Transform playerNow = PlayerTransform();
            Vector3 origin = playerNow != null ? playerNow.position : Vector3.zero;
            for (int i = 0; i < Particles.Count; i++)
            {
                var saved = Particles[i];
                if (saved.System == null)
                    continue;
                var emission = saved.System.emission;
                if (emission.enabled != saved.Applied)
                    saved.Emission = emission.enabled; // the game switched this effect itself
                bool enabled = saved.Emission;
                if (distance > 0f && playerNow != null)
                {
                    float sqr = (saved.System.transform.position - origin).sqrMagnitude;
                    if (sqr > distance * distance)
                        enabled = false;
                }
                saved.Applied = enabled;
                if (emission.enabled != enabled)
                    emission.enabled = enabled;
            }
        }

        static bool KnownParticle(ParticleSystem system)
        {
            for (int i = 0; i < Particles.Count; i++)
            {
                if (Particles[i].System == system)
                    return true;
            }
            return false;
        }

        static void ApplyAnimators()
        {
            // Only ZombieLod owns this optimization, with an explicit distance
            // and LAN guard. Other animators may drive gameplay off screen.
            RestoreAnimators();
        }
        static Transform PlayerTransform()
        {
            var manager = GlobalManager.global;
            if (manager == null || manager.controlledChar == null)
                return null;
            var transform = manager.controlledChar.GetTransform;
            return transform != null ? transform : manager.controlledChar.transform;
        }

        static Transform MainCameraTransform()
        {
            var manager = GlobalManager.global;
            if (manager == null || manager.MainCamera == null)
                return null;
            return manager.MainCamera.transform;
        }
    }

    static class ResolutionLock
    {
        public static void Maintain()
        {
            // The game's video menu owns resolution and fullscreen state.
        }
    }
}
