using System;
using System.Reflection;
using BepInEx.Bootstrap;
using UnityEngine;

namespace ZompiercerPerf
{
    // Optional read-only bridge. Unknown LAN versions retain their own zombie policy.
    internal static class LanCompatibility
    {
        private static int frame = -1;
        private static bool active;
        private static object instance;
        private static Func<bool> connected;
        private static Type[] markers = new Type[0];
        public static bool Active
        {
            get
            {
                if (frame == Time.frameCount) return active;
                frame = Time.frameCount;
                BepInEx.PluginInfo info;
                if (!Chainloader.PluginInfos.TryGetValue("local.zompiercer.lan", out info) || info.Instance == null)
                    return active = false;
                if (!ReferenceEquals(instance, info.Instance))
                {
                    instance = info.Instance;
                    connected = null;
                    var type = instance.GetType();
                    var getter = type.GetProperty("Connected", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)?.GetGetMethod(true);
                    if (getter != null && getter.ReturnType == typeof(bool))
                        try { connected = (Func<bool>)Delegate.CreateDelegate(typeof(Func<bool>), instance, getter); } catch (ArgumentException) { }
                    var names = new[] { "LanTrainReplica", "LanWorldReplica", "LanZombieReplica", "RemoteAvatarMotion" };
                    markers = Array.ConvertAll(names, name => type.Assembly.GetType("ZompiercerLAN." + name, false));
                }
                try { return active = connected == null || connected(); }
                catch (Exception) { return active = true; }
            }
        }
        public static bool Owns(Component component)
        {
            if (component == null) return false;
            if (!Active && markers.Length == 0) return false;
            foreach (var type in markers)
                if (type != null && component.GetComponentInParent(type) != null) return true;
            return false;
        }
    }
}
