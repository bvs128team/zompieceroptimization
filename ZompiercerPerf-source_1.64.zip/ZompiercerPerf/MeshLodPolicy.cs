using System;
using System.Collections.Generic;

namespace ZompiercerPerf
{
    // Unity-free geometry policy. Input arrays are never changed.
    internal static class MeshLodPolicy
    {
        internal const int MinimumTriangles = 200;
        // Array reads and final mesh upload run on Unity's main thread; the
        // heavier reduction is limited to one background worker.
        internal const int MaximumVertices = 12000;
        internal const int MaximumTriangles = 20000;

        internal sealed class Data
        {
            internal float[] Positions; // xyz
            internal float[] Normals;   // xyz
            internal float[] Uv;        // xy, or null
            internal float[] Tangents;  // xyzw, or null
            internal int[][] Submeshes;
        }

        struct PositionKey : IEquatable<PositionKey>
        {
            readonly int x, y, z;
            internal PositionKey(float[] p, int vertex)
            {
                x = BitConverter.ToInt32(BitConverter.GetBytes(p[vertex * 3]), 0);
                y = BitConverter.ToInt32(BitConverter.GetBytes(p[vertex * 3 + 1]), 0);
                z = BitConverter.ToInt32(BitConverter.GetBytes(p[vertex * 3 + 2]), 0);
            }
            public bool Equals(PositionKey other) { return x == other.x && y == other.y && z == other.z; }
            public override bool Equals(object obj) { return obj is PositionKey && Equals((PositionKey)obj); }
            public override int GetHashCode() { unchecked { return ((x * 397) ^ y) * 397 ^ z; } }
        }

        struct CellKey : IEquatable<CellKey>
        {
            readonly int x, y, z;
            internal CellKey(float[] p, int vertex, float[] min, double scale)
            {
                x = (int)Math.Floor((p[vertex * 3] - min[0]) * scale);
                y = (int)Math.Floor((p[vertex * 3 + 1] - min[1]) * scale);
                z = (int)Math.Floor((p[vertex * 3 + 2] - min[2]) * scale);
            }
            public bool Equals(CellKey other) { return x == other.x && y == other.y && z == other.z; }
            public override bool Equals(object obj) { return obj is CellKey && Equals((CellKey)obj); }
            public override int GetHashCode() { unchecked { return ((x * 397) ^ y) * 397 ^ z; } }
        }

        struct FaceKey : IEquatable<FaceKey>
        {
            readonly int x, y, z;
            internal FaceKey(int a, int b, int c)
            {
                x = Math.Min(a, Math.Min(b, c));
                z = Math.Max(a, Math.Max(b, c));
                y = a + b + c - x - z;
            }
            public bool Equals(FaceKey other) { return x == other.x && y == other.y && z == other.z; }
            public override bool Equals(object obj) { return obj is FaceKey && Equals((FaceKey)obj); }
            public override int GetHashCode() { unchecked { return ((x * 397) ^ y) * 397 ^ z; } }
        }

        static bool Finite(float x) { return !float.IsNaN(x) && !float.IsInfinity(x); }
        static ulong Edge(int a, int b)
        {
            if (a > b) { int t = a; a = b; b = t; }
            return ((ulong)(uint)a << 32) | (uint)b;
        }
        static void AddEdge(Dictionary<ulong, int> edges, int a, int b)
        {
            ulong key = Edge(a, b);
            int count;
            edges.TryGetValue(key, out count);
            edges[key] = count + 1;
        }
        static void MarkSubmesh(int[] first, int vertex, int submesh)
        {
            if (first[vertex] == -1) first[vertex] = submesh;
            else if (first[vertex] != submesh) first[vertex] = -2;
        }
        static int Find(int[] parent, int x)
        {
            while (parent[x] != x)
            {
                parent[x] = parent[parent[x]];
                x = parent[x];
            }
            return x;
        }

        internal static Data Reduce(Data input)
        {
            if (input == null || input.Positions == null || input.Normals == null || input.Submeshes == null)
                return null;
            int count = input.Positions.Length / 3;
            if (count == 0 || count > MaximumVertices || input.Positions.Length != count * 3 ||
                input.Normals.Length != count * 3 ||
                (input.Uv != null && input.Uv.Length != count * 2) ||
                (input.Tangents != null && input.Tangents.Length != count * 4))
                return null;
            if (!AllFinite(input.Positions) || !AllFinite(input.Normals) ||
                (input.Uv != null && !AllFinite(input.Uv)) ||
                (input.Tangents != null && !AllFinite(input.Tangents)))
                return null;

            var min = new float[] { float.MaxValue, float.MaxValue, float.MaxValue };
            var max = new float[] { float.MinValue, float.MinValue, float.MinValue };
            for (int i = 0; i < count; i++)
            {
                for (int k = 0; k < 3; k++)
                {
                    float v = input.Positions[i * 3 + k];
                    if (v < min[k]) min[k] = v;
                    if (v > max[k]) max[k] = v;
                }
                double normal2 = LengthSquared(input.Normals, i, 3);
                if (normal2 < 0.25 || normal2 > 4) return null;
                if (input.Tangents != null)
                {
                    double tangent2 = LengthSquared(input.Tangents, i, 4);
                    if (tangent2 < 0.25 || tangent2 > 4 || Math.Abs(input.Tangents[i * 4 + 3]) < 0.5f)
                        return null;
                }
            }
            double extent = Math.Max(max[0] - min[0], Math.Max(max[1] - min[1], max[2] - min[2]));
            if (extent <= 0 || !Finite((float)extent)) return null;

            var edges = new Dictionary<ulong, int>();
            var used = new bool[count];
            var firstSubmesh = new int[count];
            for (int i = 0; i < count; i++) firstSubmesh[i] = -1;
            int triangles = 0;
            for (int s = 0; s < input.Submeshes.Length; s++)
            {
                int[] indices = input.Submeshes[s];
                if (indices == null || indices.Length % 3 != 0) return null;
                triangles += indices.Length / 3;
                if (triangles > MaximumTriangles) return null;
                for (int j = 0; j < indices.Length; j += 3)
                {
                    int a = indices[j], b = indices[j + 1], c = indices[j + 2];
                    if ((uint)a >= count || (uint)b >= count || (uint)c >= count || a == b || b == c || a == c)
                        return null;
                    if (AreaSquared(input.Positions, a, b, c) < extent * extent * extent * extent * 1e-20)
                        return null;
                    used[a] = used[b] = used[c] = true;
                    MarkSubmesh(firstSubmesh, a, s);
                    MarkSubmesh(firstSubmesh, b, s);
                    MarkSubmesh(firstSubmesh, c, s);
                    AddEdge(edges, a, b);
                    AddEdge(edges, b, c);
                    AddEdge(edges, c, a);
                }
            }
            if (triangles < MinimumTriangles) return null;
            var protectedVertex = new bool[count];
            var originalBoundary = new HashSet<ulong>();
            foreach (var edge in edges)
            {
                if (edge.Value > 2) return null;
                if (edge.Value == 1)
                {
                    int a = (int)(edge.Key >> 32), b = (int)edge.Key;
                    protectedVertex[a] = protectedVertex[b] = true;
                    originalBoundary.Add(edge.Key);
                }
            }
            var positionOwner = new Dictionary<PositionKey, int>();
            for (int i = 0; i < count; i++)
            {
                if (!used[i]) continue;
                int other;
                var key = new PositionKey(input.Positions, i);
                if (positionOwner.TryGetValue(key, out other))
                    protectedVertex[i] = protectedVertex[other] = true;
                else positionOwner[key] = i;
                if (firstSubmesh[i] == -2) protectedVertex[i] = true;
            }

            // Contract only adjacent vertices within one small spatial cell. Locked seam,
            // hard-edge, material-border, and open-boundary vertices never move.
            double cellsAcrossLargestAxis = Math.Min(40.0, Math.Max(12.0, Math.Sqrt(count) * 0.5));
            double scale = cellsAcrossLargestAxis / extent;
            var cells = new CellKey[count];
            var parent = new int[count];
            var size = new int[count];
            var uvMin = input.Uv == null ? null : new float[count * 2];
            var uvMax = input.Uv == null ? null : new float[count * 2];
            for (int i = 0; i < count; i++)
            {
                cells[i] = new CellKey(input.Positions, i, min, scale);
                parent[i] = i;
                size[i] = 1;
                if (uvMin != null)
                    for (int k = 0; k < 2; k++) uvMin[i * 2 + k] = uvMax[i * 2 + k] = input.Uv[i * 2 + k];
            }
            foreach (var edge in edges)
            {
                int a = (int)(edge.Key >> 32), b = (int)edge.Key;
                if (protectedVertex[a] || protectedVertex[b] || !cells[a].Equals(cells[b])) continue;
                int ra = Find(parent, a), rb = Find(parent, b);
                if (ra == rb) continue;
                if (Dot(input.Normals, a, b, 3) < 0.94) continue;
                if (input.Tangents != null &&
                    (input.Tangents[a * 4 + 3] * input.Tangents[b * 4 + 3] <= 0 ||
                     Dot(input.Tangents, a, b, 4) < 0.94)) continue;
                if (uvMin != null)
                {
                    bool tooWide = false;
                    for (int k = 0; k < 2; k++)
                    {
                        float low = Math.Min(uvMin[ra * 2 + k], uvMin[rb * 2 + k]);
                        float high = Math.Max(uvMax[ra * 2 + k], uvMax[rb * 2 + k]);
                        if (high - low > 0.08f) tooWide = true;
                    }
                    if (tooWide) continue;
                }
                if (size[ra] < size[rb]) { int t = ra; ra = rb; rb = t; }
                parent[rb] = ra;
                size[ra] += size[rb];
                if (uvMin != null)
                    for (int k = 0; k < 2; k++)
                    {
                        uvMin[ra * 2 + k] = Math.Min(uvMin[ra * 2 + k], uvMin[rb * 2 + k]);
                        uvMax[ra * 2 + k] = Math.Max(uvMax[ra * 2 + k], uvMax[rb * 2 + k]);
                    }
            }

            var roots = new Dictionary<int, int>();
            var remap = new int[count];
            var sumsP = new List<double[]>();
            var sumsN = new List<double[]>();
            var sumsUv = input.Uv == null ? null : new List<double[]>();
            var sumsT = input.Tangents == null ? null : new List<double[]>();
            var contributions = new List<int>();
            int usedCount = 0;
            for (int i = 0; i < count; i++)
            {
                if (!used[i]) { remap[i] = -1; continue; }
                usedCount++;
                int root = Find(parent, i), target;
                if (!roots.TryGetValue(root, out target))
                {
                    target = roots.Count;
                    roots[root] = target;
                    sumsP.Add(new double[3]); sumsN.Add(new double[3]);
                    if (sumsUv != null) sumsUv.Add(new double[2]);
                    if (sumsT != null) sumsT.Add(new double[4]);
                    contributions.Add(0);
                }
                remap[i] = target;
                contributions[target]++;
                for (int k = 0; k < 3; k++)
                {
                    sumsP[target][k] += input.Positions[i * 3 + k];
                    sumsN[target][k] += input.Normals[i * 3 + k];
                }
                if (sumsUv != null)
                    for (int k = 0; k < 2; k++) sumsUv[target][k] += input.Uv[i * 2 + k];
                if (sumsT != null)
                    for (int k = 0; k < 4; k++) sumsT[target][k] += input.Tangents[i * 4 + k];
            }
            if (roots.Count > usedCount * 0.8) return null;
            var output = new Data
            {
                Positions = new float[roots.Count * 3], Normals = new float[roots.Count * 3],
                Uv = sumsUv == null ? null : new float[roots.Count * 2],
                Tangents = sumsT == null ? null : new float[roots.Count * 4],
                Submeshes = new int[input.Submeshes.Length][]
            };
            for (int i = 0; i < roots.Count; i++)
            {
                for (int k = 0; k < 3; k++)
                {
                    output.Positions[i * 3 + k] = (float)(sumsP[i][k] / contributions[i]);
                    output.Normals[i * 3 + k] = (float)sumsN[i][k];
                }
                if (!Normalize(output.Normals, i, 3)) return null;
                if (sumsUv != null)
                    for (int k = 0; k < 2; k++) output.Uv[i * 2 + k] = (float)(sumsUv[i][k] / contributions[i]);
                if (sumsT != null)
                {
                    for (int k = 0; k < 3; k++) output.Tangents[i * 4 + k] = (float)sumsT[i][k];
                    if (!Normalize(output.Tangents, i, 4)) return null;
                    output.Tangents[i * 4 + 3] = sumsT[i][3] >= 0 ? 1f : -1f;
                }
            }

            int surviving = 0;
            var outputEdges = new Dictionary<ulong, int>();
            var usedOutput = new bool[roots.Count];
            for (int s = 0; s < input.Submeshes.Length; s++)
            {
                var result = new List<int>(input.Submeshes[s].Length);
                var seenFaces = new HashSet<FaceKey>();
                int[] indices = input.Submeshes[s];
                for (int j = 0; j < indices.Length; j += 3)
                {
                    int a = remap[indices[j]], b = remap[indices[j + 1]], c = remap[indices[j + 2]];
                    if (a == b || b == c || a == c) continue;
                    if (!SameFacing(input.Positions, indices[j], indices[j + 1], indices[j + 2], output.Positions, a, b, c))
                        return null;
                    if (!seenFaces.Add(new FaceKey(a, b, c))) return null;
                    result.Add(a); result.Add(b); result.Add(c);
                    usedOutput[a] = usedOutput[b] = usedOutput[c] = true;
                    AddEdge(outputEdges, a, b); AddEdge(outputEdges, b, c); AddEdge(outputEdges, c, a);
                    surviving++;
                }
                output.Submeshes[s] = result.ToArray();
                if (indices.Length != 0 && result.Count == 0) return null;
            }
            if (surviving > triangles * 0.8 || surviving == 0) return null;
            for (int i = 0; i < usedOutput.Length; i++) if (!usedOutput[i]) return null;
            var outputBoundary = new HashSet<ulong>();
            foreach (var edge in outputEdges)
            {
                if (edge.Value > 2) return null;
                if (edge.Value == 1) outputBoundary.Add(edge.Key);
            }
            if (outputBoundary.Count != originalBoundary.Count) return null;
            foreach (ulong edge in originalBoundary)
                if (!outputBoundary.Contains(Edge(remap[(int)(edge >> 32)], remap[(int)edge]))) return null;
            if (usedCount - edges.Count + triangles != roots.Count - outputEdges.Count + surviving) return null;
            return output;
        }

        static bool AllFinite(float[] array)
        {
            for (int i = 0; i < array.Length; i++) if (!Finite(array[i])) return false;
            return true;
        }
        static double LengthSquared(float[] a, int i, int stride)
        {
            double x = a[i * stride], y = a[i * stride + 1], z = a[i * stride + 2];
            return x * x + y * y + z * z;
        }
        static double Dot(float[] a, int i, int j, int stride)
        {
            return a[i * stride] * a[j * stride] + a[i * stride + 1] * a[j * stride + 1] + a[i * stride + 2] * a[j * stride + 2];
        }
        static bool Normalize(float[] a, int i, int stride)
        {
            double length = Math.Sqrt(LengthSquared(a, i, stride));
            if (length <= 1e-10) return false;
            for (int k = 0; k < 3; k++) a[i * stride + k] = (float)(a[i * stride + k] / length);
            return true;
        }
        static double AreaSquared(float[] p, int a, int b, int c)
        {
            int ai = a * 3, bi = b * 3, ci = c * 3;
            double ux = p[bi] - p[ai], uy = p[bi + 1] - p[ai + 1], uz = p[bi + 2] - p[ai + 2];
            double vx = p[ci] - p[ai], vy = p[ci + 1] - p[ai + 1], vz = p[ci + 2] - p[ai + 2];
            double x = uy * vz - uz * vy, y = uz * vx - ux * vz, z = ux * vy - uy * vx;
            return x * x + y * y + z * z;
        }
        static bool SameFacing(float[] original, int a, int b, int c, float[] reduced, int x, int y, int z)
        {
            int ai = a * 3, bi = b * 3, ci = c * 3, xi = x * 3, yi = y * 3, zi = z * 3;
            double oux = original[bi] - original[ai], ouy = original[bi + 1] - original[ai + 1], ouz = original[bi + 2] - original[ai + 2];
            double ovx = original[ci] - original[ai], ovy = original[ci + 1] - original[ai + 1], ovz = original[ci + 2] - original[ai + 2];
            double n0 = ouy * ovz - ouz * ovy, n1 = ouz * ovx - oux * ovz, n2 = oux * ovy - ouy * ovx;
            double rux = reduced[yi] - reduced[xi], ruy = reduced[yi + 1] - reduced[xi + 1], ruz = reduced[yi + 2] - reduced[xi + 2];
            double rvx = reduced[zi] - reduced[xi], rvy = reduced[zi + 1] - reduced[xi + 1], rvz = reduced[zi + 2] - reduced[xi + 2];
            return n0 * (ruy * rvz - ruz * rvy) + n1 * (ruz * rvx - rux * rvz) + n2 * (rux * rvy - ruy * rvx) > 0;
        }
    }
}
