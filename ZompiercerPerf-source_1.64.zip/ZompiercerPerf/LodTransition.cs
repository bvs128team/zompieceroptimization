using System;

namespace ZompiercerPerf
{
    internal static class LodTransition
    {
        internal static float Weight(float distance, float near, float far)
        {
            if (float.IsNaN(distance) || float.IsInfinity(distance)) return 0f;
            float linear = Math.Max(0f, Math.Min(1f, (distance - near) / Math.Max(1f, far - near)));
            return linear * linear * (3f - 2f * linear);
        }
        internal static float Step(float shown, float target, float elapsed, float seconds)
        {
            // Neither a hitch nor a teleport may skip a transition in a single frame.
            float step = Math.Max(0f, Math.Min(.05f, elapsed)) / Math.Max(.1f, seconds);
            return target > shown ? Math.Min(target, shown + step) : Math.Max(target, shown - step);
        }
        internal static float CompositeAlpha(float weight, float finerWeight)
        { return weight <= 0f ? 0f : Math.Max(0f, Math.Min(1f, weight / Math.Max(.000001f, 1f - finerWeight))); }
        internal static void StepWeights(float[] weights, int selected, float elapsed, float seconds)
        {
            float sum = 0f;
            for (int i = 0; i < weights.Length; i++)
            { weights[i] = Step(weights[i], i == selected ? 1f : 0f, elapsed, seconds); sum += weights[i]; }
            // Include the cull slot: normalization must not turn a tiny fade-in into full visibility.
            if (sum > 0f) for (int i = 0; i < weights.Length; i++) weights[i] /= sum;
        }
        internal static int Level(float relativeHeight, float[] thresholds, int minimum)
        {
            for (int i = Math.Max(0, minimum); i < thresholds.Length; i++)
                if (relativeHeight >= thresholds[i]) return i;
            return thresholds.Length;
        }
    }
}
