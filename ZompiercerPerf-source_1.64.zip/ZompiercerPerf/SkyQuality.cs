using System;
using System.Reflection;
using UnityEngine;

namespace ZompiercerPerf
{
    // Enviro volumetric clouds and volume lighting. The game sets them only from its scenes, so the
    // mod swaps in a reduced copy of the cloud quality settings (never edits the shared preset asset)
    // and puts the scene's own values back when the option or the mod is switched off.
    static class SkyQuality
    {
        static readonly MethodInfo Clone = typeof(object).GetMethod("MemberwiseClone", BindingFlags.Instance | BindingFlags.NonPublic);
        static EnviroSky sky;
        static EnviroVolumeCloudsQualitySettings originalClouds, appliedClouds;
        static bool originalVolumeClouds, originalFlatClouds, originalVolumeLighting;
        static EnviroSkyRendering.VolumtericResolution originalResolution;
        static bool captured;
        static int appliedCloudsLevel = -1, appliedLight = -1;
        static float nextFind;

        public static void Tick()
        {
            var tune = PerfPlugin.Tune;
            int clouds = tune.Bypass || tune.Preset == 0 ? 0 : tune.Clouds;
            int light = tune.Bypass || tune.Preset == 0 ? 0 : tune.VolumeLight;
            if (sky == null)
            {
                captured = false;
                if (clouds == 0 && light == 0 || Time.unscaledTime < nextFind)
                    return;
                nextFind = Time.unscaledTime + 1f;
                sky = EnviroSky.instance; // FindObjectOfType; never creates one
                if (sky == null || sky.cloudsSettings == null || sky.volumeLightSettings == null)
                {
                    sky = null;
                    return;
                }
            }
            if (!captured)
            {
                originalClouds = sky.cloudsSettings.cloudsQualitySettings;
                originalVolumeClouds = sky.useVolumeClouds;
                originalFlatClouds = sky.useFlatClouds;
                originalVolumeLighting = sky.useVolumeLighting;
                originalResolution = sky.volumeLightSettings.Resolution;
                appliedCloudsLevel = appliedLight = 0;
                appliedClouds = null;
                captured = true;
            }
            if (clouds != appliedCloudsLevel)
                ApplyClouds(clouds);
            if (light != appliedLight)
                ApplyLight(light);
        }

        static void ApplyClouds(int level)
        {
            if (appliedClouds != null)
            {
                if (ReferenceEquals(sky.cloudsSettings.cloudsQualitySettings, appliedClouds))
                    sky.cloudsSettings.cloudsQualitySettings = originalClouds;
                else
                    originalClouds = sky.cloudsSettings.cloudsQualitySettings; // another preset was chosen meanwhile
            }
            appliedClouds = null;
            sky.useVolumeClouds = originalVolumeClouds;
            sky.useFlatClouds = originalFlatClouds;
            appliedCloudsLevel = level;
            if (level <= 0 || originalClouds == null)
                return;
            if (level >= 4)
            {
                // Flat clouds: the volumetric pass is skipped entirely.
                sky.useVolumeClouds = false;
                sky.useFlatClouds = true;
                return;
            }
            float steps = level == 1 ? .8f : level == 2 ? .6f : .4f;
            int resolution = level == 1 ? 1 : 2;
            var reprojection = level == 1 ? EnviroVolumeCloudsQualitySettings.ReprojectionPixelSize.Low
                : level == 2 ? EnviroVolumeCloudsQualitySettings.ReprojectionPixelSize.Medium
                : EnviroVolumeCloudsQualitySettings.ReprojectionPixelSize.High;
            var copy = (EnviroVolumeCloudsQualitySettings)Clone.Invoke(originalClouds, null);
            copy.raymarchSteps = Mathf.Max(16, Mathf.RoundToInt(originalClouds.raymarchSteps * steps));
            copy.cloudsRenderResolution = Mathf.Max(Mathf.Max(1, originalClouds.cloudsRenderResolution), resolution);
            if ((int)copy.reprojectionPixelSize < (int)reprojection)
                copy.reprojectionPixelSize = reprojection;
            sky.cloudsSettings.cloudsQualitySettings = copy;
            appliedClouds = copy;
        }

        static void ApplyLight(int level)
        {
            sky.useVolumeLighting = originalVolumeLighting;
            sky.volumeLightSettings.Resolution = originalResolution;
            appliedLight = level;
            if (level <= 0)
                return;
            if (level >= 3)
            {
                sky.useVolumeLighting = false;
                return;
            }
            var wanted = level == 1 ? EnviroSkyRendering.VolumtericResolution.Half : EnviroSkyRendering.VolumtericResolution.Quarter;
            if ((int)sky.volumeLightSettings.Resolution < (int)wanted)
                sky.volumeLightSettings.Resolution = wanted;
        }

        public static void Restore()
        {
            if (sky != null && captured)
            {
                ApplyClouds(0);
                ApplyLight(0);
            }
            sky = null;
            captured = false;
            appliedClouds = null;
            appliedCloudsLevel = appliedLight = -1;
            nextFind = 0f;
        }

        public static string Describe()
        {
            if (sky == null || !captured)
                return "";
            return "облака " + (appliedClouds != null ? appliedClouds.raymarchSteps + " шагов" : sky.useVolumeClouds ? "как в игре" : "плоские")
                + ", объёмный свет " + (sky.useVolumeLighting ? sky.volumeLightSettings.Resolution.ToString() : "выкл");
        }
    }
}
