using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;

namespace ZompiercerPerf
{
    // Render scale with FSR 1 upscaling. The game camera (and screen cameras drawn before it) render into
    // a smaller texture; a hidden output camera upscales it to the screen before any later camera or
    // overlay UI draws. Screen-space camera math is rescaled, so mouse rays, aiming and UI markers keep
    // working in screen pixels. Everything is local to this PC.
    static class RenderScale
    {
        // Config values keep their meaning across versions: 90 % and 85 % (1.3.1) were appended after
        // "auto" (5, whose slot here is unused); the menu shows them in size order.
        public static readonly float[] Scales = { 1f, 1f / 1.3f, 1f / 1.5f, 1f / 1.7f, .5f, 1f, .9f, .85f };
        public const int AutoIndex = 5;
        public static readonly int[] TargetFpsValues = { 45, 60, 75, 90, 120, 144 };
        static readonly float[] SharpnessStops = { 1.2f, .6f, .2f };
        const string BundleName = "zompiercerperf-fsr.bundle";

        static Material fsr;
        static bool loadTried, patched, failed;
        static string fsrProblem;
        static Camera main;
        static readonly List<Camera> Redirected = new List<Camera>();
        static readonly List<Canvas> MovedCanvases = new List<Canvas>();
        static readonly List<Camera> CanvasCameras = new List<Camera>();
        static RenderTexture low, mid;
        static Camera output;
        static CommandBuffer commands;
        static int builtW, builtH, builtUpscaler = -1, builtSharpness = -1, builtScreenW, builtScreenH;
        // The blits reference the textures themselves: a texture recreated at the same size
        // (MSAA change) must rebuild the commands too, or the output reads a released texture.
        static RenderTexture builtLow, builtMid;
        static float nextScan;
        static Vector2 toTarget = Vector2.one, toScreen = Vector2.one;

        public static bool Active { get { return low != null && main != null; } }

        public static bool Owns(Camera camera)
        {
            return low != null && camera != null && camera.targetTexture == low;
        }

        public static string Describe()
        {
            if (!Active)
                return "";
            return "рендер " + low.width + "x" + low.height + (PerfPlugin.Tune.RenderScale == AutoIndex ? " (авто)" : "")
                + " " + (UsingFsr() ? "FSR 1" : "простая растяжка");
        }

        public static void Patch(Harmony harmony)
        {
            // The managed wrappers are small enough for Mono to inline; the icalls below cannot be.
            try
            {
                var eye = typeof(Camera.MonoOrStereoscopicEye);
                var v2 = typeof(Vector2).MakeByRefType();
                var v3 = typeof(Vector3).MakeByRefType();
                PatchOne(harmony, "ScreenPointToRay_Injected", new[] { v2, eye, typeof(Ray).MakeByRefType() }, "RayIn", null);
                PatchOne(harmony, "ScreenToWorldPoint_Injected", new[] { v3, eye, v3 }, "PointIn", null);
                PatchOne(harmony, "ScreenToViewportPoint_Injected", new[] { v3, v3 }, "PointIn", null);
                PatchOne(harmony, "WorldToScreenPoint_Injected", new[] { v3, eye, v3 }, null, "PointOut3");
                PatchOne(harmony, "ViewportToScreenPoint_Injected", new[] { v3, v3 }, null, "PointOut2");
                patched = true;
            }
            catch (Exception ex)
            {
                // Without these the crosshair ray would miss at a lower resolution: keep native resolution.
                patched = false;
                Log("Масштаб рендера недоступен: не удалось перехватить координаты камеры: " + ex.Message, true);
            }
        }

        static void PatchOne(Harmony harmony, string name, Type[] args, string prefix, string postfix)
        {
            var method = AccessTools.Method(typeof(Camera), name, args);
            if (method == null)
                throw new MissingMethodException("Camera." + name);
            harmony.Patch(method,
                prefix == null ? null : new HarmonyMethod(typeof(RenderScale), prefix),
                postfix == null ? null : new HarmonyMethod(typeof(RenderScale), postfix));
        }

        static void RayIn(Camera __instance, ref Vector2 __0)
        {
            if (Owns(__instance)) __0 = Vector2.Scale(__0, toTarget);
        }

        static void PointIn(Camera __instance, ref Vector3 __0)
        {
            if (Owns(__instance)) { __0.x *= toTarget.x; __0.y *= toTarget.y; }
        }

        static void PointOut3(Camera __instance, ref Vector3 __2)
        {
            if (Owns(__instance)) { __2.x *= toScreen.x; __2.y *= toScreen.y; }
        }

        static void PointOut2(Camera __instance, ref Vector3 __1)
        {
            if (Owns(__instance)) { __1.x *= toScreen.x; __1.y *= toScreen.y; }
        }

        public static void ResetFailure()
        {
            failed = false;
        }

        public static void Tick()
        {
            if (failed)
                return;
            try { Update(); }
            catch (Exception ex)
            {
                failed = true;
                Log("Масштаб рендера выключен из-за ошибки: " + ex, true);
                try { Release(); } catch (Exception) { }
            }
        }

        static void Update()
        {
            var tune = PerfPlugin.Tune;
            bool auto = tune.RenderScale == AutoIndex;
            float scale = auto ? AutoScale.Current : Scales[Mathf.Clamp(tune.RenderScale, 0, Scales.Length - 1)];
            // At 100 % the same FSR passes only sharpen (EASU at 1:1 is close to a copy, RCAS sharpens).
            bool sharpenOnly = !auto && scale >= .999f && tune.Sharpen && LoadFsr();
            bool wanted = patched && !tune.Bypass && tune.Preset != 0 && (scale < .999f || auto || sharpenOnly);
            var camera = wanted ? GameCamera() : null;
            if (camera == null || !camera.isActiveAndEnabled || Screen.width < 64 || Screen.height < 64)
            {
                Release();
                return;
            }
            if (!ReferenceEquals(camera, main))
            {
                Release();
                main = camera;
            }
            int width = Mathf.Max(32, Mathf.RoundToInt(Screen.width * scale));
            int height = Mathf.Max(32, Mathf.RoundToInt(Screen.height * scale));
            bool useFsr = (tune.Upscaler == 0 || sharpenOnly) && LoadFsr();
            int msaa = main.allowMSAA && main.actualRenderingPath == RenderingPath.Forward ? Mathf.Max(1, QualitySettings.antiAliasing) : 1;
            if (low == null || low.width != width || low.height != height || low.antiAliasing != msaa)
            {
                Unredirect();
                ReleaseTexture(ref low);
                low = new RenderTexture(width, height, 24, RenderTextureFormat.Default, RenderTextureReadWrite.Default);
                low.name = "ZompiercerPerf scaled scene";
                low.antiAliasing = msaa;
                low.filterMode = FilterMode.Bilinear;
                low.wrapMode = TextureWrapMode.Clamp;
                low.Create();
            }
            toTarget = new Vector2(width / (float)Screen.width, height / (float)Screen.height);
            toScreen = new Vector2(Screen.width / (float)width, Screen.height / (float)height);
            if (useFsr && (mid == null || mid.width != Screen.width || mid.height != Screen.height))
            {
                ReleaseTexture(ref mid);
                mid = new RenderTexture(Screen.width, Screen.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
                mid.name = "ZompiercerPerf FSR";
                mid.filterMode = FilterMode.Point;
                mid.wrapMode = TextureWrapMode.Clamp;
                mid.Create();
            }
            else if (!useFsr)
                ReleaseTexture(ref mid);
            EnsureOutput();
            if (Time.unscaledTime >= nextScan || main.targetTexture != low)
            {
                nextScan = Time.unscaledTime + 2f;
                Redirect();
                PlaceOutput();
                MoveCanvases();
            }
            int sharpness = Mathf.Clamp(tune.Sharpness, 0, SharpnessStops.Length - 1);
            if (builtW != width || builtH != height || builtScreenW != Screen.width || builtScreenH != Screen.height
                || builtUpscaler != (useFsr ? 0 : 1) || builtSharpness != sharpness
                || !ReferenceEquals(builtLow, low) || !ReferenceEquals(builtMid, useFsr ? mid : null))
                BuildCommands(useFsr, sharpness);
            if (auto)
                AutoScale.Sample(TargetFpsValues[Mathf.Clamp(tune.TargetFps, 0, TargetFpsValues.Length - 1)]);
            else
                AutoScale.Reset();
            // Textures are sampled as for the lower resolution; a negative mip bias keeps their detail.
            MipBias.Apply(tune.MipBias && scale < .999f ? Mathf.Log(width / (float)Screen.width, 2f) : 0f);
        }

        static Camera GameCamera()
        {
            var manager = GlobalManager.global;
            if (manager != null && manager.MainCamera != null)
                return manager.MainCamera;
            return Camera.main;
        }

        static bool UsingFsr()
        {
            return PerfPlugin.Tune.Upscaler == 0 && fsr != null;
        }

        static bool LoadFsr()
        {
            if (loadTried)
                return fsr != null;
            loadTried = true;
            try
            {
                string path = Path.Combine(Path.GetDirectoryName(typeof(RenderScale).Assembly.Location), BundleName);
                if (!File.Exists(path))
                    fsrProblem = "нет файла " + BundleName + " рядом с ZompiercerPerf.dll";
                else
                {
                    var bundle = AssetBundle.LoadFromFile(path);
                    Shader shader = null;
                    if (bundle != null)
                    {
                        var shaders = bundle.LoadAllAssets<Shader>();
                        shader = shaders.Length > 0 ? shaders[0] : null;
                        bundle.Unload(false);
                    }
                    if (shader == null)
                        fsrProblem = "файл " + BundleName + " не читается этой версией игры";
                    else if (!shader.isSupported)
                        fsrProblem = "шейдер FSR не поддерживается видеокартой или графическим API";
                    else
                    {
                        fsr = new Material(shader);
                        fsr.hideFlags = HideFlags.HideAndDontSave;
                    }
                }
            }
            catch (Exception ex)
            {
                fsrProblem = ex.Message;
            }
            if (fsr == null)
                Log("FSR недоступен, используется простая растяжка: " + fsrProblem, true);
            return fsr != null;
        }

        static void EnsureOutput()
        {
            if (output != null)
                return;
            var go = new GameObject("__PerfFsrOutput");
            // Hidden from FindObjectsOfType: the game's menu reset must not destroy it mid-frame.
            go.hideFlags = HideFlags.HideAndDontSave;
            UnityEngine.Object.DontDestroyOnLoad(go);
            output = go.AddComponent<Camera>();
            output.cullingMask = 0;
            output.clearFlags = CameraClearFlags.Depth;
            output.renderingPath = RenderingPath.Forward;
            output.allowHDR = false;
            output.allowMSAA = false;
            output.useOcclusionCulling = false;
            output.orthographic = true;
            output.nearClipPlane = .01f;
            output.farClipPlane = 10f;
            commands = new CommandBuffer { name = "ZompiercerPerf upscale" };
            output.AddCommandBuffer(CameraEvent.BeforeForwardOpaque, commands);
            builtUpscaler = -1;
        }

        static void BuildCommands(bool useFsr, int sharpness)
        {
            commands.Clear();
            if (useFsr)
            {
                float inW = low.width, inH = low.height, outW = Screen.width, outH = Screen.height;
                fsr.SetVector("_Con0", new Vector4(inW / outW, inH / outH, .5f * inW / outW - .5f, .5f * inH / outH - .5f));
                fsr.SetVector("_Con1", new Vector4(1f / inW, 1f / inH, 1f / inW, -1f / inH));
                fsr.SetVector("_Con2", new Vector4(-1f / inW, 2f / inH, 1f / inW, 2f / inH));
                fsr.SetVector("_Con3", new Vector4(0f, 4f / inH, 0f, 0f));
                fsr.SetVector("_OutSize", new Vector4(outW, outH, 1f / outW, 1f / outH));
                fsr.SetFloat("_Linear", QualitySettings.activeColorSpace == ColorSpace.Linear ? 1f : 0f);
                fsr.SetFloat("_Sharpness", Mathf.Pow(2f, -SharpnessStops[sharpness]));
                commands.Blit(low, mid, fsr, 0);
                commands.Blit(mid, BuiltinRenderTextureType.CameraTarget, fsr, 1);
            }
            else
                commands.Blit(low, BuiltinRenderTextureType.CameraTarget);
            builtW = low.width;
            builtH = low.height;
            builtScreenW = Screen.width;
            builtScreenH = Screen.height;
            builtUpscaler = useFsr ? 0 : 1;
            builtSharpness = sharpness;
            builtLow = low;
            builtMid = useFsr ? mid : null;
        }

        static void Redirect()
        {
            // Screen cameras drawn before (or as) the game camera belong to the scaled image.
            Redirected.RemoveAll(camera => camera == null || camera.targetTexture != low);
            var cameras = Camera.allCameras;
            for (int i = 0; i < cameras.Length; i++)
            {
                var camera = cameras[i];
                if (camera == output || camera.targetTexture != null || camera.depth > main.depth && camera != main)
                    continue;
                camera.targetTexture = low;
                if (!Redirected.Contains(camera))
                    Redirected.Add(camera);
            }
        }

        static void PlaceOutput()
        {
            float above = main.depth + 1f;
            var cameras = Camera.allCameras;
            for (int i = 0; i < cameras.Length; i++)
            {
                var camera = cameras[i];
                if (camera != output && camera.targetTexture == null && camera.depth > main.depth && camera.depth < above)
                    above = camera.depth;
            }
            // Directly after the game camera, before any overlay camera such as a weapon or UI camera.
            output.depth = main.depth + (above - main.depth) * .5f;
        }

        static void MoveCanvases()
        {
            var canvases = UnityEngine.Object.FindObjectsOfType<Canvas>();
            for (int i = 0; i < canvases.Length; i++)
            {
                var canvas = canvases[i];
                if (!canvas.isRootCanvas || canvas.renderMode != RenderMode.ScreenSpaceCamera || canvas.worldCamera == null
                    || !Redirected.Contains(canvas.worldCamera) || MovedCanvases.Contains(canvas))
                    continue;
                // A camera-space HUD would be scaled too; draw it with the output camera at full resolution.
                MovedCanvases.Add(canvas);
                CanvasCameras.Add(canvas.worldCamera);
                output.cullingMask |= 1 << canvas.gameObject.layer;
                canvas.worldCamera = output;
            }
        }

        static void Unredirect()
        {
            for (int i = 0; i < Redirected.Count; i++)
                if (Redirected[i] != null && Redirected[i].targetTexture == low)
                    Redirected[i].targetTexture = null;
            Redirected.Clear();
            nextScan = 0f;
        }

        public static void Release()
        {
            MipBias.Restore();
            AutoScale.Reset();
            if (low == null && output == null && main == null)
                return;
            Unredirect();
            for (int i = 0; i < MovedCanvases.Count; i++)
                if (MovedCanvases[i] != null && MovedCanvases[i].worldCamera == output)
                    MovedCanvases[i].worldCamera = CanvasCameras[i];
            MovedCanvases.Clear();
            CanvasCameras.Clear();
            if (output != null)
            {
                if (commands != null)
                    output.RemoveCommandBuffer(CameraEvent.BeforeForwardOpaque, commands);
                UnityEngine.Object.Destroy(output.gameObject);
            }
            if (commands != null)
                commands.Release();
            commands = null;
            output = null;
            ReleaseTexture(ref low);
            ReleaseTexture(ref mid);
            main = null;
            builtUpscaler = builtSharpness = -1;
            builtLow = builtMid = null;
            toTarget = toScreen = Vector2.one;
        }

        static void ReleaseTexture(ref RenderTexture texture)
        {
            if (texture == null)
                return;
            texture.Release();
            UnityEngine.Object.Destroy(texture);
            texture = null;
        }

        static void Log(string message, bool warning)
        {
            if (PerfPlugin.Instance == null)
                return;
            if (warning) PerfPlugin.Instance.LogWarning(message);
            else PerfPlugin.Instance.LogInfo(message);
        }
    }

    // Picks the render scale for a target frame rate: lowers it 5 % at a time while the frame rate is
    // short, raises it again with plenty of headroom. When lowering gives no gain the frame is limited
    // by the CPU, so the previous scale comes back and stays for a while.
    static class AutoScale
    {
        const float Lowest = .5f, Step = .05f;
        public static float Current = 1f;
        static float windowTime, worstFrame, probeFps, previous, holdUntil;
        static int windowFrames, headroom;
        static bool probing;

        public static void Reset()
        {
            Current = 1f;
            windowTime = worstFrame = 0f;
            windowFrames = headroom = 0;
            probing = false;
            holdUntil = 0f;
        }

        public static void Sample(int target)
        {
            float step = Time.unscaledDeltaTime;
            if (step <= 0f)
                return;
            windowTime += step;
            windowFrames++;
            worstFrame = Mathf.Max(worstFrame, step);
            if (windowTime < 1f)
                return;
            float fps = windowFrames / windowTime;
            bool loading = worstFrame > .25f || windowFrames < 15;
            windowTime = worstFrame = 0f;
            windowFrames = 0;
            if (loading)
                return; // a load or a hitch says nothing about the resolution
            float now = Time.realtimeSinceStartup;
            if (probing)
            {
                probing = false;
                if (fps < probeFps * 1.02f)
                {
                    Current = previous;
                    holdUntil = now + 15f;
                    return;
                }
            }
            if (now < holdUntil)
                return;
            if (fps < target * .97f && Current > Lowest + .001f)
            {
                previous = Current;
                probeFps = fps;
                Current = Mathf.Max(Lowest, Mathf.Round((Current - Step) * 20f) / 20f);
                probing = true;
                headroom = 0;
            }
            else if (fps > target * 1.12f && Current < .999f)
            {
                if (++headroom >= 3)
                {
                    Current = Mathf.Min(1f, Mathf.Round((Current + Step) * 20f) / 20f);
                    headroom = 0;
                }
            }
            else
                headroom = 0;
        }
    }

    // Negative mip bias for every mipmapped 2D texture while the scene renders below screen size.
    // Each texture keeps its own original bias; a value changed by the game meanwhile is adopted.
    static class MipBias
    {
        sealed class Entry
        {
            public Texture2D Texture;
            public float Original, Applied;
        }

        static readonly Dictionary<int, Entry> Entries = new Dictionary<int, Entry>();
        static readonly List<Entry> Order = new List<Entry>();
        static float bias, nextScan;
        static int cursor, sceneMark = -1;

        public static void Apply(float wanted)
        {
            wanted = Mathf.Clamp(Mathf.Round(wanted * 20f) / 20f, -1f, 0f);
            if (wanted == 0f)
            {
                Restore();
                return;
            }
            bias = wanted;
            int mark = UnityEngine.SceneManagement.SceneManager.sceneCount * 7919 + UnityEngine.SceneManagement.SceneManager.GetActiveScene().handle;
            if (Order.Count == 0 || mark != sceneMark || Time.unscaledTime >= nextScan)
            {
                // A full texture search is not free: on start, after scene changes and once a minute.
                sceneMark = mark;
                nextScan = Time.unscaledTime + 60f;
                Scan();
            }
            int steps = Mathf.Min(500, Order.Count);
            for (int n = 0; n < steps; n++)
            {
                if (cursor >= Order.Count) cursor = 0;
                var entry = Order[cursor++];
                if (entry.Texture == null)
                    continue;
                float current = entry.Texture.mipMapBias;
                if (Mathf.Abs(current - entry.Applied) > .001f)
                    entry.Original = current;
                float target = entry.Original + bias;
                if (Mathf.Abs(current - target) > .001f)
                    entry.Texture.mipMapBias = target;
                entry.Applied = target;
            }
        }

        static void Scan()
        {
            Order.RemoveAll(entry => entry.Texture == null);
            Entries.Clear();
            foreach (var entry in Order) Entries[entry.Texture.GetInstanceID()] = entry;
            var textures = Resources.FindObjectsOfTypeAll<Texture2D>();
            for (int i = 0; i < textures.Length; i++)
            {
                var texture = textures[i];
                if (texture == null || texture.mipmapCount <= 1 || Entries.ContainsKey(texture.GetInstanceID()))
                    continue;
                var entry = new Entry { Texture = texture, Original = texture.mipMapBias, Applied = texture.mipMapBias };
                Entries[texture.GetInstanceID()] = entry;
                Order.Add(entry);
            }
        }

        public static void Restore()
        {
            if (Order.Count == 0)
                return;
            foreach (var entry in Order)
                if (entry.Texture != null && Mathf.Abs(entry.Texture.mipMapBias - entry.Applied) <= .001f)
                    entry.Texture.mipMapBias = entry.Original;
            Order.Clear();
            Entries.Clear();
            cursor = 0;
            sceneMark = -1;
            bias = 0f;
        }
    }
}
