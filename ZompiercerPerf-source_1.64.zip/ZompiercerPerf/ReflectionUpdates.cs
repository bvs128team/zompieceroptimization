using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Rendering;

namespace ZompiercerPerf
{
    // How often realtime reflection probes (sky and surroundings in reflections) are re-rendered.
    // The game's RealtimeReflection renders its probe every frame, GlobalReflections and
    // ReflectionProbeUpdater on timers, Enviro on game time; Unity's "every frame" probes refresh
    // themselves. Script renders of one probe are limited to one per interval (the first one always
    // runs), and "every frame" probes are switched to script refresh on the same interval.
    static class ReflectionUpdates
    {
        static readonly float[] Intervals = { 0f, .5f, 2f };

        sealed class Probe
        {
            public ReflectionProbe Target;
            public float Last = -1f;
            public int LastId;
            public bool Switched;
            public ReflectionProbeRefreshMode OriginalMode;
        }

        static readonly Dictionary<int, Probe> Probes = new Dictionary<int, Probe>();
        static readonly List<int> Dead = new List<int>();
        static bool patched, forcing;
        static float nextScan;

        public static int Throttled { get; private set; }

        static float Interval
        {
            get
            {
                var tune = PerfPlugin.Tune;
                return tune.Bypass || tune.Preset == 0 ? 0f : Intervals[Mathf.Clamp(tune.ProbeUpdate, 0, Intervals.Length - 1)];
            }
        }

        public static void Patch(Harmony harmony)
        {
            try
            {
                var method = AccessTools.Method(typeof(ReflectionProbe), "ScheduleRender",
                    new[] { typeof(ReflectionProbeTimeSlicingMode), typeof(RenderTexture) });
                if (method == null)
                    throw new MissingMethodException("ReflectionProbe.ScheduleRender");
                harmony.Patch(method, new HarmonyMethod(typeof(ReflectionUpdates), "Before"),
                    new HarmonyMethod(typeof(ReflectionUpdates), "After"));
                patched = true;
            }
            catch (Exception ex)
            {
                if (PerfPlugin.Instance != null)
                    PerfPlugin.Instance.LogWarning("Частота отражений недоступна: " + ex.Message);
            }
        }

        static Probe Of(ReflectionProbe probe)
        {
            Probe entry;
            int id = probe.GetInstanceID();
            if (!Probes.TryGetValue(id, out entry) || entry.Target == null)
                Probes[id] = entry = new Probe { Target = probe };
            return entry;
        }

        // Renders into the probe's own texture only. A render into a caller's texture is neither
        // limited nor counted: counting it would delay the probe's own next refresh.
        // __state: this render runs and refreshes the probe's own texture.
        static bool Before(ReflectionProbe __instance, RenderTexture __1, ref int __result, out bool __state)
        {
            __state = false;
            float interval = Interval;
            if (__1 != null || __instance == null || interval <= 0f)
                return true;
            __state = true;
            if (forcing)
                return true;
            var entry = Of(__instance);
            if (entry.Last >= 0f && Time.unscaledTime - entry.Last < interval)
            {
                __result = entry.LastId;
                __state = false;
                Throttled++;
                return false;
            }
            return true;
        }

        static void After(ReflectionProbe __instance, int __result, bool __state)
        {
            if (!__state || __instance == null || !patched)
                return;
            var entry = Of(__instance);
            entry.Last = Time.unscaledTime;
            entry.LastId = __result;
        }

        public static void Tick()
        {
            float interval = Interval;
            if (!patched || interval <= 0f)
            {
                Restore();
                return;
            }
            float now = Time.unscaledTime;
            if (now >= nextScan)
            {
                nextScan = now + 5f;
                Dead.Clear();
                foreach (var pair in Probes)
                    if (pair.Value.Target == null)
                        Dead.Add(pair.Key);
                foreach (int id in Dead)
                    Probes.Remove(id);
                foreach (var probe in UnityEngine.Object.FindObjectsOfType<ReflectionProbe>())
                {
                    if (probe.mode != ReflectionProbeMode.Realtime || probe.refreshMode != ReflectionProbeRefreshMode.EveryFrame)
                        continue;
                    var entry = Of(probe);
                    entry.OriginalMode = probe.refreshMode;
                    entry.Switched = true;
                    probe.refreshMode = ReflectionProbeRefreshMode.ViaScripting;
                }
            }
            // Switched probes: one render per interval, spread over frames by the per-probe clock.
            foreach (var entry in Probes.Values)
            {
                if (!entry.Switched || entry.Target == null || !entry.Target.isActiveAndEnabled)
                    continue;
                if (entry.Last >= 0f && now - entry.Last < interval)
                    continue;
                forcing = true;
                try { entry.Target.RenderProbe(); }
                finally { forcing = false; }
                break; // at most one forced probe render per frame
            }
        }

        public static void Restore()
        {
            if (Probes.Count == 0)
                return;
            foreach (var entry in Probes.Values)
                if (entry.Switched && entry.Target != null && entry.Target.refreshMode == ReflectionProbeRefreshMode.ViaScripting)
                    entry.Target.refreshMode = entry.OriginalMode;
            Probes.Clear();
            nextScan = 0f;
        }

        public static string Describe()
        {
            if (Interval <= 0f)
                return "";
            int switched = 0;
            foreach (var entry in Probes.Values)
                if (entry.Switched)
                    switched++;
            return "отражения: пропущено перерисовок " + Throttled + ", probe «каждый кадр» " + switched;
        }
    }
}
