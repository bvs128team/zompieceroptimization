using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using HarmonyLib;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Zompiercer.GUI;
using Zompiercer.Inputs;

namespace ZompiercerPerf
{
    static class Benchmark
    {
        const float WarmupSeconds = 4f;
        const float WalkSeconds = 36f;
        const float FlySeconds = 12f;
        const string FallbackScene = "ZCSBaseTerrain";
        const float FallbackTrain = 38.5f;

        enum Phase { Idle, WaitMenu, Load, Arrive, Warmup, Walk, Fly, Returning }

        static readonly float[] RingX = { 0f, 16f, 28f, 18f, -6f, -26f, -18f, 8f };
        static readonly float[] RingZ = { 26f, 34f, 8f, -22f, -30f, -8f, 22f, 40f };

        static Phase phase;
        static bool requested;
        static bool hooked;
        static float phaseTime;
        static float stableTime;
        static float stuckTime;
        // Stuck test over 0.5 s windows: a per-frame distance limit depended on the frame rate
        // (4 m/s at 144 FPS is under 3 cm a frame) and switched goals every 2.2 s at high FPS.
        const float StuckWindow = 0.5f;
        const float StuckMinMove = 0.35f;
        static float stuckWindow;
        static Vector3 stuckAnchor;
        static float travel;
        static float heading;
        static int arriveCharacter = int.MinValue;
        static int goalIndex;
        static int corner;
        static int rings;
        static int failedGoal = -2;
        static bool pathReady;
        static string sceneName = FallbackScene;
        static string failure;
        static string summary = "";
        static Vector3 origin;
        static Vector3 basisForward = Vector3.forward;
        static Vector3 basisRight = Vector3.right;
        static Vector3 lastPosition;
        static bool haveLast;
        static readonly List<Vector3> Goals = new List<Vector3>();
        static readonly List<Vector3> Trail = new List<Vector3>();
        static readonly List<float> WalkFrames = new List<float>();
        static readonly List<float> FlyFrames = new List<float>();
        static readonly NavMeshPath Route = new NavMeshPath();
        static bool cameraHeld;
        static Camera flyCam;
        static Transform flyParent;
        static Vector3 flyLocalPos;
        static Quaternion flyLocalRot;
        static bool flyCamWasEnabled = true;
        static readonly List<Vector3> FlyPoints = new List<Vector3>();
        static readonly List<float> FlyLength = new List<float>();
        static Vector3 flyPosition;
        static Quaternion flyRotation = Quaternion.identity;
        static Vector3 flyStartPos;
        static Quaternion flyStartRot = Quaternion.identity;
        static string flyNote;
        static int compare; // 0 single run, 1 comparison run with the mod, 2 run as without the mod
        static bool firstReady;
        static FrameStat firstWalk;
        static FrameStat firstFly;
        static float firstTravel;
        static string notice;
        static float noticeUntil;
        static float summaryUntil;
        const float SummarySeconds = 60f;
        static GUIStyle style;

        public static bool Running { get { return phase != Phase.Idle || compare != 0; } }

        public static bool BlocksDamage
        {
            get
            {
                return phase == Phase.Arrive || phase == Phase.Warmup || phase == Phase.Walk || phase == Phase.Fly;
            }
        }

        public static void Boot()
        {
            if (!hooked)
            {
                hooked = true;
                Camera.onPreCull += OnCamera;
                RenderPipelineManager.beginCameraRendering += OnCameraSrp;
            }
            bool auto = HasArg("-benchmark");
            if (PerfPlugin.BenchmarkAuto != null && PerfPlugin.BenchmarkAuto.Value)
                auto = true;
            if (HasArg("-benchmark-ab") && Mathf.Clamp(PerfPlugin.Preset.Value, 0, 4) != 0)
                BeginComparison();
            else if (auto)
                Begin();
        }

        public static void Shutdown()
        {
            if (hooked)
            {
                Camera.onPreCull -= OnCamera;
                RenderPipelineManager.beginCameraRendering -= OnCameraSrp;
                hooked = false;
            }
            RestoreCamera();
            ReleaseDrive();
            phase = Phase.Idle;
            compare = 0;
            PerfPlugin.ForcedMode = ForcedMode.None;
        }

        public static void OnSceneUnloaded()
        {
            if (phase == Phase.Returning)
                return;
            if (phase == Phase.Warmup || phase == Phase.Walk || phase == Phase.Fly)
                Fail("Сцена выгрузилась во время замера");
        }

        public static void Tick()
        {
            var keyboard = Keyboard.current;
            bool single = keyboard != null && keyboard.f5Key.wasPressedThisFrame;
            bool pair = keyboard != null && keyboard.f7Key.wasPressedThisFrame;
            if ((single || pair) && !Typing())
            {
                // The run loads a new game and leaves it without saving: never from a running game.
                string refusal = phase == Phase.Idle ? Refusal(pair) : null;
                if (phase != Phase.Idle)
                    notice = null;
                else if (refusal != null)
                {
                    notice = refusal;
                    noticeUntil = Time.realtimeSinceStartup + 5f;
                    Log(refusal);
                }
                else if (pair)
                    BeginComparison();
                else
                    Begin();
            }
            if (phase == Phase.Idle)
                return;
            // The phase clock is clamped so one hitch cannot skip a phase; the frame statistics
            // get the real frame time, or long stalls would be recorded as 0.5 s and raise the FPS.
            float frame = Time.unscaledDeltaTime;
            float step = frame;
            if (step < 0f)
                step = 0f;
            if (step > 0.5f)
                step = 0.5f;
            phaseTime += step;
            if (Time.timeScale < 0.5f
                && (phase == Phase.Arrive || phase == Phase.Warmup || phase == Phase.Walk || phase == Phase.Fly))
                ResumeIntro();
            if (phase == Phase.WaitMenu)
                TickMenu();
            else if (phase == Phase.Load)
                TickLoad();
            else if (phase == Phase.Arrive)
                TickArrive();
            else if (phase == Phase.Warmup)
                TickWarmup();
            else if (phase == Phase.Walk)
                TickWalk(frame);
            else if (phase == Phase.Fly)
                TickFly(frame);
            else if (phase == Phase.Returning)
                TickReturn();
        }

        public static void Late()
        {
            if (phase == Phase.Warmup || phase == Phase.Walk)
                ApplyHeading(Body());
            else if (phase == Phase.Fly && flyCam != null)
                flyCam.transform.SetPositionAndRotation(flyPosition, flyRotation);
        }

        public static void Drive(ZombieFighterController character)
        {
            if (phase != Phase.Warmup && phase != Phase.Walk)
                return;
            var manager = GlobalManager.global;
            if (character == null || manager == null || !ReferenceEquals(character, manager.controlledChar))
                return;
            if (InputEditor.Global == null)
                return;
            Vector3 position = character.transform.position;
            Vector3 dir = Steer(position);
            if (dir.sqrMagnitude < 0.0001f)
                dir = basisForward;
            float desired = Mathf.Atan2(dir.x, dir.z) * Mathf.Rad2Deg;
            float rate = 140f * Mathf.Max(Time.deltaTime, 0f);
            heading = Mathf.MoveTowardsAngle(heading, desired, rate);
            ApplyHeading(character.transform);
            InputEditor.Global.MovementAxis = new Vector2(0f, 1f);
            if (haveLast)
            {
                float moved = Horizontal(position - lastPosition);
                if (phase == Phase.Walk)
                    travel += moved;
                if (PerfPolicy.StuckStep(ref stuckWindow, ref stuckTime, Time.deltaTime,
                    Horizontal(position - stuckAnchor), StuckWindow, StuckMinMove))
                    stuckAnchor = position;
                if (stuckTime > 2.2f)
                {
                    stuckTime = 0f;
                    AdvanceGoal();
                }
            }
            else
            {
                stuckAnchor = position;
                stuckWindow = 0f;
            }
            lastPosition = position;
            haveLast = true;
            Remember(position);
        }

        static string Refusal(bool pair)
        {
            string key = pair ? "F7" : "F5";
            if (LanCompatibility.Active)
                return key + ": бенчмарк недоступен во время кооп-сессии";
            if (!InMainMenu())
                return key + ": бенчмарк запускается только из главного меню";
            if (pair && Mathf.Clamp(PerfPlugin.Preset.Value, 0, 4) == 0)
                return "F7: выберите профиль мода — «Как в игре» не с чем сравнивать";
            return null;
        }

        // Comparison: the same route with the chosen profile, then as without the mod.
        // The mod goes first, so the second run gets the warm file cache: any bias favours the game.
        static void BeginComparison()
        {
            compare = 1;
            firstReady = false;
            PerfPlugin.Force(ForcedMode.Optimized);
            Begin();
        }

        static void EndComparison()
        {
            if (compare == 0)
                return;
            compare = 0;
            PerfPlugin.Force(ForcedMode.None);
        }

        static void TickComparison()
        {
            if (compare == 1 && failure == null)
            {
                firstWalk = Measure(WalkFrames);
                firstFly = flyNote == null ? Measure(FlyFrames) : new FrameStat();
                firstTravel = travel;
                firstReady = true;
                compare = 2;
                PerfPlugin.Force(ForcedMode.Vanilla);
                Begin();
                return;
            }
            if (compare == 2 && failure == null && firstReady)
                WriteComparison(Measure(WalkFrames), flyNote == null ? Measure(FlyFrames) : new FrameStat());
            EndComparison();
        }

        static void WriteComparison(FrameStat walk, FrameStat fly)
        {
            var inv = CultureInfo.InvariantCulture;
            var report = new StringBuilder();
            report.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append("  Сравнение ").Append(sceneName)
                .Append(": профиль «").Append(PresetName(PerfPlugin.Preset.Value)).Append("» против игры без мода\n");
            AppendGain(report, "Проход", firstWalk, walk);
            AppendGain(report, "Пролёт", firstFly, fly);
            report.Append("Проход с модом ").Append(firstTravel.ToString("0")).Append(" м, без мода ").Append(travel.ToString("0")).Append(" м. ");
            report.Append("Первым шёл прогон с модом: прогретый кэш достаётся игре без мода.\n");
            report.Append(string.Format(inv, "ab_walk_avg_pct={0:0.0} ab_walk_1pct_pct={1:0.0} ab_fly_avg_pct={2:0.0} ab_fly_1pct_pct={3:0.0}\n\n",
                Gain(firstWalk.Average, walk.Average, firstWalk.Ok && walk.Ok), Gain(firstWalk.Low, walk.Low, firstWalk.Ok && walk.Ok),
                Gain(firstFly.Average, fly.Average, firstFly.Ok && fly.Ok), Gain(firstFly.Low, fly.Low, firstFly.Ok && fly.Ok)));
            var text = new StringBuilder("Сравнение: с модом / без мода\n");
            text.Append("Проход  ").Append(Fps(firstWalk)).Append(" / ").Append(Fps(walk)).Append(GainText(firstWalk, walk)).Append('\n');
            text.Append("Пролёт  ").Append(Fps(firstFly)).Append(" / ").Append(Fps(fly)).Append(GainText(firstFly, fly)).Append('\n');
            text.Append("1% проход  ").Append(Low(firstWalk)).Append(" / ").Append(Low(walk));
            summary = text.ToString();
            AppendFile(report.ToString());
        }

        static void AppendGain(StringBuilder report, string title, FrameStat mod, FrameStat game)
        {
            report.Append(title).Append(": FPS ").Append(Fps(mod)).Append(" против ").Append(Fps(game));
            if (mod.Ok && game.Ok)
                report.Append(" (").Append(Signed(Gain(mod.Average, game.Average, true))).Append("%), 1% ")
                    .Append(Low(mod)).Append(" против ").Append(Low(game))
                    .Append(" (").Append(Signed(Gain(mod.Low, game.Low, true))).Append("%)");
            report.Append('\n');
        }

        // Frame times in, percent more FPS with the mod out.
        static float Gain(float modFrame, float gameFrame, bool ok)
        {
            if (!ok || modFrame <= 0f || gameFrame <= 0f)
                return 0f;
            return (gameFrame / modFrame - 1f) * 100f;
        }

        static string GainText(FrameStat mod, FrameStat game)
        {
            return mod.Ok && game.Ok ? "  (" + Signed(Gain(mod.Average, game.Average, true)) + "%)" : "";
        }

        static string Signed(float value)
        {
            return (value >= 0f ? "+" : "") + value.ToString("0");
        }

        // Same test as the LAN skin picker: a main-menu screen is shown and no character exists yet.
        static bool InMainMenu()
        {
            var gui = Gui();
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            if (gui == null || scenes != null && scenes.SceneCurrentlyLoading)
                return false;
            bool menu = gui.mainGameMenu != null && gui.mainGameMenu.activeInHierarchy
                || gui.startGameMenu != null && gui.startGameMenu.activeInHierarchy;
            return menu && (manager == null || manager.controlledChar == null);
        }

        public static void Draw()
        {
            if (notice != null && Time.realtimeSinceStartup >= noticeUntil)
                notice = null;
            // The result stays in benchmark.txt; on screen it belongs to the main menu only.
            var manager = GlobalManager.global;
            if (phase == Phase.Idle && summary.Length > 0 && (Time.realtimeSinceStartup >= summaryUntil
                || manager != null && manager.controlledChar != null))
                summary = "";
            if (phase == Phase.Idle && summary.Length == 0 && notice == null)
                return;
            EnsureStyle();
            string text = notice ?? Overlay();
            if (text.Length == 0)
                return;
            int depth = GUI.depth;
            Color color = GUI.color;
            GUI.depth = 0;
            bool tall = notice == null && (phase == Phase.Idle || phase == Phase.Returning);
            var box = new Rect(Screen.width * 0.5f - 230f, 10f, 460f, tall ? 168f : 72f);
            GUI.color = new Color(0f, 0f, 0f, 0.62f);
            GUI.DrawTexture(box, Texture2D.whiteTexture);
            GUI.color = Color.white;
            GUI.Label(new Rect(box.x + 10f, box.y + 6f, box.width - 20f, box.height - 10f), text, style);
            GUI.color = color;
            GUI.depth = depth;
        }

        static void Begin()
        {
            RestoreCamera();
            ReleaseDrive();
            requested = false;
            phaseTime = 0f;
            stableTime = 0f;
            stuckTime = 0f;
            travel = 0f;
            goalIndex = 0;
            corner = 0;
            rings = 0;
            failedGoal = -2;
            pathReady = false;
            arriveCharacter = int.MinValue;
            haveLast = false;
            failure = null;
            flyNote = null;
            summary = "";
            sceneName = FallbackScene;
            Goals.Clear();
            Trail.Clear();
            WalkFrames.Clear();
            FlyFrames.Clear();
            FlyPoints.Clear();
            FlyLength.Clear();
            phase = Phase.WaitMenu;
            Log("Бенчмарк первой локации запущен");
        }

        static void TickMenu()
        {
            if (Gui() == null || GlobalSceneManager.global == null || GlobalManager.global == null)
            {
                if (phaseTime > 30f)
                    Fail("Меню игры не появилось");
                return;
            }
            bool menu = SceneLoaded("1StartGameMenuLocation");
            if ((menu && phaseTime > 0.4f) || phaseTime > 12f)
                RequestLocation();
        }

        static void TickLoad()
        {
            if (phaseTime > 90f)
            {
                Fail("Первая локация не загрузилась: " + sceneName);
                return;
            }
            var scenes = GlobalSceneManager.global;
            var manager = GlobalManager.global;
            if (scenes == null || manager == null || manager.controlledChar == null)
                return;
            if (scenes.SceneCurrentlyLoading)
                return;
            if (scenes.CurrentSceneName != sceneName && !SceneLoaded(sceneName))
                return;
            phase = Phase.Arrive;
            phaseTime = 0f;
            stableTime = 0f;
            arriveCharacter = manager.controlledChar.GetInstanceID();
            Log("Локация загружена: " + sceneName);
        }

        static void TickArrive()
        {
            var manager = GlobalManager.global;
            var character = manager == null ? null : manager.controlledChar;
            if (character == null)
            {
                if (phaseTime > 25f)
                    Fail("Персонаж не появился на первой локации");
                return;
            }
            if (character.GetInstanceID() != arriveCharacter)
            {
                arriveCharacter = character.GetInstanceID();
                stableTime = 0f;
            }
            if (Time.timeScale >= 0.5f && character.controlEnabled)
                stableTime += Time.unscaledDeltaTime;
            else
                stableTime = 0f;
            if (stableTime >= 0.8f || phaseTime > 20f)
                EnterWarmup(character);
        }

        static void TickWarmup()
        {
            if (phaseTime >= WarmupSeconds)
            {
                phase = Phase.Walk;
                phaseTime = 0f;
                travel = 0f;
                stuckTime = 0f;
                stuckWindow = 0f;
                stuckAnchor = lastPosition;
                Log("Замер прохода");
            }
        }

        static void TickWalk(float frame)
        {
            if (frame > 0f)
                WalkFrames.Add(frame);
            if (phaseTime >= WalkSeconds)
                EnterFly();
        }

        static void TickFly(float frame)
        {
            if (frame > 0f)
                FlyFrames.Add(frame);
            float blend = phaseTime < 1.4f ? Smooth(phaseTime / 1.4f) : 1f;
            float span = FlyLength.Count == 0 ? 0f : FlyLength[FlyLength.Count - 1];
            float along = FlySeconds <= 0f ? span : span * Mathf.Clamp01(phaseTime / FlySeconds);
            Vector3 onPath = Sample(along);
            Vector3 ahead = Sample(along + 8f);
            flyPosition = Vector3.Lerp(flyStartPos, onPath, blend);
            Vector3 look = ahead + Vector3.down * 7f - flyPosition;
            if (look.sqrMagnitude < 0.01f)
                look = flyStartRot * Vector3.forward;
            flyRotation = Quaternion.Slerp(flyStartRot, Quaternion.LookRotation(look.normalized, Vector3.up), blend);
            if (phaseTime >= FlySeconds)
                Finish();
        }

        static void RequestLocation()
        {
            if (requested)
                return;
            requested = true;
            try
            {
                if (ProceduralMode.Global != null)
                    ProceduralMode.Global.Active = false;
                float train;
                ReadFirstPoint(out sceneName, out train);
                var gui = Gui();
                if (gui != null)
                    gui.ExitStartGameMenuButton();
                var manager = GlobalManager.global;
                manager.GameStarted = true;
                manager.GameStartedTime = Time.time;
                GlobalSceneManager.SaveLocationStartFileAfterSceneLoaded = false;
                GlobalSceneManager.global.LoadLevel(sceneName, train, -1);
                phase = Phase.Load;
                phaseTime = 0f;
                Log("Загрузка первой локации " + sceneName + " поезд " + train.ToString("0.0"));
            }
            catch (Exception ex)
            {
                Fail(ex.Message);
            }
        }

        static void ReadFirstPoint(out string scene, out float train)
        {
            scene = FallbackScene;
            train = FallbackTrain;
            var gui = Gui();
            if (gui == null || gui.StartingPoints == null || gui.StartingPoints.Count == 0)
                return;
            var point = gui.StartingPoints[0];
            if (point == null)
                return;
            if (!string.IsNullOrEmpty(point.LevelName))
                scene = point.LevelName;
            train = point.TrainPosition;
        }

        static void EnterWarmup(ZombieFighterController character)
        {
            ResumeIntro();
            character.controlEnabled = true;
            character.IgnoreNextFallDamage = true;
            PlaceOnGround(character);
            var body = character.transform;
            origin = body.position;
            basisForward = Flat(body.forward);
            if (basisForward.sqrMagnitude < 0.01f)
                basisForward = Vector3.forward;
            basisForward.Normalize();
            basisRight = Flat(body.right);
            if (basisRight.sqrMagnitude < 0.01f)
                basisRight = Vector3.Cross(Vector3.up, basisForward);
            basisRight.Normalize();
            heading = body.eulerAngles.y;
            lastPosition = origin;
            haveLast = true;
            stuckAnchor = origin;
            stuckWindow = 0f;
            Goals.Clear();
            goalIndex = 0;
            rings = 0;
            pathReady = false;
            failedGoal = -2;
            ExtendGoals();
            Remember(origin);
            phase = Phase.Warmup;
            phaseTime = 0f;
            stableTime = 0f;
            stuckTime = 0f;
            Log("Проход по " + sceneName);
        }

        static void PlaceOnGround(ZombieFighterController character)
        {
            var body = character.transform;
            body.SetParent(null, true);
            Vector3 position = body.position;
            Vector3 right = Flat(body.right);
            if (right.sqrMagnitude < 0.01f)
                right = Vector3.right;
            right.Normalize();
            float[] sides = { 5f, -5f, 8f, -8f, 12f, -12f, 3f, -3f };
            for (int i = 0; i < sides.Length; i++)
            {
                Vector3 probe = position + right * sides[i] + Vector3.up * 4f;
                RaycastHit ground;
                if (!Physics.Raycast(probe, Vector3.down, out ground, 50f, ~0, QueryTriggerInteraction.Ignore))
                    continue;
                if (ground.collider != null && ground.collider.transform.IsChildOf(body))
                    continue;
                NavMeshHit nav;
                if (!NavMesh.SamplePosition(ground.point, out nav, 6f, NavMesh.AllAreas))
                    continue;
                Vector3 flat = nav.position - position;
                flat.y = 0f;
                if (flat.magnitude < 2.5f && nav.position.y > position.y - 1.2f)
                    continue;
                Teleport(character, nav.position + Vector3.up * 0.2f);
                return;
            }
        }

        static void Teleport(ZombieFighterController character, Vector3 position)
        {
            character.IgnoreNextFallDamage = true;
            var body = character.transform;
            if (character.controller != null)
                character.controller.enabled = false;
            body.position = position;
            if (character.controller != null)
                character.controller.enabled = true;
        }

        static void EnterFly()
        {
            ReleaseDrive();
            BuildFlyPath();
            flyCam = null;
            var manager = GlobalManager.global;
            if (manager != null && manager.MainCamera != null)
                flyCam = manager.MainCamera;
            if (flyCam == null)
                flyCam = Camera.main;
            if (flyCam == null || FlyPoints.Count < 2)
            {
                flyNote = "Пролёт пропущен: нет камеры или слишком короткий маршрут.";
                Finish();
                return;
            }
            var controller = CameraController.global;
            if (controller != null)
            {
                flyCamWasEnabled = controller.enabled;
                controller.enabled = false;
            }
            cameraHeld = true;
            flyParent = flyCam.transform.parent;
            flyLocalPos = flyCam.transform.localPosition;
            flyLocalRot = flyCam.transform.localRotation;
            flyStartPos = flyCam.transform.position;
            flyStartRot = flyCam.transform.rotation;
            flyCam.transform.SetParent(null, true);
            flyPosition = flyStartPos;
            flyRotation = flyStartRot;
            phase = Phase.Fly;
            phaseTime = 0f;
            Log("Замер пролёта");
        }

        static void BuildFlyPath()
        {
            FlyPoints.Clear();
            FlyLength.Clear();
            float length = 0f;
            if (Trail.Count > 1)
            {
                for (int i = 1; i < Trail.Count; i++)
                    length += Horizontal(Trail[i] - Trail[i - 1]);
            }
            if (Trail.Count < 2 || length < 12f)
            {
                Vector3 center = Trail.Count > 0 ? Trail[0] : origin;
                for (int i = 0; i <= 16; i++)
                {
                    float angle = i / 16f * Mathf.PI * 2f;
                    Vector3 ground = center + new Vector3(Mathf.Cos(angle) * 22f, 0f, Mathf.Sin(angle) * 22f);
                    FlyPoints.Add(ground + Vector3.up * Clearance(ground));
                }
            }
            else
            {
                int count = Trail.Count < 48 ? Trail.Count : 48;
                for (int i = 0; i < count; i++)
                {
                    float t = count == 1 ? 0f : i / (float)(count - 1);
                    int index = Mathf.RoundToInt(t * (Trail.Count - 1));
                    Vector3 ground = Trail[index];
                    FlyPoints.Add(ground + Vector3.up * Clearance(ground));
                }
            }
            float cursor = 0f;
            FlyLength.Add(0f);
            for (int i = 1; i < FlyPoints.Count; i++)
            {
                cursor += Vector3.Distance(FlyPoints[i - 1], FlyPoints[i]);
                FlyLength.Add(cursor);
            }
        }

        static float Clearance(Vector3 ground)
        {
            var hits = Physics.RaycastAll(ground + Vector3.up * 0.5f, Vector3.up, 16f, ~0, QueryTriggerInteraction.Ignore);
            float nearest = 16f;
            Transform root = Body();
            for (int i = 0; i < hits.Length; i++)
            {
                if (root != null && hits[i].transform != null && hits[i].transform.IsChildOf(root))
                    continue;
                if (hits[i].distance < nearest)
                    nearest = hits[i].distance;
            }
            if (nearest < 15f)
                return Mathf.Clamp(nearest * 0.45f, 2.2f, 11f);
            return 11f;
        }

        static void Finish()
        {
            if (phase == Phase.Returning)
                return;
            RestoreCamera();
            ReleaseDrive();
            WriteReport();
            phase = Phase.Returning;
            phaseTime = 0f;
            Log(failure == null ? "Бенчмарк завершён, возврат в меню" : "Бенчмарк остановлен: " + failure);
            ReturnToMenu();
        }

        static void Fail(string reason)
        {
            if (phase == Phase.Returning)
                return;
            failure = reason;
            Finish();
        }

        static void ReturnToMenu()
        {
            try
            {
                Time.timeScale = 1f;
                var gui = Gui();
                if (gui == null)
                {
                    phase = Phase.Idle;
                    return;
                }
                gui.ExitGameToMainMenuYesButton();
            }
            catch (Exception ex)
            {
                phase = Phase.Idle;
                Log(ex.Message);
            }
        }

        static void TickReturn()
        {
            if (phaseTime < 1.2f)
                return;
            if (MenuBack() || phaseTime > 25f)
            {
                phase = Phase.Idle;
                phaseTime = 0f;
                if (compare != 0)
                    TickComparison();
                if (phase == Phase.Idle)
                {
                    summaryUntil = Time.realtimeSinceStartup + SummarySeconds;
                    Log("Меню открыто. F5 — бенчмарк, F7 — сравнение с игрой без мода.");
                }
            }
        }

        static bool MenuBack()
        {
            if (Gui() == null || GlobalManager.global == null)
                return false;
            if (!SceneLoaded("1MainScene") || SceneLoaded(sceneName))
                return false;
            var scenes = GlobalSceneManager.global;
            return scenes == null || !scenes.SceneCurrentlyLoading;
        }

        static void ExtendGoals()
        {
            if (rings >= 3)
            {
                goalIndex = 0;
                pathReady = false;
                failedGoal = -2;
                return;
            }
            rings++;
            float scale = 1f + (rings - 1) * 0.7f;
            for (int i = 0; i < RingX.Length; i++)
                Goals.Add(origin + basisRight * (RingX[i] * scale) + basisForward * (RingZ[i] * scale));
        }

        static void AdvanceGoal()
        {
            goalIndex++;
            pathReady = false;
            failedGoal = -2;
            if (goalIndex >= Goals.Count)
                ExtendGoals();
        }

        static Vector3 Steer(Vector3 position)
        {
            Vector3 target = NextTarget(position);
            Vector3 to = target - position;
            to.y = 0f;
            if (to.sqrMagnitude < 0.04f)
                return basisForward;
            Vector3 dir = to.normalized;
            if (!Blocked(position, dir))
                return dir;
            float[] angles = { 40f, -40f, 75f, -75f, 120f, -120f };
            for (int i = 0; i < angles.Length; i++)
            {
                Vector3 turned = Quaternion.Euler(0f, angles[i], 0f) * dir;
                if (!Blocked(position, turned))
                    return turned;
            }
            return Quaternion.Euler(0f, 90f, 0f) * dir;
        }

        static Vector3 NextTarget(Vector3 position)
        {
            if (Goals.Count == 0)
                ExtendGoals();
            if (goalIndex >= Goals.Count)
                goalIndex = 0;
            if (!pathReady)
                TryPath(position);
            if (pathReady && Route.corners != null && corner < Route.corners.Length)
            {
                if (FlatSqr(Route.corners[corner], position) < 2.25f)
                {
                    corner++;
                    if (corner >= Route.corners.Length)
                    {
                        AdvanceGoal();
                        TryPath(position);
                    }
                }
                if (pathReady && Route.corners != null && corner < Route.corners.Length)
                    return Route.corners[corner];
            }
            Vector3 goal = Goals[goalIndex];
            if (FlatSqr(goal, position) < 16f)
                AdvanceGoal();
            if (goalIndex >= Goals.Count)
                goalIndex = 0;
            return Goals[goalIndex];
        }

        static void TryPath(Vector3 position)
        {
            pathReady = false;
            if (Goals.Count == 0 || failedGoal == goalIndex)
                return;
            if (goalIndex >= Goals.Count)
                goalIndex = 0;
            Vector3 goal = Goals[goalIndex];
            NavMeshHit nav;
            if (NavMesh.SamplePosition(goal, out nav, 20f, NavMesh.AllAreas))
                goal = nav.position;
            Vector3 from = position;
            NavMeshHit start;
            if (NavMesh.SamplePosition(position, out start, 8f, NavMesh.AllAreas))
                from = start.position;
            if (NavMesh.CalculatePath(from, goal, NavMesh.AllAreas, Route)
                && Route.status != NavMeshPathStatus.PathInvalid
                && Route.corners != null && Route.corners.Length > 1)
            {
                pathReady = true;
                corner = 1;
                failedGoal = -2;
            }
            else
                failedGoal = goalIndex;
        }

        static bool Blocked(Vector3 position, Vector3 dir)
        {
            Vector3 originCast = position + Vector3.up * 1.05f + dir * 0.65f;
            RaycastHit hit;
            if (!Physics.SphereCast(originCast, 0.3f, dir, out hit, 1.25f, ~0, QueryTriggerInteraction.Ignore))
                return false;
            Transform root = Body();
            if (root != null && hit.transform != null && hit.transform.IsChildOf(root))
                return Physics.SphereCast(hit.point + dir * 0.25f, 0.3f, dir, out hit, 1f, ~0, QueryTriggerInteraction.Ignore);
            return true;
        }

        static void Remember(Vector3 position)
        {
            if (Trail.Count == 0 || FlatSqr(Trail[Trail.Count - 1], position) >= 9f)
                Trail.Add(position);
        }

        static Vector3 Sample(float distance)
        {
            if (FlyPoints.Count == 0)
                return flyPosition;
            if (FlyPoints.Count == 1 || distance <= 0f)
                return FlyPoints[0];
            float total = FlyLength[FlyLength.Count - 1];
            if (distance >= total)
                return FlyPoints[FlyPoints.Count - 1];
            int index = 1;
            while (index < FlyLength.Count && FlyLength[index] < distance)
                index++;
            float begin = FlyLength[index - 1];
            float span = FlyLength[index] - begin;
            float blend = span > 0.001f ? (distance - begin) / span : 0f;
            return Vector3.Lerp(FlyPoints[index - 1], FlyPoints[index], blend);
        }

        static void ApplyHeading(Transform body)
        {
            if (body == null)
                return;
            var rotation = Quaternion.Euler(0f, heading, 0f);
            var camera = CameraController.global;
            Transform view = camera == null ? null : camera.playerBody;
            if (view != null && view != body && body.IsChildOf(view))
            {
                view.rotation = rotation;
                body.rotation = rotation;
            }
            else
            {
                body.rotation = rotation;
                if (view != null && view != body)
                    view.rotation = rotation;
            }
            if (camera != null)
                camera.rotationY = 14f;
        }

        static void OnCamera(Camera cam) { Pose(cam); }

        static void OnCameraSrp(ScriptableRenderContext context, Camera cam) { Pose(cam); }

        static void Pose(Camera cam)
        {
            if (phase != Phase.Fly || flyCam == null || cam != flyCam)
                return;
            cam.transform.SetPositionAndRotation(flyPosition, flyRotation);
        }

        static void RestoreCamera()
        {
            if (!cameraHeld)
                return;
            cameraHeld = false;
            var controller = CameraController.global;
            if (controller != null)
                controller.enabled = flyCamWasEnabled;
            if (flyCam != null && flyParent != null)
            {
                flyCam.transform.SetParent(flyParent, false);
                flyCam.transform.localPosition = flyLocalPos;
                flyCam.transform.localRotation = flyLocalRot;
            }
            flyCam = null;
            flyParent = null;
        }

        static void ResumeIntro()
        {
            if (Time.timeScale >= 0.5f || GlobalSceneManager.global == null)
                return;
            try
            {
                GlobalSceneManager.global.PlayAfterIntroductionButton();
            }
            catch (Exception ex)
            {
                Log(ex.Message);
            }
            stableTime = 0f;
        }

        static void ReleaseDrive()
        {
            if (InputEditor.Global != null)
                InputEditor.Global.MovementAxis = Vector2.zero;
        }

        static void WriteReport()
        {
            FrameStat walk = Measure(WalkFrames);
            FrameStat fly = Measure(FlyFrames);
            var report = new StringBuilder();
            report.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            report.Append("  ").Append(sceneName);
            if (compare != 0)
                report.Append("  [сравнение ").Append(compare).Append("/2]");
            var scenes = GlobalSceneManager.global;
            if (scenes != null)
            {
                var data = scenes.GetCurrentSceneData();
                if (data != null && !string.IsNullOrEmpty(data.name) && data.name != sceneName)
                    report.Append(" (").Append(data.name).Append(')');
            }
            report.Append('\n');
            report.Append(Screen.width).Append('x').Append(Screen.height).Append(' ').Append(Screen.fullScreenMode);
            report.Append("  ").Append(PresetName());
            if (RenderScale.Active)
                report.Append("  ").Append(RenderScale.Describe());
            if (SkyQuality.Describe().Length > 0)
                report.Append("  ").Append(SkyQuality.Describe());
            if (AntiAliasing.Describe().Length > 0)
                report.Append("  ").Append(AntiAliasing.Describe());
            if (ReflectionUpdates.Describe().Length > 0)
                report.Append("  ").Append(ReflectionUpdates.Describe());
            int level = QualitySettings.GetQualityLevel();
            if (QualitySettings.names != null && level >= 0 && level < QualitySettings.names.Length)
                report.Append("  качество ").Append(QualitySettings.names[level]);
            report.Append("\nПроход ").Append(travel.ToString("0")).Append(" м за ").Append(WalkSeconds.ToString("0")).Append(" с\n");
            AppendStat(report, "Проход", walk);
            if (flyNote != null)
                report.Append(flyNote).Append('\n');
            else
                AppendStat(report, "Пролёт", fly);
            if (failure == null && travel < 8f)
                report.Append("Персонаж почти не сдвинулся, маршрут мог упереться в геометрию.\n");
            if (failure != null)
                report.Append("Ошибка: ").Append(failure).Append('\n');
            var inv = CultureInfo.InvariantCulture;
            report.Append(string.Format(inv,
                "walk_fps_avg={0:0.00} walk_fps_1pct={1:0.00} fly_fps_avg={2:0.00} fly_fps_1pct={3:0.00} walk_m={4:0.0}\n\n",
                walk.Ok ? 1f / walk.Average : 0f,
                walk.Ok ? 1f / walk.Low : 0f,
                fly.Ok ? 1f / fly.Average : 0f,
                fly.Ok ? 1f / fly.Low : 0f,
                travel));
            summary = SummaryText(walk, fly);
            AppendFile(report.ToString());
        }

        static void AppendFile(string text)
        {
            try
            {
                string root = Directory.GetParent(Application.dataPath).FullName;
                string path = Path.Combine(Path.Combine(root, "BepInEx"), "benchmark.txt");
                File.AppendAllText(path, text, Encoding.UTF8);
                Log("Отчёт " + path);
            }
            catch (Exception ex)
            {
                Log(ex.Message);
            }
        }

        static string SummaryText(FrameStat walk, FrameStat fly)
        {
            var text = new StringBuilder();
            if (failure != null)
                text.Append("Бенчмарк остановлен\n").Append(failure);
            else
                text.Append("Бенчмарк ").Append(sceneName).Append('\n');
            text.Append("Проход  FPS ").Append(Fps(walk)).Append("   1% ").Append(Low(walk)).Append('\n');
            text.Append("Пролёт  FPS ").Append(Fps(fly)).Append("   1% ").Append(Low(fly));
            return text.ToString();
        }

        static string Overlay()
        {
            if (phase == Phase.Returning)
                return summary + "\nВозврат в меню";
            if (phase == Phase.Idle)
                return summary + "\nF5 — бенчмарк, F7 — сравнение с игрой без мода";
            string title = compare == 1 ? "Сравнение 1/2 · с модом" : compare == 2 ? "Сравнение 2/2 · без мода" : "Бенчмарк";
            if (phase == Phase.WaitMenu || phase == Phase.Load)
                return title + "\nЗагрузка первой локации";
            if (phase == Phase.Arrive)
                return title + "\nСтарт локации";
            if (phase == Phase.Warmup)
                return title + " · разгон\n" + phaseTime.ToString("0.0") + " / " + WarmupSeconds.ToString("0") + " с";
            if (phase == Phase.Walk)
                return title + " · проход\n" + phaseTime.ToString("0.0") + " / " + WalkSeconds.ToString("0")
                    + " с    FPS " + Live(WalkFrames);
            if (phase == Phase.Fly)
                return title + " · пролёт\n" + phaseTime.ToString("0.0") + " / " + FlySeconds.ToString("0")
                    + " с    FPS " + Live(FlyFrames);
            return "";
        }

        struct FrameStat
        {
            public bool Ok;
            public float Average;
            public float Low;
            public float Slowest;
            public int Count;
        }

        static FrameStat Measure(List<float> frames)
        {
            var stat = new FrameStat();
            if (frames == null || frames.Count == 0)
                return stat;
            stat.Ok = true;
            stat.Count = frames.Count;
            float sum = 0f;
            float slowest = 0f;
            var ordered = new float[frames.Count];
            for (int i = 0; i < frames.Count; i++)
            {
                float step = frames[i];
                ordered[i] = step;
                sum += step;
                if (step > slowest)
                    slowest = step;
            }
            Array.Sort(ordered);
            int lowCount = Math.Max(1, frames.Count / 100);
            float lowSum = 0f;
            for (int i = frames.Count - lowCount; i < frames.Count; i++)
                lowSum += ordered[i];
            stat.Average = sum / frames.Count;
            stat.Low = lowSum / lowCount;
            stat.Slowest = slowest;
            return stat;
        }

        static void AppendStat(StringBuilder report, string title, FrameStat stat)
        {
            report.Append(title).Append(": ");
            if (!stat.Ok)
            {
                report.Append("нет кадров\n");
                return;
            }
            report.Append(stat.Count).Append(" кадров, FPS ср ").Append((1f / stat.Average).ToString("0.0"));
            report.Append(", 1% ").Append((1f / stat.Low).ToString("0.0"));
            report.Append(", мин ").Append((1f / stat.Slowest).ToString("0.0")).Append('\n');
        }

        static string Fps(FrameStat stat)
        {
            return stat.Ok ? (1f / stat.Average).ToString("0.0") : "—";
        }

        static string Low(FrameStat stat)
        {
            return stat.Ok ? (1f / stat.Low).ToString("0.0") : "—";
        }

        static string Live(List<float> frames)
        {
            int samples = frames.Count < 30 ? frames.Count : 30;
            if (samples == 0)
                return "—";
            float sum = 0f;
            for (int i = frames.Count - samples; i < frames.Count; i++)
                sum += frames[i];
            float mean = sum / samples;
            if (mean <= 0f)
                return "—";
            return (1f / mean).ToString("0");
        }

        static string PresetName()
        {
            if (PerfPlugin.Tune.Bypass)
                return "как без мода";
            return PresetName(PerfPlugin.Tune.Preset);
        }

        static string PresetName(int preset)
        {
            switch (preset)
            {
                case 0: return "как в игре";
                case 1: return "максимум";
                case 2: return "сбалансировано";
                case 3: return "минимум";
                case 5: return "лучший баланс";
                case 4: return "своё";
                default: return "профиль " + preset;
            }
        }

        static Transform Body()
        {
            var manager = GlobalManager.global;
            if (manager == null || manager.controlledChar == null)
                return null;
            return manager.controlledChar.transform;
        }

        // Singleton<GUIManager>.Global creates a new GUIManager when none exists, e.g. during the
        // main-menu reset. That stray copy threw every frame and froze the menu: read, never create.
        static readonly System.Reflection.FieldInfo GuiInstance = typeof(Zompiercer.Singleton<GUIManager>)
            .GetField("_instance", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);

        static GUIManager Gui()
        {
            var gui = GuiInstance == null ? null : GuiInstance.GetValue(null) as GUIManager;
            return gui != null ? gui : null;
        }

        static bool SceneLoaded(string name)
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (scene.isLoaded && scene.name == name)
                    return true;
            }
            return false;
        }

        static bool Typing()
        {
            var events = UnityEngine.EventSystems.EventSystem.current;
            if (events == null || events.currentSelectedGameObject == null)
                return false;
            return events.currentSelectedGameObject.GetComponent<UnityEngine.UI.InputField>() != null;
        }

        static float FlatSqr(Vector3 a, Vector3 b)
        {
            float x = a.x - b.x;
            float z = a.z - b.z;
            return x * x + z * z;
        }

        static float Horizontal(Vector3 delta)
        {
            delta.y = 0f;
            return delta.magnitude;
        }

        static Vector3 Flat(Vector3 value)
        {
            value.y = 0f;
            return value;
        }

        static float Smooth(float value)
        {
            value = Mathf.Clamp01(value);
            return value * value * (3f - 2f * value);
        }

        static bool HasArg(string name)
        {
            var args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length; i++)
            {
                if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        static void Log(string message)
        {
            if (PerfPlugin.Instance != null)
                PerfPlugin.Instance.LogInfo(message);
        }

        static void EnsureStyle()
        {
            if (style != null)
                return;
            style = new GUIStyle(GUI.skin.label);
            style.normal.textColor = Color.white;
            style.fontSize = 16;
            style.alignment = TextAnchor.UpperLeft;
        }

        [HarmonyPatch(typeof(ZombieFighterController), "Movement")]
        static class DrivePatch
        {
            static void Prefix(ZombieFighterController __instance)
            {
                Drive(__instance);
            }
        }

        [HarmonyPatch(typeof(ZombieFighterIndicatorsBar), "CauseDamage")]
        static class DamagePatch
        {
            static bool Prefix()
            {
                return !BlocksDamage;
            }
        }

        // The game's "exit to main menu" destroys every visible GameObject, including the
        // BepInEx manager (HideManagerGameObject=false), which used to unload this mod after
        // the first exit unless ZompiercerLAN was installed. LAN keeps the manager with its own
        // transpiler; without it this prefix runs the same cleanup and spares the plugins.
        [HarmonyPatch(typeof(GlobalSceneManager), "DeleteEverything2")]
        static class KeepLoaderPatch
        {
            static bool Prefix(System.Reflection.MethodBase __originalMethod)
            {
                if (LanKeepsManager(__originalMethod))
                    return true;
                var objects = UnityEngine.Object.FindObjectsOfType<GameObject>();
                for (int i = 0; i < objects.Length; i++)
                {
                    var item = objects[i];
                    if (item == null || Keep(item))
                        continue;
                    UnityEngine.Object.Destroy(item);
                }
                if (DontDestroyOnLoadController.global != null)
                    DontDestroyOnLoadController.global.DestroyObjects();
                return false;
            }

            static bool LanKeepsManager(System.Reflection.MethodBase method)
            {
                var info = method == null ? null : Harmony.GetPatchInfo(method);
                if (info == null)
                    return false;
                foreach (var patch in info.Transpilers)
                    if (patch.owner == "local.zompiercer.lan.leave")
                        return true;
                return false;
            }

            static bool Keep(GameObject item)
            {
                string name = item.name;
                if (name == "SteamManager" || name == "_CurvyGlobal_" || name.StartsWith("BepInEx"))
                    return true;
                var manager = BepInEx.Bootstrap.Chainloader.ManagerObject;
                if (manager != null && (item == manager || item.transform.IsChildOf(manager.transform)))
                    return true;
                return item.GetComponentInParent<BepInEx.BaseUnityPlugin>() != null;
            }
        }
    }
}
