param([string]$GameDir = (Split-Path -Parent $PSScriptRoot), [switch]$Install, [switch]$Shader, [string]$Unity = '')
$ErrorActionPreference = 'Stop'
$GameDir = [IO.Path]::GetFullPath($GameDir)
if (!(Test-Path -LiteralPath (Join-Path $GameDir 'Zompiercer.exe'))) { throw 'Choose a folder containing Zompiercer.exe with -GameDir.' }
$shaderProject = Join-Path $PSScriptRoot 'fsr-shader'
$bundle = Join-Path $shaderProject 'Build/zompiercerperf-fsr.bundle'
$license = Join-Path $shaderProject 'LICENSE-FSR.txt'

if ($Shader) {
    # The bundle must come from the game's Unity version (2020.1.17f1) or the player may refuse it.
    if ($Unity -eq '') {
        $editors = Join-Path $env:APPDATA 'UnityHub/editors-v2.json'
        if (Test-Path -LiteralPath $editors) {
            $entry = (Get-Content -LiteralPath $editors -Raw | ConvertFrom-Json).data | Where-Object { $_.version -eq '2020.1.17f1' } | Select-Object -First 1
            if ($entry) { $Unity = @($entry.location)[0] }
        }
    }
    if ($Unity -ne '' -and (Test-Path -LiteralPath $Unity -PathType Container)) {
        foreach ($candidate in @('Unity.exe', 'Editor/Unity.exe')) {
            if (Test-Path -LiteralPath (Join-Path $Unity $candidate)) { $Unity = Join-Path $Unity $candidate; break }
        }
    }
    if ($Unity -eq '' -or !(Test-Path -LiteralPath $Unity -PathType Leaf)) { throw 'Unity 2020.1.17f1 not found; pass -Unity <path to Unity.exe>.' }
    $log = Join-Path $shaderProject 'build-bundle.log'
    if (Test-Path -LiteralPath $bundle) { Remove-Item -LiteralPath $bundle }
    $process = Start-Process -FilePath $Unity -PassThru -NoNewWindow -ArgumentList @(
        '-batchmode', '-nographics', '-quit', '-projectPath', "`"$shaderProject`"",
        '-executeMethod', 'BuildFsrBundle.Build', '-logFile', "`"$log`"")
    # Guard: Unity 2020.1 once hung after the build and ate all memory. Stop it after 10 minutes,
    # above 3 GB, or 20 s after the bundle has appeared.
    $deadline = (Get-Date).AddMinutes(10)
    $bundleSeen = $null
    while (!$process.HasExited) {
        Start-Sleep -Seconds 2
        $process.Refresh()
        $tooBig = $process.WorkingSet64 -gt 3GB
        if ($bundleSeen -eq $null -and (Test-Path -LiteralPath $bundle)) { $bundleSeen = Get-Date }
        $lingering = $bundleSeen -ne $null -and ((Get-Date) - $bundleSeen).TotalSeconds -gt 20
        if ($tooBig -or $lingering -or (Get-Date) -gt $deadline) {
            Write-Output ("Stopping Unity: " + $(if ($tooBig) { 'memory over 3 GB' } elseif ($lingering) { 'still running after the build' } else { 'timeout' }))
            Stop-Process -Id $process.Id -Force
            Get-Process -Name UnityShaderCompiler -ErrorAction SilentlyContinue | Stop-Process -Force
            break
        }
    }
    if (!(Test-Path -LiteralPath $bundle)) { throw "Shader bundle build failed, see $log" }
    Write-Output "Shader bundle: $bundle"
}

& dotnet build (Join-Path $PSScriptRoot 'ZompiercerPerf.csproj') -c Release "-p:GameDir=$GameDir" -warnaserror -v minimal
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
$built = Join-Path $PSScriptRoot 'bin/Release/net472/ZompiercerPerf.dll'
Write-Output "Built: $built"
if ($Install) {
    if (Get-Process -Name Zompiercer -ErrorAction SilentlyContinue) { throw 'Close the game before installing.' }
    $plugins = Join-Path $GameDir 'BepInEx/plugins'
    $destination = Join-Path $plugins 'ZompiercerPerf.dll'
    if (Test-Path -LiteralPath $destination) {
        $backup = Join-Path $PSScriptRoot ('diagnostics/installed-before-' + [Guid]::NewGuid().ToString('N') + '/ZompiercerPerf.dll')
        New-Item -ItemType Directory -Path (Split-Path $backup -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $destination -Destination $backup
        Write-Output "Previous DLL: $backup"
    }
    New-Item -ItemType Directory -Path $plugins -Force | Out-Null
    Copy-Item -LiteralPath $built -Destination $destination -Force
    if ((Get-FileHash -LiteralPath $built).Hash -ne (Get-FileHash -LiteralPath $destination).Hash) { throw 'Installed DLL hash differs.' }
    Write-Output "Installed: $destination"
    if (Test-Path -LiteralPath $bundle) {
        Copy-Item -LiteralPath $bundle -Destination (Join-Path $plugins 'zompiercerperf-fsr.bundle') -Force
        Copy-Item -LiteralPath $license -Destination (Join-Path $plugins 'ZompiercerPerf-LICENSE-FSR.txt') -Force
        Write-Output "Installed FSR shader bundle."
    }
    else { Write-Output 'No FSR bundle built yet: render scale uses plain upscaling until build.ps1 -Shader runs.' }
}
